import { useEffect, useRef, useState, useCallback } from 'react'
import * as tf from '@tensorflow/tfjs'
import * as cocoSsd from '@tensorflow-models/coco-ssd'
import * as blazeface from '@tensorflow-models/blazeface'

interface DetectionStats {
  phoneDetections: number
  faceDetections: number
  totalFrames: number
  averageConfidence: number
}

export const useAIDetection = (
  videoRef: React.RefObject<HTMLVideoElement>,
  canvasRef: React.RefObject<HTMLCanvasElement>,
  isActive: boolean
) => {
  const [isModelLoaded, setIsModelLoaded] = useState(false)
  const [modelLoadError, setModelLoadError] = useState<string | null>(null)
  const [phoneDetected, setPhoneDetected] = useState(false)
  const [faceDetected, setFaceDetected] = useState(false)
  const [faceCount, setFaceCount] = useState(0)
  const [detectionStats, setDetectionStats] = useState<DetectionStats | null>(null)
  
  const cocoModelRef = useRef<cocoSsd.ObjectDetection | null>(null)
  const blazefaceModelRef = useRef<blazeface.BlazeFaceModel | null>(null)
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const statsRef = useRef<DetectionStats>({
    phoneDetections: 0,
    faceDetections: 0,
    totalFrames: 0,
    averageConfidence: 0
  })

  // Initialize TensorFlow.js and load models
  useEffect(() => {
    const initializeModels = async () => {
      try {
        setModelLoadError(null)
        
        // Set TensorFlow.js backend with timeout
        console.log('Initializing TensorFlow.js...')
        await Promise.race([
          tf.ready(),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('TensorFlow.js initialization timeout')), 10000)
          )
        ])
        console.log('TensorFlow.js backend:', tf.getBackend())

        // Load models with retry logic and fallback options
        console.log('Loading AI models...')
        
        // Try to load COCO-SSD model with fallback options
        try {
          console.log('Loading COCO-SSD model...')
          const cocoModel = await Promise.race([
            cocoSsd.load({
              base: 'lite_mobilenet_v2' // Use lighter model for better compatibility
            }),
            new Promise<never>((_, reject) => 
              setTimeout(() => reject(new Error('COCO-SSD model loading timeout')), 15000)
            )
          ])
          cocoModelRef.current = cocoModel
          console.log('COCO-SSD model loaded successfully')
        } catch (cocoError) {
          console.warn('Failed to load COCO-SSD model:', cocoError)
          // Continue without object detection
        }

        // Try to load BlazeFace model
        try {
          console.log('Loading BlazeFace model...')
          const faceModel = await Promise.race([
            blazeface.load(),
            new Promise<never>((_, reject) => 
              setTimeout(() => reject(new Error('BlazeFace model loading timeout')), 15000)
            )
          ])
          blazefaceModelRef.current = faceModel
          console.log('BlazeFace model loaded successfully')
        } catch (faceError) {
          console.warn('Failed to load BlazeFace model:', faceError)
          // Continue without face detection
        }

        // Check if at least one model loaded
        if (cocoModelRef.current || blazefaceModelRef.current) {
          setIsModelLoaded(true)
          console.log('AI detection initialized with available models')
        } else {
          throw new Error('No AI models could be loaded. Please check your internet connection and try again.')
        }

      } catch (error) {
        console.error('Error loading AI models:', error)
        setModelLoadError(error instanceof Error ? error.message : 'Unknown error occurred while loading AI models')
        setIsModelLoaded(false)
      }
    }

    initializeModels()

    return () => {
      // Cleanup models
      cocoModelRef.current = null
      blazefaceModelRef.current = null
    }
  }, [])

  // Perform detection on video frame
  const detectObjects = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || !isModelLoaded) return

    const video = videoRef.current
    const canvas = canvasRef.current
    
    // Check if video is ready
    if (video.readyState !== 4) return

    try {
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      
      const ctx = canvas.getContext('2d')
      if (!ctx) return

      // Draw current video frame to canvas
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

      let phoneFound = false
      let totalConfidence = 0
      let detectionCount = 0

      // Object detection for phones and other items (if model is available)
      if (cocoModelRef.current) {
        try {
          const objectPredictions = await cocoModelRef.current.detect(canvas)
          
          objectPredictions.forEach(prediction => {
            const { class: className, score } = prediction
            
            // Check for phones, tablets, laptops, or other prohibited items
            const prohibitedItems = [
              'cell phone', 'mobile phone', 'smartphone',
              'laptop', 'tablet', 'computer', 'monitor',
              'book', 'paper', 'notebook'
            ]
            
            if (prohibitedItems.some(item => 
              className.toLowerCase().includes(item) || 
              className.toLowerCase().includes('phone')
            )) {
              if (score > 0.5) { // Confidence threshold
                phoneFound = true
                statsRef.current.phoneDetections++
              }
            }

            totalConfidence += score
            detectionCount++
          })

          // Draw object detection boxes (for debugging)
          if (process.env.NODE_ENV === 'development') {
            ctx.strokeStyle = '#00ff00'
            ctx.lineWidth = 2
            ctx.font = '16px Arial'
            ctx.fillStyle = '#00ff00'

            objectPredictions.forEach(prediction => {
              const [x, y, width, height] = prediction.bbox
              ctx.strokeRect(x, y, width, height)
              ctx.fillText(
                `${prediction.class} (${Math.round(prediction.score * 100)}%)`,
                x, y > 20 ? y - 5 : y + 20
              )
            })
          }
        } catch (objError) {
          console.warn('Object detection error:', objError)
        }
      }

      // Face detection (if model is available)
      let faces = 0
      if (blazefaceModelRef.current) {
        try {
          const facePredictions = await blazefaceModelRef.current.estimateFaces(canvas, false)
          faces = facePredictions.length

          // Draw face detection boxes (for debugging)
          if (process.env.NODE_ENV === 'development') {
            facePredictions.forEach(prediction => {
              const start = prediction.topLeft as [number, number]
              const end = prediction.bottomRight as [number, number]
              const size = [end[0] - start[0], end[1] - start[1]]
              
              ctx.strokeStyle = '#ff0000'
              ctx.strokeRect(start[0], start[1], size[0], size[1])
              ctx.fillStyle = '#ff0000'
              ctx.fillText('Face', start[0], start[1] > 20 ? start[1] - 5 : start[1] + 20)
            })
          }
        } catch (faceError) {
          console.warn('Face detection error:', faceError)
        }
      }

      const faceFound = faces > 0

      // Update states
      setPhoneDetected(phoneFound)
      setFaceDetected(faceFound)
      setFaceCount(faces)

      // Update stats
      statsRef.current.totalFrames++
      if (faceFound) statsRef.current.faceDetections++
      if (detectionCount > 0) {
        statsRef.current.averageConfidence = totalConfidence / detectionCount
      }

      setDetectionStats({ ...statsRef.current })

    } catch (error) {
      console.error('Detection error:', error)
    }
  }, [videoRef, canvasRef, isModelLoaded])

  // Start detection loop
  const startDetection = useCallback(() => {
    if (!isActive || !isModelLoaded) return

    console.log('Starting AI detection...')
    
    // Clear any existing interval
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current)
    }

    // Start detection loop (every 500ms for performance)
    detectionIntervalRef.current = setInterval(detectObjects, 500)
  }, [isActive, isModelLoaded, detectObjects])

  // Stop detection loop
  const stopDetection = useCallback(() => {
    console.log('Stopping AI detection...')
    
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current)
      detectionIntervalRef.current = null
    }

    // Reset states
    setPhoneDetected(false)
    setFaceDetected(false)
    setFaceCount(0)
  }, [])

  // Auto-start/stop detection based on isActive
  useEffect(() => {
    if (isActive && isModelLoaded) {
      startDetection()
    } else {
      stopDetection()
    }

    return () => {
      stopDetection()
    }
  }, [isActive, isModelLoaded, startDetection, stopDetection])

  return {
    isModelLoaded,
    modelLoadError,
    phoneDetected,
    faceDetected,
    faceCount,
    detectionStats,
    startDetection,
    stopDetection
  }
}