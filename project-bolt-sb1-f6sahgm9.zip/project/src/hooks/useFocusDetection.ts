import { useEffect, useState, useCallback, useRef } from 'react'

export const useFocusDetection = (isActive: boolean) => {
  const [isFocused, setIsFocused] = useState(true)
  const [focusLostCount, setFocusLostCount] = useState(0)
  const [totalFocusTime, setTotalFocusTime] = useState(0)
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null)
  
  const focusTimeRef = useRef(0)
  const lastFocusTime = useRef(Date.now())
  const focusIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Handle window focus/blur events
  const handleFocus = useCallback(() => {
    setIsFocused(true)
    lastFocusTime.current = Date.now()
  }, [])

  const handleBlur = useCallback(() => {
    if (!isActive) return
    
    setIsFocused(false)
    setFocusLostCount(prev => prev + 1)
    
    // Calculate focus time for this session
    const now = Date.now()
    const focusTime = now - lastFocusTime.current
    focusTimeRef.current += focusTime
  }, [isActive])

  // Handle visibility change (tab switching)
  const handleVisibilityChange = useCallback(() => {
    if (!isActive) return
    
    if (document.hidden) {
      handleBlur()
    } else {
      handleFocus()
    }
  }, [isActive, handleBlur, handleFocus])

  // Mouse movement detection for engagement
  const handleMouseMove = useCallback(() => {
    if (!isActive || !isFocused) return
    
    // Update last activity time
    lastFocusTime.current = Date.now()
  }, [isActive, isFocused])

  // Keyboard activity detection
  const handleKeyPress = useCallback(() => {
    if (!isActive || !isFocused) return
    
    // Update last activity time
    lastFocusTime.current = Date.now()
  }, [isActive, isFocused])

  // Start focus tracking
  const startFocusTracking = useCallback(() => {
    if (!isActive) return

    console.log('Starting focus tracking...')
    
    setSessionStartTime(Date.now())
    lastFocusTime.current = Date.now()
    focusTimeRef.current = 0
    setFocusLostCount(0)
    setIsFocused(true)

    // Add event listeners
    window.addEventListener('focus', handleFocus)
    window.addEventListener('blur', handleBlur)
    document.addEventListener('visibilitychange', handleVisibilityChange)
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('keypress', handleKeyPress)

    // Start focus time tracking interval
    focusIntervalRef.current = setInterval(() => {
      if (isFocused) {
        const now = Date.now()
        const timeDiff = now - lastFocusTime.current
        focusTimeRef.current += timeDiff
        lastFocusTime.current = now
        setTotalFocusTime(focusTimeRef.current)
      }
    }, 1000)

  }, [isActive, isFocused, handleFocus, handleBlur, handleVisibilityChange, handleMouseMove, handleKeyPress])

  // Stop focus tracking
  const stopFocusTracking = useCallback(() => {
    console.log('Stopping focus tracking...')
    
    // Remove event listeners
    window.removeEventListener('focus', handleFocus)
    window.removeEventListener('blur', handleBlur)
    document.removeEventListener('visibilitychange', handleVisibilityChange)
    document.removeEventListener('mousemove', handleMouseMove)
    document.removeEventListener('keypress', handleKeyPress)

    // Clear interval
    if (focusIntervalRef.current) {
      clearInterval(focusIntervalRef.current)
      focusIntervalRef.current = null
    }

    // Final focus time calculation
    if (isFocused && sessionStartTime) {
      const now = Date.now()
      const timeDiff = now - lastFocusTime.current
      focusTimeRef.current += timeDiff
      setTotalFocusTime(focusTimeRef.current)
    }

  }, [isFocused, sessionStartTime, handleFocus, handleBlur, handleVisibilityChange, handleMouseMove, handleKeyPress])

  // Auto-start/stop based on isActive
  useEffect(() => {
    if (isActive) {
      startFocusTracking()
    } else {
      stopFocusTracking()
    }

    return () => {
      stopFocusTracking()
    }
  }, [isActive, startFocusTracking, stopFocusTracking])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopFocusTracking()
    }
  }, [stopFocusTracking])

  return {
    isFocused,
    focusLostCount,
    totalFocusTime: Math.floor(totalFocusTime / 1000), // Convert to seconds
    startFocusTracking,
    stopFocusTracking
  }
}