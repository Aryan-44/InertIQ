// AI-powered quiz generation using Gemini API
const GEMINI_API_KEY = "AIzaSyD_7Xl4ZCsIHvW7FuvJwoHICHxO-SmV3vQ"
const GEMINI_MODEL = "gemini-2.0-flash"

export interface QuizQuestion {
  id: string
  type: 'multiple-choice' | 'true-false' | 'short-answer'
  question: string
  options?: string[]
  correctAnswer: string | number
  explanation: string
  difficulty: 'easy' | 'medium' | 'hard'
  topic: string
}

export interface QuizResult {
  score: number
  totalQuestions: number
  percentage: number
  performance: 'excellent' | 'good' | 'average' | 'weak'
  weakAreas: string[]
  recommendations: string[]
}

export class AIQuizGenerator {
  static async generateQuizForTopic(
    topic: string, 
    content: string, 
    difficulty: 'easy' | 'medium' | 'hard' = 'medium',
    questionCount: number = 5
  ): Promise<QuizQuestion[]> {
    try {
      const prompt = `
        Based on the following content about "${topic}", generate ${questionCount} quiz questions with varying types (multiple choice, true/false, short answer).
        
        Content: ${content.substring(0, 1500)}
        
        Requirements:
        - Difficulty level: ${difficulty}
        - Include ${Math.ceil(questionCount * 0.6)} multiple choice questions (4 options each)
        - Include ${Math.floor(questionCount * 0.3)} true/false questions
        - Include ${Math.floor(questionCount * 0.1)} short answer questions
        - Each question should test understanding of key concepts
        - Provide clear explanations for correct answers
        - Make questions specific to the content provided
        
        Format your response as a JSON array with this structure:
        [
          {
            "type": "multiple-choice",
            "question": "Question text here?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 0,
            "explanation": "Explanation of why this is correct",
            "difficulty": "${difficulty}"
          },
          {
            "type": "true-false",
            "question": "Statement to evaluate",
            "correctAnswer": true,
            "explanation": "Explanation",
            "difficulty": "${difficulty}"
          }
        ]
        
        Only return the JSON array, no additional text.
      `

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048,
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`)
      }

      const data = await response.json()
      const aiResponse = data?.candidates?.[0]?.content?.parts?.[0]?.text

      if (!aiResponse) {
        throw new Error('No response from AI')
      }

      // Parse the JSON response
      let questions: any[]
      try {
        // Clean the response to extract JSON
        const jsonMatch = aiResponse.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          questions = JSON.parse(jsonMatch[0])
        } else {
          throw new Error('Invalid JSON format')
        }
      } catch (parseError) {
        console.error('Failed to parse AI response:', parseError)
        // Fallback to generated questions
        questions = this.generateFallbackQuestions(topic, difficulty, questionCount)
      }

      // Convert to our QuizQuestion format
      return questions.map((q, index) => ({
        id: `${topic}-${Date.now()}-${index}`,
        type: q.type,
        question: q.question,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        difficulty: q.difficulty || difficulty,
        topic: topic
      }))

    } catch (error) {
      console.error('Error generating quiz:', error)
      // Return fallback questions
      return this.generateFallbackQuestions(topic, difficulty, questionCount)
    }
  }

  static generateFallbackQuestions(topic: string, difficulty: string, count: number): QuizQuestion[] {
    const fallbackQuestions: QuizQuestion[] = [
      {
        id: `fallback-1-${Date.now()}`,
        type: 'multiple-choice',
        question: `What is the main focus of ${topic}?`,
        options: [
          'Understanding core concepts',
          'Memorizing definitions',
          'Practical applications only',
          'Historical context only'
        ],
        correctAnswer: 0,
        explanation: 'The main focus is understanding core concepts which forms the foundation for practical application.',
        difficulty: difficulty as any,
        topic: topic
      },
      {
        id: `fallback-2-${Date.now()}`,
        type: 'true-false',
        question: `${topic} involves both theoretical understanding and practical application.`,
        correctAnswer: true,
        explanation: 'Most academic topics require both theoretical knowledge and practical application for complete understanding.',
        difficulty: difficulty as any,
        topic: topic
      },
      {
        id: `fallback-3-${Date.now()}`,
        type: 'multiple-choice',
        question: `Which approach is most effective when studying ${topic}?`,
        options: [
          'Reading only',
          'Practice only',
          'Combining theory and practice',
          'Memorization only'
        ],
        correctAnswer: 2,
        explanation: 'Combining theoretical understanding with practical application provides the most comprehensive learning experience.',
        difficulty: difficulty as any,
        topic: topic
      }
    ]

    return fallbackQuestions.slice(0, count)
  }

  static evaluateQuizResults(
    questions: QuizQuestion[], 
    userAnswers: (string | number | boolean)[]
  ): QuizResult {
    let correctAnswers = 0
    const weakAreas: string[] = []

    questions.forEach((question, index) => {
      const userAnswer = userAnswers[index]
      const isCorrect = userAnswer === question.correctAnswer

      if (isCorrect) {
        correctAnswers++
      } else {
        weakAreas.push(question.topic)
      }
    })

    const percentage = Math.round((correctAnswers / questions.length) * 100)
    
    let performance: 'excellent' | 'good' | 'average' | 'weak'
    if (percentage >= 90) performance = 'excellent'
    else if (percentage >= 75) performance = 'good'
    else if (percentage >= 60) performance = 'average'
    else performance = 'weak'

    const recommendations = this.generateRecommendations(performance, weakAreas)

    return {
      score: correctAnswers,
      totalQuestions: questions.length,
      percentage,
      performance,
      weakAreas: [...new Set(weakAreas)],
      recommendations
    }
  }

  static generateRecommendations(
    performance: 'excellent' | 'good' | 'average' | 'weak',
    weakAreas: string[]
  ): string[] {
    const recommendations: string[] = []

    switch (performance) {
      case 'excellent':
        recommendations.push('Outstanding performance! Consider exploring advanced topics.')
        recommendations.push('Share your knowledge by helping others or creating study materials.')
        break
      case 'good':
        recommendations.push('Great job! Review any missed questions to strengthen understanding.')
        recommendations.push('Try more challenging questions to push your knowledge further.')
        break
      case 'average':
        recommendations.push('Good effort! Focus on reviewing the fundamental concepts.')
        recommendations.push('Practice more questions in your weak areas.')
        break
      case 'weak':
        recommendations.push('Consider reviewing the study material more thoroughly.')
        recommendations.push('Break down complex topics into smaller, manageable sections.')
        recommendations.push('Seek additional resources or help for better understanding.')
        break
    }

    if (weakAreas.length > 0) {
      recommendations.push(`Focus extra attention on: ${weakAreas.join(', ')}`)
    }

    return recommendations
  }

  static async regenerateSimplifiedContent(
    topic: string, 
    originalContent: string
  ): Promise<string> {
    try {
      const prompt = `
        The user scored poorly on a quiz about "${topic}". Please create a simplified, easy-to-understand explanation of this topic based on the original content below.
        
        Original content: ${originalContent.substring(0, 1000)}
        
        Requirements:
        - Use simple, clear language
        - Break down complex concepts into basic terms
        - Include practical examples
        - Structure with clear headings and bullet points
        - Focus on the most important concepts
        - Make it engaging and easy to follow
        
        Create a comprehensive but simplified study guide for this topic.
      `

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.8,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1500,
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`)
      }

      const data = await response.json()
      const simplifiedContent = data?.candidates?.[0]?.content?.parts?.[0]?.text

      return simplifiedContent || originalContent
    } catch (error) {
      console.error('Error regenerating content:', error)
      return originalContent
    }
  }
}