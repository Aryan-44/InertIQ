import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Brain, Clock, CheckCircle, XCircle, RotateCcw, Play, Trophy, Zap, Target, AlertCircle } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import { AIQuizGenerator, QuizQuestion, QuizResult } from '../utils/aiQuizGenerator'

export const SmartQuizModule: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | number | boolean | null>(null)
  const [userAnswers, setUserAnswers] = useState<(string | number | boolean)[]>([])
  const [showResult, setShowResult] = useState(false)
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes
  const [showExplanation, setShowExplanation] = useState(false)
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false)
  const [regeneratedContent, setRegeneratedContent] = useState<string | null>(null)
  
  const { 
    isDarkMode, 
    addXP, 
    currentQuiz, 
    isQuizActive, 
    setCurrentQuiz, 
    setIsQuizActive,
    pdfContent,
    pdfTopics
  } = useAppStore()

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (isQuizActive && timeLeft > 0 && !showResult && currentQuiz.length > 0) {
      timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0 && isQuizActive) {
      handleQuizComplete()
    }
    return () => clearTimeout(timer)
  }, [isQuizActive, timeLeft, showResult, currentQuiz.length])

  const handleAnswerSelect = (answer: string | number | boolean) => {
    if (selectedAnswer !== null) return
    
    setSelectedAnswer(answer)
    setShowExplanation(true)
    
    const newAnswers = [...userAnswers]
    newAnswers[currentQuestion] = answer
    setUserAnswers(newAnswers)
    
    // Award XP for answering
    if (answer === currentQuiz[currentQuestion].correctAnswer) {
      addXP(20) // Correct answer
    } else {
      addXP(5) // Participation
    }
    
    setTimeout(() => {
      if (currentQuestion < currentQuiz.length - 1) {
        setCurrentQuestion(currentQuestion + 1)
        setSelectedAnswer(null)
        setShowExplanation(false)
      } else {
        handleQuizComplete()
      }
    }, 3000)
  }

  const handleQuizComplete = () => {
    const result = AIQuizGenerator.evaluateQuizResults(currentQuiz, userAnswers)
    setQuizResult(result)
    setShowResult(true)
    setIsQuizActive(false)
    
    // Award completion XP
    addXP(50 + (result.percentage * 2)) // Base + performance bonus
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setUserAnswers([])
    setShowResult(false)
    setQuizResult(null)
    setTimeLeft(300)
    setShowExplanation(false)
    setCurrentQuiz([])
    setIsQuizActive(false)
    setRegeneratedContent(null)
  }

  const generateRandomQuiz = async () => {
    if (pdfTopics.length === 0) return
    
    setIsGeneratingQuiz(true)
    
    try {
      const randomTopic = pdfTopics[Math.floor(Math.random() * pdfTopics.length)]
      const questions = await AIQuizGenerator.generateQuizForTopic(
        randomTopic,
        pdfContent || `Study material for ${randomTopic}`,
        'medium',
        5
      )
      
      setCurrentQuiz(questions)
      setIsQuizActive(true)
      setCurrentQuestion(0)
      setUserAnswers([])
      setTimeLeft(300)
      setIsGeneratingQuiz(false)
    } catch (error) {
      console.error('Error generating quiz:', error)
      setIsGeneratingQuiz(false)
    }
  }

  const handleRegenerateContent = async () => {
    if (!quizResult || !currentQuiz[0]) return
    
    try {
      const topic = currentQuiz[0].topic
      const simplified = await AIQuizGenerator.regenerateSimplifiedContent(
        topic,
        pdfContent || `Study material for ${topic}`
      )
      setRegeneratedContent(simplified)
    } catch (error) {
      console.error('Error regenerating content:', error)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // Start screen
  if (!isQuizActive && currentQuiz.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`rounded-3xl p-6 sm:p-8 text-center ${
          isDarkMode 
            ? 'bg-gray-800/50 border border-gray-700/50' 
            : 'bg-white/80 border border-gray-200/50'
        }`}
        style={{
          boxShadow: isDarkMode 
            ? '0 25px 50px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
            : '0 25px 50px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(20px)'
        }}
      >
        <motion.div
          animate={{ 
            rotate: [0, 5, -5, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            repeatDelay: 3
          }}
          className={`mx-auto mb-6 w-20 h-20 rounded-3xl flex items-center justify-center ${
            isDarkMode ? 'bg-gradient-to-br from-purple-500 to-pink-600' : 'bg-gradient-to-br from-purple-400 to-pink-500'
          }`}
          style={{
            boxShadow: '0 12px 40px rgba(168, 85, 247, 0.4)'
          }}
        >
          <Brain className="h-10 w-10 text-white" />
        </motion.div>
        
        <h2 className={`text-3xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          Smart Quiz System
        </h2>
        
        <p className={`text-lg mb-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
          AI-powered adaptive learning with personalized feedback
        </p>
        
        <div className={`mb-8 p-6 rounded-2xl ${
          isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
        }`}>
          <div className="grid grid-cols-3 gap-6 text-center">
            <div>
              <motion.p 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2 }}
                className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
              >
                AI
              </motion.p>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Generated
              </p>
            </div>
            <div>
              <motion.p 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3 }}
                className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
              >
                5:00
              </motion.p>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Time Limit
              </p>
            </div>
            <div>
              <motion.p 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.4 }}
                className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
              >
                Smart
              </motion.p>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Adaptive
              </p>
            </div>
          </div>
        </div>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={generateRandomQuiz}
          disabled={isGeneratingQuiz || pdfTopics.length === 0}
          className={`px-10 py-4 rounded-2xl font-bold text-lg transition-all duration-200 ${
            isGeneratingQuiz || pdfTopics.length === 0
              ? 'opacity-50 cursor-not-allowed'
              : isDarkMode 
                ? 'bg-gradient-to-br from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white'
                : 'bg-gradient-to-br from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white'
          }`}
          style={{
            boxShadow: !isGeneratingQuiz && pdfTopics.length > 0 ? '0 12px 40px rgba(168, 85, 247, 0.4)' : 'none'
          }}
        >
          {isGeneratingQuiz ? (
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
              />
              <span>Generating Quiz...</span>
            </div>
          ) : pdfTopics.length === 0 ? (
            <div className="flex items-center space-x-3">
              <AlertCircle className="h-5 w-5" />
              <span>Upload PDF First</span>
            </div>
          ) : (
            <div className="flex items-center space-x-3">
              <Play className="h-6 w-6" />
              <span>Start Smart Quiz</span>
            </div>
          )}
        </motion.button>

        {pdfTopics.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className={`mt-6 p-4 rounded-2xl ${
              isDarkMode ? 'bg-blue-500/10 border border-blue-400/30' : 'bg-blue-50 border border-blue-200'
            }`}
          >
            <p className={`text-sm ${isDarkMode ? 'text-blue-300' : 'text-blue-700'}`}>
              💡 Upload a PDF document to unlock AI-powered quiz generation
            </p>
          </motion.div>
        )}
      </motion.div>
    )
  }

  // Results screen
  if (showResult && quizResult) {
    const percentage = quizResult.percentage
    
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`rounded-3xl p-6 sm:p-8 ${
          isDarkMode 
            ? 'bg-gray-800/50 border border-gray-700/50' 
            : 'bg-white/80 border border-gray-200/50'
        }`}
        style={{
          boxShadow: isDarkMode 
            ? '0 25px 50px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
            : '0 25px 50px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(20px)'
        }}
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className={`mx-auto mb-6 w-24 h-24 rounded-3xl flex items-center justify-center ${
              percentage >= 80 
                ? 'bg-gradient-to-br from-green-500 to-emerald-600' 
                : percentage >= 60
                  ? 'bg-gradient-to-br from-yellow-500 to-orange-600'
                  : 'bg-gradient-to-br from-red-500 to-pink-600'
            }`}
            style={{
              boxShadow: percentage >= 80 
                ? '0 12px 40px rgba(34, 197, 94, 0.4)'
                : percentage >= 60
                  ? '0 12px 40px rgba(251, 146, 60, 0.4)'
                  : '0 12px 40px rgba(239, 68, 68, 0.4)'
            }}
          >
            {percentage >= 80 ? 
              <Trophy className="h-12 w-12 text-white" /> :
              percentage >= 60 ?
              <Zap className="h-12 w-12 text-white" /> :
              <Target className="h-12 w-12 text-white" />
            }
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className={`text-4xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
          >
            {percentage}%
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className={`text-xl mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}
          >
            {quizResult.performance === 'excellent' ? 'Outstanding! 🎉' : 
             quizResult.performance === 'good' ? 'Great job! 👏' : 
             quizResult.performance === 'average' ? 'Good effort! 👍' : 'Keep practicing! 💪'}
          </motion.p>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className={`text-lg mb-8 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
          >
            You scored {quizResult.score} out of {quizResult.totalQuestions} questions
          </motion.p>
        </div>

        {/* Performance Analysis */}
        <div className="space-y-6 mb-8">
          {/* Recommendations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className={`p-6 rounded-2xl ${
              isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
            }`}
          >
            <h3 className={`text-lg font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Personalized Recommendations
            </h3>
            <div className="space-y-3">
              {quizResult.recommendations.map((rec, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-start space-x-3"
                >
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    percentage >= 80 ? 'bg-green-500' :
                    percentage >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                  }`} />
                  <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {rec}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Weak Areas & Content Regeneration */}
          {quizResult.performance === 'weak' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className={`p-6 rounded-2xl ${
                isDarkMode ? 'bg-red-500/10 border border-red-400/30' : 'bg-red-50 border border-red-200'
              }`}
            >
              <h3 className={`text-lg font-bold mb-4 ${isDarkMode ? 'text-red-300' : 'text-red-700'}`}>
                Adaptive Learning Activated
              </h3>
              <p className={`text-sm mb-4 ${isDarkMode ? 'text-red-200' : 'text-red-600'}`}>
                Based on your performance, we've identified areas that need more attention. 
                Would you like simplified study material?
              </p>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleRegenerateContent}
                className={`px-4 py-2 rounded-xl font-medium text-sm transition-all duration-200 ${
                  isDarkMode 
                    ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30'
                    : 'bg-red-100 text-red-700 hover:bg-red-200'
                }`}
              >
                Generate Simplified Content
              </motion.button>

              {regeneratedContent && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className={`mt-4 p-4 rounded-xl ${
                    isDarkMode ? 'bg-gray-700/30' : 'bg-white/50'
                  }`}
                >
                  <h4 className={`font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Simplified Study Guide
                  </h4>
                  <div className={`text-sm leading-relaxed ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {regeneratedContent.split('\n').map((line, index) => (
                      <p key={index} className="mb-2">{line}</p>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={resetQuiz}
            className={`flex-1 px-6 py-4 rounded-2xl font-bold transition-all duration-200 ${
              isDarkMode 
                ? 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white'
                : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white'
            }`}
            style={{
              boxShadow: '0 12px 40px rgba(59, 130, 246, 0.4)'
            }}
          >
            <div className="flex items-center justify-center space-x-2">
              <RotateCcw className="h-5 w-5" />
              <span>Try Another Quiz</span>
            </div>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={generateRandomQuiz}
            disabled={isGeneratingQuiz}
            className={`flex-1 px-6 py-4 rounded-2xl font-bold transition-all duration-200 ${
              isGeneratingQuiz
                ? 'opacity-50 cursor-not-allowed'
                : isDarkMode 
                  ? 'bg-gradient-to-br from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white'
                  : 'bg-gradient-to-br from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white'
            }`}
            style={{
              boxShadow: !isGeneratingQuiz ? '0 12px 40px rgba(34, 197, 94, 0.4)' : 'none'
            }}
          >
            <div className="flex items-center justify-center space-x-2">
              <Play className="h-5 w-5" />
              <span>New Topic Quiz</span>
            </div>
          </motion.button>
        </div>
      </motion.div>
    )
  }

  // Quiz in progress
  if (currentQuiz.length > 0) {
    const question = currentQuiz[currentQuestion]

    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className={`rounded-3xl overflow-hidden ${
          isDarkMode 
            ? 'bg-gray-800/50 border border-gray-700/50' 
            : 'bg-white/80 border border-gray-200/50'
        }`}
        style={{
          boxShadow: isDarkMode 
            ? '0 25px 50px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
            : '0 25px 50px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(20px)'
        }}
      >
        {/* Header */}
        <div className={`p-6 border-b ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Brain className={`h-6 w-6 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <span className={`font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Question {currentQuestion + 1} of {currentQuiz.length}
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Clock className={`h-4 w-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
              <span className={`font-mono font-bold ${
                timeLeft < 60 ? 'text-red-500' : isDarkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className={`w-full h-3 rounded-full overflow-hidden ${
            isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
          }`}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${((currentQuestion + 1) / currentQuiz.length) * 100}%` }}
              transition={{ duration: 0.5 }}
              className={`h-full rounded-full ${
                isDarkMode 
                  ? 'bg-gradient-to-r from-purple-400 to-pink-500' 
                  : 'bg-gradient-to-r from-purple-500 to-pink-600'
              }`}
              style={{
                boxShadow: '0 0 20px rgba(168, 85, 247, 0.5)'
              }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="p-6">
          <motion.h3
            key={currentQuestion}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-xl font-bold mb-8 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
          >
            {question.question}
          </motion.h3>

          {/* Answer Options */}
          <div className="space-y-4">
            <AnimatePresence mode="wait">
              {question.type === 'multiple-choice' && question.options ? (
                question.options.map((option, index) => (
                  <motion.button
                    key={`${currentQuestion}-${index}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: selectedAnswer === null ? 1.02 : 1 }}
                    whileTap={{ scale: selectedAnswer === null ? 0.98 : 1 }}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={selectedAnswer !== null}
                    className={`w-full p-4 rounded-2xl text-left transition-all duration-300 ${
                      selectedAnswer === null
                        ? isDarkMode
                          ? 'bg-gray-700/30 hover:bg-gray-700/50 text-gray-300 border border-gray-600/50'
                          : 'bg-gray-50/80 hover:bg-gray-100/80 text-gray-700 border border-gray-200/50'
                        : selectedAnswer === index
                          ? index === question.correctAnswer
                            ? 'bg-green-500/20 border border-green-500/50 text-green-600'
                            : 'bg-red-500/20 border border-red-500/50 text-red-600'
                          : index === question.correctAnswer
                            ? 'bg-green-500/20 border border-green-500/50 text-green-600'
                            : isDarkMode
                              ? 'bg-gray-700/10 text-gray-500 border border-gray-600/30'
                              : 'bg-gray-50/50 text-gray-400 border border-gray-200/30'
                    }`}
                    style={selectedAnswer === index ? {
                      boxShadow: index === question.correctAnswer
                        ? '0 8px 30px rgba(34, 197, 94, 0.3)'
                        : '0 8px 30px rgba(239, 68, 68, 0.3)'
                    } : {}}
                  >
                    <div className="flex items-center space-x-4">
                      <motion.div
                        animate={selectedAnswer === index ? {
                          scale: [1, 1.2, 1],
                          rotate: [0, 180, 360]
                        } : {}}
                        transition={{ duration: 0.5 }}
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                          selectedAnswer === null
                            ? isDarkMode ? 'border-gray-500' : 'border-gray-400'
                            : selectedAnswer === index
                              ? index === question.correctAnswer
                                ? 'border-green-500 bg-green-500'
                                : 'border-red-500 bg-red-500'
                              : index === question.correctAnswer
                                ? 'border-green-500 bg-green-500'
                                : isDarkMode ? 'border-gray-600' : 'border-gray-300'
                        }`}
                      >
                        {selectedAnswer !== null && (
                          (selectedAnswer === index && index === question.correctAnswer) ||
                          (selectedAnswer !== index && index === question.correctAnswer)
                        ) && (
                          <CheckCircle className="h-5 w-5 text-white" />
                        )}
                        {selectedAnswer === index && index !== question.correctAnswer && (
                          <XCircle className="h-5 w-5 text-white" />
                        )}
                      </motion.div>
                      
                      <span className="flex-1 font-medium">{option}</span>
                    </div>
                  </motion.button>
                ))
              ) : question.type === 'true-false' ? (
                ['True', 'False'].map((option, index) => (
                  <motion.button
                    key={`${currentQuestion}-${index}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: selectedAnswer === null ? 1.02 : 1 }}
                    whileTap={{ scale: selectedAnswer === null ? 0.98 : 1 }}
                    onClick={() => handleAnswerSelect(index === 0)}
                    disabled={selectedAnswer !== null}
                    className={`w-full p-4 rounded-2xl text-left transition-all duration-300 ${
                      selectedAnswer === null
                        ? isDarkMode
                          ? 'bg-gray-700/30 hover:bg-gray-700/50 text-gray-300 border border-gray-600/50'
                          : 'bg-gray-50/80 hover:bg-gray-100/80 text-gray-700 border border-gray-200/50'
                        : selectedAnswer === (index === 0)
                          ? (index === 0) === question.correctAnswer
                            ? 'bg-green-500/20 border border-green-500/50 text-green-600'
                            : 'bg-red-500/20 border border-red-500/50 text-red-600'
                          : (index === 0) === question.correctAnswer
                            ? 'bg-green-500/20 border border-green-500/50 text-green-600'
                            : isDarkMode
                              ? 'bg-gray-700/10 text-gray-500 border border-gray-600/30'
                              : 'bg-gray-50/50 text-gray-400 border border-gray-200/30'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <motion.div
                        animate={selectedAnswer === (index === 0) ? {
                          scale: [1, 1.2, 1],
                          rotate: [0, 180, 360]
                        } : {}}
                        transition={{ duration: 0.5 }}
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                          selectedAnswer === null
                            ? isDarkMode ? 'border-gray-500' : 'border-gray-400'
                            : selectedAnswer === (index === 0)
                              ? (index === 0) === question.correctAnswer
                                ? 'border-green-500 bg-green-500'
                                : 'border-red-500 bg-red-500'
                              : (index === 0) === question.correctAnswer
                                ? 'border-green-500 bg-green-500'
                                : isDarkMode ? 'border-gray-600' : 'border-gray-300'
                        }`}
                      >
                        {selectedAnswer !== null && (
                          (selectedAnswer === (index === 0) && (index === 0) === question.correctAnswer) ||
                          (selectedAnswer !== (index === 0) && (index === 0) === question.correctAnswer)
                        ) && (
                          <CheckCircle className="h-5 w-5 text-white" />
                        )}
                        {selectedAnswer === (index === 0) && (index === 0) !== question.correctAnswer && (
                          <XCircle className="h-5 w-5 text-white" />
                        )}
                      </motion.div>
                      
                      <span className="flex-1 font-medium">{option}</span>
                    </div>
                  </motion.button>
                ))
              ) : null}
            </AnimatePresence>
          </div>

          {/* Explanation */}
          <AnimatePresence>
            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className={`mt-8 p-6 rounded-2xl ${
                  isDarkMode ? 'bg-blue-500/10 border border-blue-400/30' : 'bg-blue-50/80 border border-blue-200/50'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <Brain className={`h-5 w-5 mt-1 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                  <div>
                    <h4 className={`font-bold mb-2 ${isDarkMode ? 'text-blue-300' : 'text-blue-800'}`}>
                      Explanation
                    </h4>
                    <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-blue-200' : 'text-blue-700'}`}>
                      {question.explanation}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    )
  }

  return null
}