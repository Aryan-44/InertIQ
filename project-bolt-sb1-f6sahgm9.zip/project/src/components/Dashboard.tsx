import React, { useEffect, useRef } from 'react'
import { motion, useScroll, useTransform, useSpring } from 'framer-motion'
import { Camera, Sparkles, TrendingUp, Users, BookOpen, Zap, Target, Award, Brain, Rocket, Star, Globe } from 'lucide-react'
import { PDFDropZone } from './PDFDropZone'
import { ChatAssistant } from './ChatAssistant'
import { StudyStreak } from './StudyStreak'
import { QuizModule } from './QuizModule'
import { TopicViewer } from './TopicViewer'
import { SettingsPanel } from './SettingsPanel'
import { useAppStore } from '../store/useAppStore'

export const Dashboard: React.FC = () => {
  const { isDarkMode, setIsWebcamOpen, user, totalXP, studyStreak, messages, level, dailyXP } = useAppStore()
  const containerRef = useRef<HTMLDivElement>(null)
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  })

  const y = useTransform(scrollYProgress, [0, 1], [0, -30])
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.9])
  
  const springConfig = { stiffness: 100, damping: 30, restDelta: 0.001 }
  const ySpring = useSpring(y, springConfig)

  // Dynamic stats based on actual user activity
  const stats = [
    { 
      label: 'Documents Analyzed', 
      value: '0',
      color: 'blue', 
      icon: BookOpen,
      gradient: 'from-blue-500 to-cyan-500',
      description: 'PDFs processed with AI'
    },
    { 
      label: 'Questions Answered', 
      value: messages.filter(m => m.isUser).length.toString(), 
      color: 'green', 
      icon: Sparkles,
      gradient: 'from-green-500 to-emerald-500',
      description: 'Interactive conversations'
    },
    { 
      label: 'Total XP Earned', 
      value: totalXP.toString(), 
      color: 'purple', 
      icon: TrendingUp,
      gradient: 'from-purple-500 to-pink-500',
      description: 'Learning achievements'
    },
    { 
      label: 'Study Streak', 
      value: `${studyStreak} days`, 
      color: 'orange', 
      icon: Users,
      gradient: 'from-orange-500 to-red-500',
      description: 'Consecutive learning days'
    }
  ]

  return (
    <div ref={containerRef} className="w-full min-h-screen overflow-x-hidden">
      {/* Enhanced Hero Section - Fully Responsive */}
      <motion.section
        style={{ y: ySpring, opacity }}
        className="w-full px-2 sm:px-4 md:px-6 lg:px-8 xl:px-12 pt-4 sm:pt-6 lg:pt-8 pb-6 sm:pb-8 lg:pb-12 relative overflow-hidden"
      >
        {/* Floating Elements Background - Responsive */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(4)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                x: [0, Math.sin(i) * 15, 0],
                rotate: [0, 180],
                scale: [1, 1.05, 1]
              }}
              transition={{
                duration: 6 + i * 2,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 1.5
              }}
              className={`absolute w-8 h-8 sm:w-12 sm:h-12 lg:w-16 lg:h-16 rounded-full opacity-5 ${
                isDarkMode ? 'bg-blue-400' : 'bg-blue-500'
              }`}
              style={{
                left: `${15 + i * 20}%`,
                top: `${25 + (i % 2) * 40}%`,
                filter: 'blur(8px)'
              }}
            />
          ))}
        </div>

        <div className="w-full max-w-none relative z-10">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 xl:gap-12 items-start">
            {/* Welcome Content - Responsive Typography */}
            <div className="xl:col-span-2 space-y-4 sm:space-y-6 lg:space-y-8 min-w-0">
              <motion.div
                initial={{ x: -40, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.8, ease: "easeOut" }}
                className="min-w-0"
              >
                <motion.h1 
                  className={`text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold mb-3 sm:mb-4 lg:mb-6 leading-tight break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 0.8 }}
                >
                  Welcome back{user?.name ? `, ${user.name}` : ''}! 
                  <motion.span
                    animate={{ 
                      rotate: [0, 15, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: Infinity, 
                      repeatDelay: 3,
                      ease: "easeInOut"
                    }}
                    className="inline-block ml-2"
                  >
                    👋
                  </motion.span>
                </motion.h1>
                
                <motion.p 
                  className={`text-base sm:text-lg md:text-xl lg:text-2xl mb-4 sm:mb-6 lg:mb-8 leading-relaxed break-words ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                >
                  Ready to{' '}
                  <motion.span
                    animate={{ 
                      backgroundPosition: ['0%', '100%', '0%']
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent bg-300% font-bold"
                  >
                    supercharge
                  </motion.span>
                  {' '}your learning today?
                </motion.p>
              </motion.div>

              {/* Enhanced Quick Stats Cards - Responsive Grid */}
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7, duration: 0.8 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 lg:gap-6"
              >
                <motion.div 
                  whileHover={{ 
                    scale: 1.02, 
                    y: -5
                  }}
                  className={`p-3 sm:p-4 lg:p-6 rounded-xl sm:rounded-2xl magnetic-hover smooth-transition min-w-0 ${
                    isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
                  }`}
                  style={{
                    boxShadow: isDarkMode 
                      ? '0 10px 30px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                      : '0 10px 30px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                    backdropFilter: 'blur(16px)'
                  }}
                >
                  <div className="flex items-center space-x-3 sm:space-x-4 min-w-0">
                    <motion.div 
                      whileHover={{ 
                        rotate: 180,
                        scale: 1.1
                      }}
                      transition={{ duration: 0.6 }}
                      className="w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0"
                      style={{ boxShadow: '0 8px 25px rgba(168, 85, 247, 0.4)' }}
                    >
                      <Award className="h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7 text-white" />
                    </motion.div>
                    <div className="min-w-0 flex-1">
                      <motion.p 
                        className={`text-xl sm:text-2xl lg:text-3xl font-bold break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.8, type: "spring", stiffness: 200 }}
                      >
                        Level {level}
                      </motion.p>
                      <p className={`text-xs sm:text-sm lg:text-base break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Current Level
                      </p>
                    </div>
                  </div>
                </motion.div>

                <motion.div 
                  whileHover={{ 
                    scale: 1.02, 
                    y: -5
                  }}
                  className={`p-3 sm:p-4 lg:p-6 rounded-xl sm:rounded-2xl magnetic-hover smooth-transition min-w-0 ${
                    isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
                  }`}
                  style={{
                    boxShadow: isDarkMode 
                      ? '0 10px 30px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                      : '0 10px 30px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                    backdropFilter: 'blur(16px)'
                  }}
                >
                  <div className="flex items-center space-x-3 sm:space-x-4 min-w-0">
                    <motion.div 
                      whileHover={{ 
                        rotate: 180,
                        scale: 1.1
                      }}
                      transition={{ duration: 0.6 }}
                      className="w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0"
                      style={{ boxShadow: '0 8px 25px rgba(59, 130, 246, 0.4)' }}
                    >
                      <Zap className="h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7 text-white" />
                    </motion.div>
                    <div className="min-w-0 flex-1">
                      <motion.p 
                        className={`text-xl sm:text-2xl lg:text-3xl font-bold break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.9, type: "spring", stiffness: 200 }}
                      >
                        {dailyXP}
                      </motion.p>
                      <p className={`text-xs sm:text-sm lg:text-base break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Daily XP
                      </p>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            </div>

            {/* Enhanced Quick Actions Panel - Responsive */}
            <motion.div
              initial={{ x: 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className={`p-4 sm:p-6 lg:p-8 rounded-xl sm:rounded-2xl magnetic-hover min-w-0 ${
                isDarkMode 
                  ? 'bg-gray-800/50 border border-gray-700/50' 
                  : 'bg-white/80 border border-gray-200/50'
              }`}
              style={{
                boxShadow: isDarkMode 
                  ? '0 20px 40px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                  : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                backdropFilter: 'blur(16px)'
              }}
            >
              <h3 className={`text-lg sm:text-xl lg:text-2xl font-bold mb-4 sm:mb-6 lg:mb-8 break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Quick Actions
              </h3>
              
              <div className="space-y-3 sm:space-y-4 lg:space-y-6">
                {[
                  {
                    icon: Camera,
                    title: "Enable Webcam",
                    description: "Start AI-powered video learning",
                    gradient: "from-green-500 to-emerald-500",
                    action: () => setIsWebcamOpen(true)
                  },
                  {
                    icon: Brain,
                    title: "Smart Quiz",
                    description: "AI-generated adaptive questions",
                    gradient: "from-purple-500 to-pink-500",
                    action: () => {}
                  },
                  {
                    icon: Target,
                    title: "Learning Goals",
                    description: "Set personalized objectives",
                    gradient: "from-blue-500 to-cyan-500",
                    action: () => {}
                  }
                ].map((item, index) => (
                  <motion.button
                    key={item.title}
                    whileHover={{ 
                      scale: 1.02, 
                      x: 8
                    }}
                    whileTap={{ scale: 0.98 }}
                    onClick={item.action}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.9 + index * 0.1, duration: 0.6 }}
                    className={`w-full p-3 sm:p-4 lg:p-5 rounded-lg sm:rounded-xl text-left transition-all duration-300 btn-hover min-w-0 ${
                      isDarkMode 
                        ? 'bg-gray-700/30 hover:bg-gray-700/50 text-gray-300 border border-gray-600/30' 
                        : 'bg-gray-50/80 hover:bg-gray-100/80 text-gray-700 border border-gray-200/50'
                    }`}
                  >
                    <div className="flex items-center space-x-3 sm:space-x-4 lg:space-x-5 min-w-0">
                      <motion.div 
                        whileHover={{ 
                          rotate: 360,
                          scale: 1.1
                        }}
                        transition={{ duration: 0.6 }}
                        className={`w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-lg sm:rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center flex-shrink-0`}
                        style={{ boxShadow: '0 8px 25px rgba(0, 0, 0, 0.2)' }}
                      >
                        <item.icon className="h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7 text-white" />
                      </motion.div>
                      <div className="flex-1 min-w-0">
                        <span className="font-semibold text-sm sm:text-base lg:text-lg xl:text-xl block mb-1 break-words">{item.title}</span>
                        <p className={`text-xs sm:text-sm lg:text-base break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {item.description}
                        </p>
                      </div>
                      <motion.div
                        whileHover={{ x: 4 }}
                        className="text-lg sm:text-xl flex-shrink-0"
                      >
                        →
                      </motion.div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Enhanced Main Content Grid - Fully Responsive Layout */}
      <section className="w-full px-2 sm:px-4 md:px-6 lg:px-8 xl:px-12 pb-6 sm:pb-8 lg:pb-12">
        <div className="w-full max-w-none">
          
          {/* Mobile Layout (< lg) - Single Column */}
          <div className="lg:hidden space-y-6 sm:space-y-8">
            {[
              { component: <PDFDropZone />, delay: 0.1 },
              { component: <ChatAssistant />, delay: 0.2, height: "h-[400px] sm:h-[500px] md:h-[600px]" },
              { component: <StudyStreak />, delay: 0.3 },
              { component: <TopicViewer />, delay: 0.4 },
              { component: <QuizModule />, delay: 0.5 },
              { component: <SettingsPanel />, delay: 0.6 }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: item.delay, duration: 0.6, ease: "easeOut" }}
                className={`${item.height || ""} min-w-0`}
              >
                {item.component}
              </motion.div>
            ))}
          </div>

          {/* Desktop Layout (>= lg) - Advanced Grid System */}
          <div className="hidden lg:block">
            {/* Primary Grid - Responsive Column Layout */}
            <div className="grid grid-cols-12 gap-6 xl:gap-8 2xl:gap-10 mb-8 lg:mb-12 xl:mb-16">
              
              {/* Left Column - Upload & Topics */}
              <div className="col-span-12 lg:col-span-4 xl:col-span-3 space-y-6 xl:space-y-8 2xl:space-y-10 min-w-0">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1, duration: 0.6 }}
                  className="min-w-0"
                >
                  <PDFDropZone />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2, duration: 0.6 }}
                  className="min-w-0"
                >
                  <TopicViewer />
                </motion.div>
              </div>

              {/* Center Column - Chat Interface */}
              <div className="col-span-12 lg:col-span-8 xl:col-span-6 min-w-0">
                <motion.div
                  initial={{ opacity: 0, y: 30, scale: 0.95 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                  className="h-[600px] lg:h-[700px] xl:h-[800px] 2xl:h-[850px] min-w-0"
                >
                  <ChatAssistant />
                </motion.div>
              </div>

              {/* Right Column - Study Tools */}
              <div className="col-span-12 xl:col-span-3 space-y-6 xl:space-y-8 2xl:space-y-10 min-w-0">
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4, duration: 0.6 }}
                  className="min-w-0"
                >
                  <StudyStreak />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.5, duration: 0.6 }}
                  className="min-w-0"
                >
                  <QuizModule />
                </motion.div>
              </div>
            </div>

            {/* Secondary Grid - Bottom Section */}
            <div className="grid grid-cols-12 gap-6 xl:gap-8 2xl:gap-10 mb-8 lg:mb-12 xl:mb-16">
              {/* Settings Panel */}
              <div className="col-span-12 lg:col-span-5 xl:col-span-4 min-w-0">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.6, duration: 0.6 }}
                  className="min-w-0"
                >
                  <SettingsPanel />
                </motion.div>
              </div>

              {/* Enhanced Learning Insights */}
              <div className="col-span-12 lg:col-span-7 xl:col-span-8 min-w-0">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.7, duration: 0.6 }}
                  className={`h-full p-4 sm:p-6 lg:p-8 rounded-xl sm:rounded-2xl magnetic-hover min-w-0 ${
                    isDarkMode 
                      ? 'bg-gray-800/50 border border-gray-700/50' 
                      : 'bg-white/80 border border-gray-200/50'
                  }`}
                  style={{
                    boxShadow: isDarkMode 
                      ? '0 20px 40px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                      : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                    backdropFilter: 'blur(16px)'
                  }}
                >
                  <h3 className={`text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 lg:mb-8 break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Learning Insights
                  </h3>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 lg:gap-8 h-full">
                    <motion.div 
                      whileHover={{ scale: 1.02 }}
                      className={`p-4 sm:p-6 lg:p-8 rounded-lg sm:rounded-xl min-w-0 ${
                        isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
                      }`}
                    >
                      <h4 className={`text-lg sm:text-xl font-semibold mb-3 sm:mb-4 break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Recent Activity
                      </h4>
                      <div className="space-y-3 sm:space-y-4">
                        {[
                          { color: 'green', text: 'Completed daily goal', icon: '🎯' },
                          { color: 'blue', text: 'Started new session', icon: '🚀' },
                          { color: 'purple', text: 'Earned achievement', icon: '🏆' }
                        ].map((item, index) => (
                          <motion.div 
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.8 + index * 0.1 }}
                            whileHover={{ x: 5, scale: 1.02 }}
                            className="flex items-center space-x-3 min-w-0"
                          >
                            <div className={`w-3 h-3 rounded-full bg-${item.color}-500 flex-shrink-0`}></div>
                            <span className="text-lg sm:text-xl flex-shrink-0">{item.icon}</span>
                            <span className={`text-sm sm:text-base break-words min-w-0 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {item.text}
                            </span>
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>

                    <motion.div 
                      whileHover={{ scale: 1.02 }}
                      className={`p-4 sm:p-6 lg:p-8 rounded-lg sm:rounded-xl min-w-0 ${
                        isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
                      }`}
                    >
                      <h4 className={`text-lg sm:text-xl font-semibold mb-3 sm:mb-4 break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        AI Recommendations
                      </h4>
                      <div className="space-y-3 sm:space-y-4">
                        {[
                          { 
                            color: 'blue', 
                            text: 'Try uploading a PDF to get personalized study materials',
                            icon: '💡'
                          },
                          { 
                            color: 'purple', 
                            text: 'Set a daily XP goal to stay motivated',
                            icon: '🎯'
                          }
                        ].map((item, index) => (
                          <motion.div 
                            key={index}
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 1.1 + index * 0.1 }}
                            whileHover={{ scale: 1.02 }}
                            className={`p-3 sm:p-4 rounded-lg sm:rounded-xl min-w-0 ${
                              isDarkMode ? `bg-${item.color}-500/10 border border-${item.color}-400/30` : `bg-${item.color}-50 border border-${item.color}-200`
                            }`}
                          >
                            <div className="flex items-start space-x-3 min-w-0">
                              <span className="text-base sm:text-lg flex-shrink-0">{item.icon}</span>
                              <p className={`text-sm sm:text-base break-words min-w-0 ${isDarkMode ? `text-${item.color}-300` : `text-${item.color}-700`}`}>
                                {item.text}
                              </p>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>

          {/* Enhanced Stats Section - Fully Responsive Grid */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className={`p-4 sm:p-6 lg:p-8 xl:p-10 2xl:p-12 rounded-xl sm:rounded-2xl w-full magnetic-hover min-w-0 ${
              isDarkMode 
                ? 'bg-gray-800/50 border border-gray-700/50' 
                : 'bg-white/80 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 20px 40px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(16px)'
            }}
          >
            <motion.h3 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9, duration: 0.6 }}
              className={`text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8 lg:mb-12 text-center break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
            >
              Your Learning Journey
            </motion.h3>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 lg:gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ scale: 0.8, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 1 + index * 0.1, type: "spring", stiffness: 200 }}
                  whileHover={{ 
                    scale: 1.05, 
                    y: -8
                  }}
                  className={`text-center p-3 sm:p-4 md:p-6 lg:p-8 rounded-xl sm:rounded-2xl transition-all duration-500 magnetic-hover min-w-0 ${
                    isDarkMode ? 'bg-gray-700/30 hover:bg-gray-700/50' : 'bg-gray-50/80 hover:bg-gray-100/80'
                  }`}
                  style={{
                    boxShadow: isDarkMode 
                      ? '0 15px 30px rgba(0, 0, 0, 0.15)' 
                      : '0 15px 30px rgba(0, 0, 0, 0.08)'
                  }}
                >
                  <motion.div
                    animate={{ 
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      repeatDelay: 4,
                      delay: index * 0.8
                    }}
                    className={`mx-auto mb-3 sm:mb-4 lg:mb-6 w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 rounded-xl sm:rounded-2xl flex items-center justify-center bg-gradient-to-br ${stat.gradient} flex-shrink-0`}
                    style={{
                      boxShadow: '0 10px 25px rgba(0, 0, 0, 0.15)'
                    }}
                  >
                    <stat.icon className="h-5 w-5 sm:h-6 sm:w-6 md:h-7 md:w-7 lg:h-8 lg:w-8 text-white" />
                  </motion.div>
                  
                  <motion.p
                    whileHover={{ scale: 1.1 }}
                    className={`text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-bold mb-1 sm:mb-2 bg-gradient-to-br ${stat.gradient} bg-clip-text text-transparent break-words`}
                  >
                    {stat.value}
                  </motion.p>
                  <p className={`text-xs sm:text-sm md:text-base lg:text-lg font-medium leading-tight mb-1 break-words ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {stat.label}
                  </p>
                  <p className={`text-xs sm:text-sm opacity-70 break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {stat.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}