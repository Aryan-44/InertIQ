import React, { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence, useDragControls } from 'framer-motion'
import { 
  Camera, 
  Minimize2, 
  Maximize2, 
  Mic, 
  MicOff, 
  X, 
  Move, 
  Video, 
  VideoOff,
  Settings,
  Monitor,
  Smartphone,
  RotateCcw,
  AlertCircle
} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const FloatingWebcam: React.FC = () => {
  const [showControls, setShowControls] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isMinimized, setIsMinimized] = useState(false)
  const [deviceList, setDeviceList] = useState<MediaDeviceInfo[]>([])
  const [selectedDevice, setSelectedDevice] = useState<string>('')
  const [isLoading, setIsLoading] = useState(false)
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const nodeRef = useRef<HTMLDivElement>(null)
  const dragControls = useDragControls()
  
  const { 
    isWebcamOpen, 
    webcamPosition, 
    webcamSize, 
    isDarkMode,
    setIsWebcamOpen, 
    setWebcamPosition, 
    setWebcamSize
  } = useAppStore()

  // Get available video devices
  const getVideoDevices = useCallback(async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices()
      const videoDevices = devices.filter(device => device.kind === 'videoinput')
      setDeviceList(videoDevices)
      if (videoDevices.length > 0 && !selectedDevice) {
        setSelectedDevice(videoDevices[0].deviceId)
      }
    } catch (error) {
      console.error('Error getting video devices:', error)
    }
  }, [selectedDevice])

  // Initialize webcam stream with error handling
  const initializeWebcam = useCallback(async () => {
    if (!isVideoOn) return

    setIsLoading(true)
    setError(null)

    try {
      const constraints = {
        video: {
          deviceId: selectedDevice ? { exact: selectedDevice } : undefined,
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          facingMode: selectedDevice ? undefined : 'user',
          frameRate: { ideal: 30 }
        },
        audio: !isMuted
      }
      
      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints)
      setStream(mediaStream)
      setHasPermission(true)
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        await videoRef.current.play()
      }
    } catch (err) {
      console.error("Webcam initialization error:", err)
      setHasPermission(false)
      setIsVideoOn(false)
      
      if (err instanceof Error) {
        switch (err.name) {
          case 'NotAllowedError':
            setError("Camera permission denied. Please allow camera access and try again.")
            break
          case 'NotFoundError':
            setError("No camera found on this device.")
            break
          case 'NotReadableError':
            setError("Camera is already in use by another application.")
            break
          case 'OverconstrainedError':
            setError("Camera constraints not supported.")
            break
          default:
            setError(`Camera error: ${err.message}`)
        }
      } else {
        setError("Unknown camera error occurred.")
      }
    } finally {
      setIsLoading(false)
    }
  }, [isVideoOn, isMuted, selectedDevice])

  // Initialize webcam when component mounts or settings change
  useEffect(() => {
    if (isWebcamOpen && isVideoOn && !stream) {
      getVideoDevices().then(() => {
        initializeWebcam()
      })
    }
  }, [isWebcamOpen, isVideoOn, stream, initializeWebcam, getVideoDevices])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop())
      }
    }
  }, [stream])

  // Handle video toggle
  const handleVideoToggle = useCallback(() => {
    if (isVideoOn && stream) {
      stream.getVideoTracks().forEach(track => track.stop())
      setStream(null)
    }
    setIsVideoOn(!isVideoOn)
  }, [isVideoOn, stream])

  // Handle mute toggle
  const handleMuteToggle = useCallback(() => {
    if (stream) {
      stream.getAudioTracks().forEach(track => {
        track.enabled = isMuted
      })
    }
    setIsMuted(!isMuted)
  }, [stream, isMuted])

  // Handle device change
  const handleDeviceChange = useCallback(async (deviceId: string) => {
    setSelectedDevice(deviceId)
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
      setStream(null)
    }
    // Reinitialize with new device
    setTimeout(() => {
      initializeWebcam()
    }, 100)
  }, [stream, initializeWebcam])

  // Handle close
  const handleClose = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
      setStream(null)
    }
    setIsWebcamOpen(false)
    setError(null)
    setHasPermission(null)
  }, [stream, setIsWebcamOpen])

  // Retry connection
  const handleRetry = useCallback(() => {
    setError(null)
    setHasPermission(null)
    initializeWebcam()
  }, [initializeWebcam])

  // Responsive sizing with bounds checking
  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth
      const screenHeight = window.innerHeight
      
      const newSize = screenWidth < 640 
        ? { width: 160, height: 120 }
        : screenWidth < 1024 
          ? { width: 200, height: 150 }
          : { width: 240, height: 180 }
      
      setWebcamSize(newSize)
      
      // Keep webcam in bounds
      let newX = webcamPosition.x
      let newY = webcamPosition.y
      
      if (newX + newSize.width > screenWidth) {
        newX = screenWidth - newSize.width - 20
      }
      if (newY + newSize.height > screenHeight) {
        newY = screenHeight - newSize.height - 20
      }
      
      if (newX !== webcamPosition.x || newY !== webcamPosition.y) {
        setWebcamPosition({ x: Math.max(20, newX), y: Math.max(20, newY) })
      }
    }

    window.addEventListener('resize', handleResize)
    handleResize() // Initial call
    return () => window.removeEventListener('resize', handleResize)
  }, [webcamPosition, setWebcamPosition, setWebcamSize])

  // Auto-open webcam after login with delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsWebcamOpen(true)
    }, 2000)
    
    return () => clearTimeout(timer)
  }, [setIsWebcamOpen])

  if (!isWebcamOpen) return null

  const currentSize = isExpanded 
    ? { width: Math.min(webcamSize.width * 1.4, window.innerWidth * 0.4), height: Math.min(webcamSize.height * 1.4, window.innerHeight * 0.4) }
    : isMinimized
      ? { width: 48, height: 48 }
      : webcamSize

  return (
    <motion.div
      ref={nodeRef}
      drag
      dragControls={dragControls}
      dragMomentum={false}
      dragElastic={0.1}
      dragConstraints={{
        left: 0,
        right: Math.max(0, window.innerWidth - currentSize.width),
        top: 0,
        bottom: Math.max(0, window.innerHeight - currentSize.height)
      }}
      initial={{ 
        scale: 0, 
        opacity: 0, 
        x: Math.max(20, window.innerWidth - currentSize.width - 20), 
        y: Math.max(20, window.innerHeight - currentSize.height - 100)
      }}
      animate={{ 
        scale: 1, 
        opacity: 1,
        width: currentSize.width,
        height: currentSize.height
      }}
      exit={{ scale: 0, opacity: 0 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      whileHover={{ scale: isMinimized ? 1.1 : 1.02 }}
      className="fixed z-50 cursor-move"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
      onDragEnd={(event, info) => {
        const newX = Math.max(0, Math.min(info.point.x, window.innerWidth - currentSize.width))
        const newY = Math.max(0, Math.min(info.point.y, window.innerHeight - currentSize.height))
        setWebcamPosition({ x: newX, y: newY })
      }}
      style={{
        left: webcamPosition.x,
        top: webcamPosition.y,
        maxWidth: '40vw',
        maxHeight: '40vh'
      }}
    >
      <motion.div
        className={`relative w-full h-full rounded-xl sm:rounded-2xl lg:rounded-3xl overflow-hidden transition-all duration-300 ${
          isDarkMode 
            ? 'bg-gray-900/95 border-2 border-gray-700/50' 
            : 'bg-white/95 border-2 border-gray-200/50'
        }`}
        style={{
          boxShadow: isDarkMode 
            ? '0 15px 30px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
            : '0 15px 30px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(20px)'
        }}
        animate={{
          borderColor: isVideoOn && stream ? '#10b981' : error ? '#ef4444' : '#6b7280'
        }}
      >
        {/* Webcam Content */}
        <div className={`w-full h-full flex items-center justify-center ${
          isVideoOn && stream ? 'bg-black' : 'bg-gradient-to-br from-gray-700 to-gray-800'
        }`}>
          {isMinimized ? (
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="text-center"
            >
              <Camera className={`h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 mx-auto ${
                isVideoOn && stream ? 'text-green-400' : 'text-gray-400'
              }`} />
            </motion.div>
          ) : isLoading ? (
            <motion.div
              animate={{ 
                rotate: 360
              }}
              transition={{ 
                duration: 1,
                repeat: Infinity,
                ease: "linear"
              }}
              className="text-center"
            >
              <div className="w-6 h-6 sm:w-8 sm:h-8 border-2 sm:border-3 border-blue-500 border-t-transparent rounded-full mx-auto mb-2" />
              <p className="text-xs text-gray-400">Connecting...</p>
            </motion.div>
          ) : isVideoOn && stream && hasPermission ? (
            <video 
              ref={videoRef}
              autoPlay 
              muted 
              playsInline 
              className="w-full h-full object-cover rounded-xl sm:rounded-2xl lg:rounded-3xl"
            />
          ) : error ? (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center p-2 sm:p-4"
            >
              <AlertCircle className="h-6 w-6 sm:h-8 sm:w-8 lg:h-10 lg:w-10 text-red-400 mx-auto mb-2 sm:mb-3" />
              <p className="text-xs sm:text-sm text-red-400 text-center leading-tight mb-2 sm:mb-3 break-words">{error}</p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleRetry}
                className="px-2 py-1 sm:px-3 sm:py-1.5 text-xs bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors btn-hover"
              >
                <div className="flex items-center space-x-1">
                  <RotateCcw className="h-2 w-2 sm:h-3 sm:w-3" />
                  <span>Retry</span>
                </div>
              </motion.button>
            </motion.div>
          ) : isVideoOn && hasPermission === null ? (
            <motion.div
              animate={{ 
                scale: [1, 1.05, 1],
                opacity: [0.8, 1, 0.8]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="text-center"
            >
              <Camera className="h-6 w-6 sm:h-8 sm:w-8 lg:h-10 lg:w-10 text-gray-400 mx-auto mb-2" />
              <p className="text-xs sm:text-sm text-gray-400">Requesting access...</p>
            </motion.div>
          ) : (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center"
            >
              <VideoOff className="h-6 w-6 sm:h-8 sm:w-8 lg:h-10 lg:w-10 text-red-400 mx-auto mb-2" />
              <p className="text-xs sm:text-sm text-red-400">Camera Off</p>
            </motion.div>
          )}
        </div>

        {/* Status Indicators */}
        <div className="absolute top-1 right-1 sm:top-2 sm:right-2 flex space-x-1">
          {/* Recording Status */}
          <motion.div
            animate={{ 
              opacity: isVideoOn && stream ? [1, 0.5, 1] : 1,
              scale: isVideoOn && stream ? [1, 1.1, 1] : 1
            }}
            transition={{ 
              duration: isVideoOn && stream ? 2 : 0,
              repeat: isVideoOn && stream ? Infinity : 0,
              ease: "easeInOut"
            }}
            className={`w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full ${
              isVideoOn && stream ? 'bg-green-500' : error ? 'bg-red-500' : 'bg-gray-500'
            }`}
            style={{
              boxShadow: isVideoOn && stream
                ? '0 0 8px rgba(34, 197, 94, 0.6)' 
                : error 
                  ? '0 0 8px rgba(239, 68, 68, 0.6)'
                  : '0 0 8px rgba(107, 114, 128, 0.6)'
            }}
          />

          {/* Device Indicator */}
          {deviceList.length > 1 && (
            <motion.div
              animate={{ 
                opacity: [0.5, 1, 0.5],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-blue-500"
              style={{
                boxShadow: '0 0 8px rgba(59, 130, 246, 0.6)'
              }}
            />
          )}
        </div>

        {/* Enhanced Controls */}
        <AnimatePresence>
          {showControls && !isMinimized && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className={`absolute bottom-1 left-1 right-1 sm:bottom-2 sm:left-2 sm:right-2 p-1.5 sm:p-2.5 rounded-lg sm:rounded-xl ${
                isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'
              }`}
              style={{
                backdropFilter: 'blur(10px)'
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1 sm:space-x-1.5">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleMuteToggle}
                    className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg transition-colors ${
                      isMuted
                        ? 'bg-red-500/20 text-red-500'
                        : isDarkMode
                          ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                          : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                    }`}
                  >
                    {isMuted ? <MicOff className="h-2 w-2 sm:h-3 sm:w-3" /> : <Mic className="h-2 w-2 sm:h-3 sm:w-3" />}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleVideoToggle}
                    className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg transition-colors ${
                      !isVideoOn
                        ? 'bg-red-500/20 text-red-500'
                        : isDarkMode
                          ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                          : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                    }`}
                  >
                    {isVideoOn ? <Video className="h-2 w-2 sm:h-3 sm:w-3" /> : <VideoOff className="h-2 w-2 sm:h-3 sm:w-3" />}
                  </motion.button>

                  {/* Device Selector - Only show on larger screens */}
                  {deviceList.length > 1 && currentSize.width > 200 && (
                    <select
                      value={selectedDevice}
                      onChange={(e) => handleDeviceChange(e.target.value)}
                      className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg text-xs transition-colors max-w-20 sm:max-w-24 ${
                        isDarkMode
                          ? 'bg-gray-700/50 text-gray-300 border border-gray-600/50'
                          : 'bg-gray-100/50 text-gray-700 border border-gray-200/50'
                      }`}
                    >
                      {deviceList.map((device) => (
                        <option key={device.deviceId} value={device.deviceId}>
                          {device.label || `Camera ${device.deviceId.slice(0, 8)}`}
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div className="flex items-center space-x-1 sm:space-x-1.5">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsMinimized(true)}
                    className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg transition-colors ${
                      isDarkMode
                        ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                        : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                    }`}
                  >
                    <Minimize2 className="h-2 w-2 sm:h-3 sm:w-3" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsExpanded(!isExpanded)}
                    className={`p-1 sm:p-1.5 rounded-md sm:rounded-lg transition-colors ${
                      isDarkMode
                        ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                        : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                    }`}
                  >
                    {isExpanded ? <Monitor className="h-2 w-2 sm:h-3 sm:w-3" /> : <Maximize2 className="h-2 w-2 sm:h-3 sm:w-3" />}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleClose}
                    className="p-1 sm:p-1.5 rounded-md sm:rounded-lg bg-red-500/20 text-red-500 hover:bg-red-500/30 transition-colors"
                  >
                    <X className="h-2 w-2 sm:h-3 sm:w-3" />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Minimized State Controls */}
        {isMinimized && (
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMinimized(false)}
            className="absolute inset-0 w-full h-full flex items-center justify-center"
          >
            <Maximize2 className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400" />
          </motion.button>
        )}

        {/* Drag Handle */}
        {!isMinimized && (
          <motion.div
            whileHover={{ scale: 1.1 }}
            className={`absolute top-1 left-1 sm:top-2 sm:left-2 p-1 sm:p-1.5 rounded-md sm:rounded-lg cursor-move transition-opacity duration-200 ${
              showControls ? 'opacity-100' : 'opacity-0'
            } ${isDarkMode ? 'bg-gray-700/80 text-gray-300' : 'bg-white/80 text-gray-700'}`}
            onPointerDown={(e) => dragControls.start(e)}
          >
            <Move className="h-2 w-2 sm:h-3 sm:w-3" />
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}