import React, { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Shield, 
  AlertTriangle, 
  Camera, 
  Eye, 
  Smartphone, 
  Clock,
  CheckCircle,
  XCircle,
  RotateCcw,
  Play,
  Pause,
  Square
} from 'lucide-react'
import { SmartWebcam } from './SmartWebcam'
import { useAppStore } from '../store/useAppStore'

interface ExamSession {
  id: string
  startTime: Date
  violations: Array<{
    type: 'focus' | 'phone' | 'face'
    timestamp: Date
    description: string
  }>
  status: 'active' | 'paused' | 'terminated' | 'completed'
}

export const ExamMode: React.FC = () => {
  const [examSession, setExamSession] = useState<ExamSession | null>(null)
  const [violationCount, setViolationCount] = useState(0)
  const [showTerminationWarning, setShowTerminationWarning] = useState(false)
  const [examDuration, setExamDuration] = useState(0) // in seconds
  
  const { isDarkMode, setIsWebcamOpen } = useAppStore()

  // Maximum violations before exam termination
  const MAX_VIOLATIONS = 5
  const CRITICAL_VIOLATIONS = 3

  // Start exam session
  const startExam = useCallback(() => {
    const newSession: ExamSession = {
      id: `exam_${Date.now()}`,
      startTime: new Date(),
      violations: [],
      status: 'active'
    }
    
    setExamSession(newSession)
    setViolationCount(0)
    setExamDuration(0)
    setIsWebcamOpen(true)
    
    // Start exam timer
    const timer = setInterval(() => {
      setExamDuration(prev => prev + 1)
    }, 1000)

    // Store timer reference for cleanup
    ;(newSession as any).timer = timer
  }, [setIsWebcamOpen])

  // Handle violations from webcam
  const handleViolation = useCallback((type: 'focus' | 'phone' | 'face') => {
    if (!examSession || examSession.status !== 'active') return

    const violation = {
      type,
      timestamp: new Date(),
      description: getViolationDescription(type)
    }

    const updatedSession = {
      ...examSession,
      violations: [...examSession.violations, violation]
    }

    setExamSession(updatedSession)
    setViolationCount(prev => prev + 1)

    // Check for critical violations
    if (type === 'phone') {
      // Phone detection is critical - immediate termination
      terminateExam('Phone detected - Exam terminated immediately')
    } else if (violationCount + 1 >= MAX_VIOLATIONS) {
      // Too many violations
      terminateExam('Maximum violations exceeded')
    } else if (violationCount + 1 >= CRITICAL_VIOLATIONS) {
      // Show warning
      setShowTerminationWarning(true)
      setTimeout(() => setShowTerminationWarning(false), 5000)
    }
  }, [examSession, violationCount])

  // Terminate exam
  const terminateExam = useCallback((reason: string) => {
    if (!examSession) return

    const updatedSession = {
      ...examSession,
      status: 'terminated' as const
    }

    setExamSession(updatedSession)
    
    // Clear timer
    if ((examSession as any).timer) {
      clearInterval((examSession as any).timer)
    }

    // Show termination alert
    alert(`EXAM TERMINATED: ${reason}`)
    
    // Optionally restart the page or redirect
    setTimeout(() => {
      if (confirm('Exam has been terminated. Would you like to restart?')) {
        window.location.reload()
      }
    }, 2000)
  }, [examSession])

  // Pause/Resume exam
  const toggleExamPause = useCallback(() => {
    if (!examSession) return

    const newStatus = examSession.status === 'active' ? 'paused' : 'active'
    setExamSession({
      ...examSession,
      status: newStatus
    })

    if (newStatus === 'paused') {
      if ((examSession as any).timer) {
        clearInterval((examSession as any).timer)
      }
    } else {
      const timer = setInterval(() => {
        setExamDuration(prev => prev + 1)
      }, 1000)
      ;(examSession as any).timer = timer
    }
  }, [examSession])

  // Complete exam
  const completeExam = useCallback(() => {
    if (!examSession) return

    const updatedSession = {
      ...examSession,
      status: 'completed' as const
    }

    setExamSession(updatedSession)
    
    if ((examSession as any).timer) {
      clearInterval((examSession as any).timer)
    }
  }, [examSession])

  // Get violation description
  const getViolationDescription = (type: 'focus' | 'phone' | 'face'): string => {
    switch (type) {
      case 'focus':
        return 'Lost focus - looked away from screen'
      case 'phone':
        return 'Smartphone detected in camera view'
      case 'face':
        return 'Face not visible or multiple faces detected'
      default:
        return 'Unknown violation'
    }
  }

  // Format time
  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    }
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const violationLevel = violationCount >= CRITICAL_VIOLATIONS ? 'critical' : violationCount > 0 ? 'warning' : 'safe'

  return (
    <div className="min-h-screen w-full p-4 lg:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`mb-8 p-6 rounded-3xl ${
            isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
          }`}
          style={{
            boxShadow: isDarkMode 
              ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
              : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
            backdropFilter: 'blur(20px)'
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <motion.div
                animate={{ 
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3
                }}
                className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                  examSession?.status === 'active'
                    ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                    : examSession?.status === 'terminated'
                      ? 'bg-gradient-to-br from-red-500 to-pink-600'
                      : 'bg-gradient-to-br from-blue-500 to-purple-600'
                }`}
                style={{
                  boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
                }}
              >
                <Shield className="h-8 w-8 text-white" />
              </motion.div>
              <div>
                <h1 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Secure Exam Mode
                </h1>
                <p className={`text-lg ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  AI-Powered Proctoring System
                </p>
              </div>
            </div>

            {examSession && (
              <div className="text-right">
                <div className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {formatTime(examDuration)}
                </div>
                <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Exam Duration
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {!examSession ? (
          /* Pre-Exam Setup */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {/* Exam Instructions */}
            <div className={`p-8 rounded-3xl ${
              isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)'
            }}
            >
              <h2 className={`text-2xl font-bold mb-6 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Exam Instructions
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Camera className={`h-6 w-6 mt-1 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                  <div>
                    <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Camera Monitoring
                    </h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Your camera will monitor your face throughout the exam. Ensure good lighting and stay visible.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Eye className={`h-6 w-6 mt-1 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
                  <div>
                    <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Focus Detection
                    </h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      AI will track your eye movement and focus. Avoid looking away from the screen for extended periods.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Smartphone className={`h-6 w-6 mt-1 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`} />
                  <div>
                    <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Device Detection
                    </h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Smartphones and other devices are prohibited. Detection will result in immediate exam termination.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <AlertTriangle className={`h-6 w-6 mt-1 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
                  <div>
                    <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Violation Policy
                    </h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Maximum {MAX_VIOLATIONS} violations allowed. Critical violations may result in immediate termination.
                    </p>
                  </div>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={startExam}
                className={`w-full mt-8 py-4 rounded-2xl font-bold text-lg transition-all duration-200 ${
                  isDarkMode 
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white'
                    : 'bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white'
                }`}
                style={{
                  boxShadow: '0 8px 30px rgba(34, 197, 94, 0.4)'
                }}
              >
                <div className="flex items-center justify-center space-x-2">
                  <Play className="h-6 w-6" />
                  <span>Start Secure Exam</span>
                </div>
              </motion.button>
            </div>

            {/* System Check */}
            <div className={`p-8 rounded-3xl ${
              isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)'
            }}
            >
              <h2 className={`text-2xl font-bold mb-6 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                System Check
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className={`${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Camera Access
                  </span>
                  <CheckCircle className="h-6 w-6 text-green-500" />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className={`${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    AI Models Loaded
                  </span>
                  <CheckCircle className="h-6 w-6 text-green-500" />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className={`${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Internet Connection
                  </span>
                  <CheckCircle className="h-6 w-6 text-green-500" />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className={`${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Browser Compatibility
                  </span>
                  <CheckCircle className="h-6 w-6 text-green-500" />
                </div>
              </div>

              <div className={`mt-6 p-4 rounded-2xl ${
                isDarkMode ? 'bg-green-500/10 border border-green-400/30' : 'bg-green-50 border border-green-200'
              }`}>
                <div className="flex items-center space-x-2">
                  <CheckCircle className={`h-5 w-5 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
                  <span className={`font-semibold ${isDarkMode ? 'text-green-300' : 'text-green-700'}`}>
                    All systems ready
                  </span>
                </div>
                <p className={`text-sm mt-1 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`}>
                  Your device is compatible and ready for secure exam mode.
                </p>
              </div>
            </div>
          </motion.div>
        ) : (
          /* Active Exam Interface */
          <div className="space-y-8">
            {/* Exam Status Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-6 rounded-3xl ${
                violationLevel === 'critical'
                  ? isDarkMode ? 'bg-red-900/50 border border-red-500/50' : 'bg-red-50 border border-red-500/50'
                  : violationLevel === 'warning'
                    ? isDarkMode ? 'bg-yellow-900/50 border border-yellow-500/50' : 'bg-yellow-50 border border-yellow-500/50'
                    : isDarkMode ? 'bg-green-900/50 border border-green-500/50' : 'bg-green-50 border border-green-500/50'
              }`}
              style={{ backdropFilter: 'blur(20px)' }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-4 h-4 rounded-full ${
                    examSession.status === 'active' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                  }`} />
                  <span className={`font-bold text-lg ${
                    violationLevel === 'critical' ? 'text-red-600' :
                    violationLevel === 'warning' ? 'text-yellow-600' : 'text-green-600'
                  }`}>
                    Exam Status: {examSession.status.toUpperCase()}
                  </span>
                </div>

                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${
                      violationLevel === 'critical' ? 'text-red-600' :
                      violationLevel === 'warning' ? 'text-yellow-600' : 'text-green-600'
                    }`}>
                      {violationCount}/{MAX_VIOLATIONS}
                    </div>
                    <div className="text-sm text-gray-600">Violations</div>
                  </div>

                  <div className="flex space-x-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={toggleExamPause}
                      className={`p-3 rounded-xl ${
                        examSession.status === 'active'
                          ? 'bg-yellow-500/20 text-yellow-600 hover:bg-yellow-500/30'
                          : 'bg-green-500/20 text-green-600 hover:bg-green-500/30'
                      }`}
                    >
                      {examSession.status === 'active' ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={completeExam}
                      className="p-3 rounded-xl bg-blue-500/20 text-blue-600 hover:bg-blue-500/30"
                    >
                      <Square className="h-5 w-5" />
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Smart Webcam */}
            <SmartWebcam 
              isExamMode={true}
              onViolation={handleViolation}
            />

            {/* Violation History */}
            {examSession.violations.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-6 rounded-3xl ${
                  isDarkMode ? 'bg-gray-800/50 border border-gray-700/50' : 'bg-white/80 border border-gray-200/50'
                }`}
                style={{
                  boxShadow: isDarkMode 
                    ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                    : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  backdropFilter: 'blur(20px)'
                }}
              >
                <h3 className={`text-xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Violation History
                </h3>
                
                <div className="space-y-3">
                  {examSession.violations.map((violation, index) => (
                    <div key={index} className={`p-3 rounded-xl ${
                      violation.type === 'phone' 
                        ? isDarkMode ? 'bg-red-500/10 border border-red-400/30' : 'bg-red-50 border border-red-200'
                        : isDarkMode ? 'bg-yellow-500/10 border border-yellow-400/30' : 'bg-yellow-50 border border-yellow-200'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <AlertTriangle className={`h-5 w-5 ${
                            violation.type === 'phone' ? 'text-red-500' : 'text-yellow-500'
                          }`} />
                          <span className={`font-medium ${
                            violation.type === 'phone' 
                              ? isDarkMode ? 'text-red-300' : 'text-red-700'
                              : isDarkMode ? 'text-yellow-300' : 'text-yellow-700'
                          }`}>
                            {violation.description}
                          </span>
                        </div>
                        <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {violation.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        )}

        {/* Termination Warning Modal */}
        <AnimatePresence>
          {showTerminationWarning && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className={`max-w-md w-full p-8 rounded-3xl ${
                  isDarkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'
                }`}
                style={{
                  boxShadow: '0 25px 50px rgba(0, 0, 0, 0.5)'
                }}
              >
                <div className="text-center">
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      duration: 0.5,
                      repeat: Infinity,
                      repeatDelay: 1
                    }}
                    className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center"
                  >
                    <AlertTriangle className="h-8 w-8 text-white" />
                  </motion.div>
                  
                  <h3 className={`text-2xl font-bold mb-4 text-red-600`}>
                    Critical Warning
                  </h3>
                  
                  <p className={`text-lg mb-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    You have reached {CRITICAL_VIOLATIONS} violations. One more violation will result in exam termination.
                  </p>
                  
                  <div className={`p-4 rounded-2xl ${
                    isDarkMode ? 'bg-red-500/10 border border-red-400/30' : 'bg-red-50 border border-red-200'
                  }`}>
                    <p className={`text-sm ${isDarkMode ? 'text-red-300' : 'text-red-700'}`}>
                      Please ensure you remain focused and follow all exam guidelines.
                    </p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}