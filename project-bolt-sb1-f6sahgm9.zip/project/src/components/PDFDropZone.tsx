// Re-export the enhanced component
export { EnhancedPDFDropZone as PDFDropZone } from './EnhancedPDFDropZone'