// Re-export the enhanced component
export { SmartQuizModule as QuizModule } from './SmartQuizModule'