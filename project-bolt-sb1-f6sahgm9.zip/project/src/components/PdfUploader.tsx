import React, { useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useDropzone } from 'react-dropzone'
import { Upload, FileText, Loader, CheckCircle, X } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const PdfUploader: React.FC = () => {
  const { 
    uploadedPdf, 
    isProcessingPdf, 
    isDarkMode,
    setUploadedPdf, 
    setIsProcessingPdf,
    setPdfTopics 
  } = useAppStore()

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    if (file && file.type === 'application/pdf') {
      setUploadedPdf(file)
      setIsProcessingPdf(true)
      
      // Simulate PDF processing
      setTimeout(() => {
        setIsProcessingPdf(false)
        setPdfTopics([
          'Introduction to Machine Learning',
          'Neural Networks Basics',
          'Deep Learning Fundamentals',
          'Computer Vision Applications',
          'Natural Language Processing'
        ])
      }, 3000)
    }
  }, [setUploadedPdf, setIsProcessingPdf, setPdfTopics])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    multiple: false
  })

  const removeFile = () => {
    setUploadedPdf(null)
    setPdfTopics([])
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <AnimatePresence mode="wait">
        {!uploadedPdf ? (
          <motion.div
            key="uploader"
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            {...getRootProps()}
            className={`relative cursor-pointer rounded-2xl border-2 border-dashed p-12 text-center transition-all duration-300 ${
              isDragActive
                ? isDarkMode
                  ? 'border-blue-400 bg-blue-500/10'
                  : 'border-blue-500 bg-blue-50'
                : isDarkMode
                  ? 'border-gray-600 hover:border-gray-500 bg-gray-800/30'
                  : 'border-gray-300 hover:border-gray-400 bg-gray-50/50'
            }`}
            style={{
              transform: isDragActive ? 'scale(1.02)' : 'scale(1)',
              boxShadow: isDragActive 
                ? isDarkMode
                  ? '0 20px 40px rgba(59, 130, 246, 0.3)'
                  : '0 20px 40px rgba(59, 130, 246, 0.2)'
                : isDarkMode
                  ? '0 8px 32px rgba(0, 0, 0, 0.3)'
                  : '0 8px 32px rgba(0, 0, 0, 0.1)'
            }}
          >
            <input {...getInputProps()} />
            
            <motion.div
              animate={{ 
                y: isDragActive ? -5 : 0,
                rotate: isDragActive ? 5 : 0 
              }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className={`mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full ${
                isDragActive
                  ? 'bg-gradient-to-br from-blue-500 to-purple-600'
                  : isDarkMode
                    ? 'bg-gradient-to-br from-gray-700 to-gray-600'
                    : 'bg-gradient-to-br from-gray-100 to-gray-200'
              }`}
              style={{
                boxShadow: isDragActive
                  ? '0 8px 32px rgba(59, 130, 246, 0.4)'
                  : '0 4px 20px rgba(0, 0, 0, 0.1)'
              }}
            >
              <Upload className={`h-8 w-8 ${
                isDragActive ? 'text-white' : isDarkMode ? 'text-gray-300' : 'text-gray-600'
              }`} />
            </motion.div>

            <motion.h3 
              className={`mb-2 text-xl font-semibold ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}
              animate={{ scale: isDragActive ? 1.05 : 1 }}
            >
              {isDragActive ? 'Drop your PDF here!' : 'Upload PDF Document'}
            </motion.h3>
            
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Drag and drop your PDF file here, or click to browse
            </p>
            
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: isDragActive ? '100%' : '0%' }}
              className={`mx-auto mt-4 h-1 rounded-full ${
                isDarkMode ? 'bg-gradient-to-r from-blue-400 to-purple-500' : 'bg-gradient-to-r from-blue-500 to-purple-600'
              }`}
            />
          </motion.div>
        ) : (
          <motion.div
            key="file-preview"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`rounded-2xl p-6 ${
              isDarkMode 
                ? 'bg-gray-800/50 border border-gray-700/50' 
                : 'bg-white/80 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 8px 32px rgba(0, 0, 0, 0.3)' 
                : '0 8px 32px rgba(0, 0, 0, 0.1)',
              backdropFilter: 'blur(10px)'
            }}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-4">
                <motion.div
                  initial={{ rotate: -10 }}
                  animate={{ rotate: 0 }}
                  className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                    isDarkMode ? 'bg-red-500/20 text-red-400' : 'bg-red-100 text-red-600'
                  }`}
                >
                  <FileText className="h-6 w-6" />
                </motion.div>
                
                <div>
                  <h4 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {uploadedPdf.name}
                  </h4>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {(uploadedPdf.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <AnimatePresence mode="wait">
                  {isProcessingPdf ? (
                    <motion.div
                      key="processing"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      className="flex items-center space-x-2"
                    >
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        <Loader className={`h-5 w-5 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                      </motion.div>
                      <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Processing...
                      </span>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="completed"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="flex items-center space-x-2"
                    >
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-sm text-green-500">Ready</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={removeFile}
                  className={`p-1 rounded-lg transition-colors ${
                    isDarkMode 
                      ? 'hover:bg-gray-700/50 text-gray-400 hover:text-red-400' 
                      : 'hover:bg-gray-100 text-gray-600 hover:text-red-600'
                  }`}
                >
                  <X className="h-4 w-4" />
                </motion.button>
              </div>
            </div>

            <AnimatePresence>
              {isProcessingPdf && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-4 space-y-2"
                >
                  <div className={`h-2 rounded-full overflow-hidden ${
                    isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
                  }`}>
                    <motion.div
                      initial={{ width: '0%' }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 3 }}
                      className={`h-full rounded-full ${
                        isDarkMode 
                          ? 'bg-gradient-to-r from-blue-400 to-purple-500' 
                          : 'bg-gradient-to-r from-blue-500 to-purple-600'
                      }`}
                    />
                  </div>
                  <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Extracting content and generating topics...
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}