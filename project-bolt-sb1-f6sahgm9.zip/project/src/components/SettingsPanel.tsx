import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Settings, 
  Moon, 
  Sun, 
  Bell, 
  Save, 
  Globe, 
  Volume2, 
  VolumeX,
  ChevronDown,
  Check
} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const SettingsPanel: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false)
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false)
  
  const { 
    isDarkMode, 
    toggleTheme,
    notifications,
    autoSave,
    language,
    setNotifications,
    setAutoSave,
    setLanguage
  } = useAppStore()

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' }
  ]

  const currentLanguage = languages.find(lang => lang.code === language) || languages[0]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-3xl overflow-hidden ${
        isDarkMode 
          ? 'bg-gray-800/50 border border-gray-700/50' 
          : 'bg-white/80 border border-gray-200/50'
      }`}
      style={{
        boxShadow: isDarkMode 
          ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
          : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
        backdropFilter: 'blur(20px)'
      }}
    >
      {/* Header */}
      <motion.div
        className={`p-6 border-b cursor-pointer ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}
        onClick={() => setIsExpanded(!isExpanded)}
        whileHover={{ backgroundColor: isDarkMode ? 'rgba(55, 65, 81, 0.6)' : 'rgba(249, 250, 251, 0.9)' }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.div
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3
              }}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                isDarkMode ? 'bg-gradient-to-br from-gray-600 to-gray-700' : 'bg-gradient-to-br from-gray-200 to-gray-300'
              }`}
              style={{
                boxShadow: '0 8px 30px rgba(0, 0, 0, 0.2)'
              }}
            >
              <Settings className={`h-6 w-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`} />
            </motion.div>
            <div>
              <h3 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Settings
              </h3>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Customize your experience
              </p>
            </div>
          </div>
          
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown className={`h-5 w-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
          </motion.div>
        </div>
      </motion.div>

      {/* Settings Content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-6 space-y-6">
              {/* Theme Toggle */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-800/20 text-gray-800'
                  }`}>
                    {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                  </div>
                  <div>
                    <h4 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Theme
                    </h4>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {isDarkMode ? 'Dark mode' : 'Light mode'}
                    </p>
                  </div>
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={toggleTheme}
                  className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                    isDarkMode ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                >
                  <motion.div
                    animate={{ x: isDarkMode ? 24 : 2 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-lg"
                  />
                </motion.button>
              </motion.div>

              {/* Notifications */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    notifications 
                      ? isDarkMode ? 'bg-green-500/20 text-green-400' : 'bg-green-100 text-green-600'
                      : isDarkMode ? 'bg-gray-600/20 text-gray-400' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {notifications ? <Bell className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
                  </div>
                  <div>
                    <h4 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Notifications
                    </h4>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {notifications ? 'Enabled' : 'Disabled'}
                    </p>
                  </div>
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setNotifications(!notifications)}
                  className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                    notifications ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <motion.div
                    animate={{ x: notifications ? 24 : 2 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-lg"
                  />
                </motion.button>
              </motion.div>

              {/* Auto Save */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    autoSave 
                      ? isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-100 text-blue-600'
                      : isDarkMode ? 'bg-gray-600/20 text-gray-400' : 'bg-gray-100 text-gray-600'
                  }`}>
                    <Save className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Auto Save
                    </h4>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {autoSave ? 'Automatically save progress' : 'Manual save only'}
                    </p>
                  </div>
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setAutoSave(!autoSave)}
                  className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                    autoSave ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                >
                  <motion.div
                    animate={{ x: autoSave ? 24 : 2 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-lg"
                  />
                </motion.button>
              </motion.div>

              {/* Language Selection */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="relative"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      isDarkMode ? 'bg-purple-500/20 text-purple-400' : 'bg-purple-100 text-purple-600'
                    }`}>
                      <Globe className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Language
                      </h4>
                      <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Interface language
                      </p>
                    </div>
                  </div>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-colors ${
                      isDarkMode
                        ? 'bg-gray-700/50 hover:bg-gray-700/70 text-gray-300 border border-gray-600/50'
                        : 'bg-gray-100/80 hover:bg-gray-200/80 text-gray-700 border border-gray-200/50'
                    }`}
                  >
                    <span className="text-lg">{currentLanguage.flag}</span>
                    <span className="font-medium">{currentLanguage.name}</span>
                    <motion.div
                      animate={{ rotate: showLanguageDropdown ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <ChevronDown className="h-4 w-4" />
                    </motion.div>
                  </motion.button>
                </div>

                {/* Language Dropdown */}
                <AnimatePresence>
                  {showLanguageDropdown && (
                    <motion.div
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className={`absolute right-0 top-full mt-2 w-48 rounded-2xl border z-10 ${
                        isDarkMode
                          ? 'bg-gray-800/95 border-gray-700/50'
                          : 'bg-white/95 border-gray-200/50'
                      }`}
                      style={{
                        boxShadow: isDarkMode 
                          ? '0 20px 40px rgba(0, 0, 0, 0.4)' 
                          : '0 20px 40px rgba(0, 0, 0, 0.15)',
                        backdropFilter: 'blur(20px)'
                      }}
                    >
                      <div className="p-2">
                        {languages.map((lang, index) => (
                          <motion.button
                            key={lang.code}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => {
                              setLanguage(lang.code)
                              setShowLanguageDropdown(false)
                            }}
                            className={`w-full flex items-center justify-between p-3 rounded-xl transition-colors ${
                              language === lang.code
                                ? isDarkMode
                                  ? 'bg-purple-600/20 text-purple-300'
                                  : 'bg-purple-100 text-purple-700'
                                : isDarkMode
                                  ? 'hover:bg-gray-700/50 text-gray-300'
                                  : 'hover:bg-gray-100/50 text-gray-700'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <span className="text-lg">{lang.flag}</span>
                              <span className="font-medium">{lang.name}</span>
                            </div>
                            {language === lang.code && (
                              <Check className="h-4 w-4" />
                            )}
                          </motion.button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Save Button */}
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`w-full p-4 rounded-2xl font-semibold transition-all duration-200 ${
                  isDarkMode 
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white'
                    : 'bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white'
                }`}
                style={{
                  boxShadow: '0 8px 30px rgba(34, 197, 94, 0.3)'
                }}
              >
                <div className="flex items-center justify-center space-x-2">
                  <Save className="h-5 w-5" />
                  <span>Save Settings</span>
                </div>
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}