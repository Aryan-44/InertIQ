import React, { useState, useRef } from 'react'
import { motion, useDragControls } from 'framer-motion'
import { Camera, Minimize2, Maximize2, Mic, MicOff, X, Move } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const WebcamBox: React.FC = () => {
  const [isMuted, setIsMuted] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [showControls, setShowControls] = useState(false)
  const dragControls = useDragControls()
  const constraintsRef = useRef(null)
  
  const { 
    isWebcamOpen, 
    webcamPosition, 
    webcamSize, 
    isDarkMode,
    setIsWebcamOpen, 
    setWebcamPosition, 
    setWebcamSize 
  } = useAppStore()

  if (!isWebcamOpen) return null

  return (
    <div ref={constraintsRef} className="fixed inset-0 pointer-events-none z-50">
      <motion.div
        drag
        dragControls={dragControls}
        dragConstraints={constraintsRef}
        dragElastic={0.1}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        whileHover={{ scale: 1.02 }}
        className="pointer-events-auto absolute"
        style={{
          left: webcamPosition.x,
          top: webcamPosition.y,
          width: isExpanded ? webcamSize.width * 1.5 : webcamSize.width,
          height: isExpanded ? webcamSize.height * 1.5 : webcamSize.height
        }}
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        <div
          className={`relative w-full h-full rounded-2xl overflow-hidden transition-all duration-300 ${
            isDarkMode 
              ? 'bg-gray-900/95 border border-gray-700/50' 
              : 'bg-white/95 border border-gray-200/50'
          }`}
          style={{
            boxShadow: isDarkMode 
              ? '0 20px 40px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
              : '0 20px 40px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
            backdropFilter: 'blur(20px)'
          }}
        >
          {/* Webcam Content */}
          <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.7, 1, 0.7]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="text-center"
            >
              <Camera className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-xs text-gray-400">Camera Preview</p>
            </motion.div>
          </div>

          {/* Drag Handle */}
          <motion.div
            onPointerDown={(e) => dragControls.start(e)}
            whileHover={{ scale: 1.1 }}
            className={`absolute top-2 left-2 p-1 rounded-lg cursor-move transition-opacity duration-200 ${
              showControls ? 'opacity-100' : 'opacity-0'
            } ${isDarkMode ? 'bg-gray-700/80 text-gray-300' : 'bg-white/80 text-gray-700'}`}
            style={{ touchAction: 'none' }}
          >
            <Move className="h-3 w-3" />
          </motion.div>

          {/* Controls */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ 
              opacity: showControls ? 1 : 0,
              y: showControls ? 0 : 10
            }}
            className={`absolute bottom-2 left-2 right-2 flex items-center justify-between p-2 rounded-lg ${
              isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'
            }`}
            style={{
              backdropFilter: 'blur(10px)'
            }}
          >
            <div className="flex items-center space-x-1">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsMuted(!isMuted)}
                className={`p-1 rounded-md transition-colors ${
                  isMuted
                    ? 'bg-red-500/20 text-red-500'
                    : isDarkMode
                      ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                      : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                }`}
              >
                {isMuted ? <MicOff className="h-3 w-3" /> : <Mic className="h-3 w-3" />}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsExpanded(!isExpanded)}
                className={`p-1 rounded-md transition-colors ${
                  isDarkMode
                    ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                    : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                }`}
              >
                {isExpanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
              </motion.button>
            </div>

            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsWebcamOpen(false)}
              className="p-1 rounded-md bg-red-500/20 text-red-500 hover:bg-red-500/30 transition-colors"
            >
              <X className="h-3 w-3" />
            </motion.button>
          </motion.div>

          {/* Status Indicator */}
          <motion.div
            animate={{ 
              opacity: [1, 0.5, 1],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"
            style={{
              boxShadow: '0 0 10px rgba(239, 68, 68, 0.5)'
            }}
          />
        </div>
      </motion.div>
    </div>
  )
}