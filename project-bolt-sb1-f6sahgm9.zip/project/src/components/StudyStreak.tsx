import React from 'react'
import { motion } from 'framer-motion'
import { Flame, Trophy, Star, Target, Zap, Award } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const StudyStreak: React.FC = () => {
  const { 
    studyStreak, 
    dailyXP, 
    totalXP,
    level, 
    weeklyProgress,
    isDarkMode 
  } = useAppStore()

  const streakData = Array.from({ length: 7 }, (_, i) => ({
    day: ['S', 'M', 'T', 'W', 'T', 'F', 'S'][i],
    completed: weeklyProgress[i],
    isToday: i === 6
  }))

  const xpToNextLevel = (level * 500) - (totalXP % 500)
  const levelProgress = ((totalXP % 500) / 500) * 100

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl sm:rounded-3xl p-4 sm:p-6 ${
        isDarkMode 
          ? 'bg-gray-800/50 border border-gray-700/50' 
          : 'bg-white/80 border border-gray-200/50'
      }`}
      style={{
        boxShadow: isDarkMode 
          ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
          : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
        backdropFilter: 'blur(20px)'
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4 sm:mb-6">
        <div className="flex items-center space-x-3 sm:space-x-4">
          <motion.div
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3
            }}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl flex items-center justify-center ${
              studyStreak > 0 
                ? isDarkMode ? 'bg-gradient-to-br from-orange-500 to-red-600' : 'bg-gradient-to-br from-orange-400 to-red-500'
                : isDarkMode ? 'bg-gray-600/50' : 'bg-gray-300/50'
            }`}
            style={{
              boxShadow: studyStreak > 0 ? '0 8px 30px rgba(251, 146, 60, 0.4)' : 'none'
            }}
          >
            <Flame className={`h-6 w-6 sm:h-7 sm:w-7 ${studyStreak > 0 ? 'text-white' : 'text-gray-400'}`} />
          </motion.div>
          <div>
            <h3 className={`text-lg sm:text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Study Streak
            </h3>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {studyStreak > 0 ? `${studyStreak} days strong! 🔥` : 'Start your streak today!'}
            </p>
          </div>
        </div>

        <motion.div
          whileHover={{ scale: 1.05 }}
          className={`px-3 sm:px-4 py-2 rounded-xl sm:rounded-2xl text-sm font-bold ${
            isDarkMode 
              ? 'bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30 text-purple-300'
              : 'bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-400/30 text-purple-700'
          }`}
          style={{
            boxShadow: '0 4px 20px rgba(168, 85, 247, 0.2)'
          }}
        >
          Level {level}
        </motion.div>
      </div>

      {/* Streak Calendar */}
      <div className="mb-6 sm:mb-8">
        <h4 className={`text-sm font-semibold mb-3 sm:mb-4 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
          This Week
        </h4>
        <div className="flex justify-between space-x-1 sm:space-x-2">
          {streakData.map((day, index) => (
            <motion.div
              key={index}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.1 }}
              className="flex flex-col items-center space-y-2 sm:space-y-3"
            >
              <span className={`text-xs font-medium ${
                isDarkMode ? 'text-gray-400' : 'text-gray-600'
              }`}>
                {day.day}
              </span>
              
              <motion.div
                animate={day.completed ? {
                  scale: [1, 1.2, 1],
                  rotate: day.isToday ? [0, 360, 0] : 0
                } : {}}
                transition={{ 
                  duration: day.isToday ? 2 : 0.5,
                  repeat: day.isToday ? Infinity : 0,
                  repeatDelay: 3
                }}
                className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl flex items-center justify-center border-2 transition-all duration-300 ${
                  day.completed
                    ? day.isToday
                      ? isDarkMode
                        ? 'bg-gradient-to-br from-orange-500 to-red-600 border-orange-400 text-white'
                        : 'bg-gradient-to-br from-orange-400 to-red-500 border-orange-300 text-white'
                      : isDarkMode
                        ? 'bg-gradient-to-br from-green-500 to-emerald-600 border-green-400 text-white'
                        : 'bg-gradient-to-br from-green-400 to-emerald-500 border-green-300 text-white'
                    : isDarkMode
                      ? 'border-gray-600 bg-gray-700/30'
                      : 'border-gray-300 bg-gray-100/50'
                }`}
                style={day.completed ? {
                  boxShadow: day.isToday 
                    ? '0 8px 30px rgba(251, 146, 60, 0.4)'
                    : '0 8px 30px rgba(34, 197, 94, 0.3)'
                } : {}}
              >
                {day.completed && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.2 }}
                  >
                    {day.isToday ? <Flame className="h-4 w-4 sm:h-5 sm:w-5" /> : <Star className="h-3 w-3 sm:h-4 sm:w-4" />}
                  </motion.div>
                )}
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Level Progress */}
      <div className="mb-4 sm:mb-6">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <div className="flex items-center space-x-2">
            <Zap className={`h-4 w-4 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
            <span className={`text-sm font-semibold ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Level Progress
            </span>
          </div>
          <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {totalXP > 0 ? `${xpToNextLevel} XP to Level ${level + 1}` : 'Start earning XP!'}
          </span>
        </div>
        
        <div className={`h-2 sm:h-3 rounded-full overflow-hidden ${
          isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
        }`}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${levelProgress}%` }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className={`h-full rounded-full ${
              isDarkMode 
                ? 'bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500' 
                : 'bg-gradient-to-r from-yellow-500 via-orange-600 to-red-600'
            }`}
            style={{
              boxShadow: totalXP > 0 ? '0 0 20px rgba(251, 146, 60, 0.5)' : 'none'
            }}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl ${
            isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
          }`}
        >
          <div className="flex items-center space-x-2 mb-2">
            <Target className={`h-4 w-4 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
            <span className={`text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Daily XP
            </span>
          </div>
          <div className="flex items-end space-x-2">
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className={`text-xl sm:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
            >
              {dailyXP}
            </motion.span>
            <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              / 250
            </span>
          </div>
          
          {/* Daily XP Progress Bar */}
          <div className={`mt-2 h-1.5 sm:h-2 rounded-full overflow-hidden ${
            isDarkMode ? 'bg-gray-600' : 'bg-gray-200'
          }`}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((dailyXP / 250) * 100, 100)}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className={`h-full rounded-full ${
                isDarkMode 
                  ? 'bg-gradient-to-r from-blue-400 to-purple-500' 
                  : 'bg-gradient-to-r from-blue-500 to-purple-600'
              }`}
            />
          </div>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.02 }}
          className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl ${
            isDarkMode ? 'bg-gray-700/30' : 'bg-gray-50/80'
          }`}
        >
          <div className="flex items-center space-x-2 mb-2">
            <Trophy className={`h-4 w-4 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
            <span className={`text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Total XP
            </span>
          </div>
          <div className="flex items-end space-x-2">
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className={`text-xl sm:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
            >
              {totalXP.toLocaleString()}
            </motion.span>
          </div>
          
          <p className={`text-xs mt-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {totalXP > 0 ? 'Keep learning! 🚀' : 'Start your journey!'}
          </p>
        </motion.div>
      </div>

      {/* Achievement Badge - Only show if user has achievements */}
      {studyStreak > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className={`mt-4 sm:mt-6 p-3 sm:p-4 rounded-xl sm:rounded-2xl text-center ${
            isDarkMode 
              ? 'bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30'
              : 'bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-400/30'
          }`}
        >
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Award className={`h-4 w-4 sm:h-5 sm:w-5 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
            <span className={`text-sm font-semibold ${isDarkMode ? 'text-purple-300' : 'text-purple-700'}`}>
              Achievement Unlocked!
            </span>
          </div>
          <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            First Steps - Started your learning journey
          </p>
        </motion.div>
      )}
    </motion.div>
  )
}