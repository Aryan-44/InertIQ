// Re-export the enhanced component
export { EnhancedTopicViewer as TopicViewer } from './EnhancedTopicViewer'