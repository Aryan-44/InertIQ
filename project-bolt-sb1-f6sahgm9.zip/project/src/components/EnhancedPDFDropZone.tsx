import React, { useCallback, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useDropzone } from 'react-dropzone'
import { Upload, FileText, Loader, CheckCircle, X, Sparkles, Brain, Zap, BookOpen } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import { PDFProcessor } from '../utils/pdfProcessor'

export const EnhancedPDFDropZone: React.FC = () => {
  const [processingStage, setProcessingStage] = useState<string>('')
  const [progress, setProgress] = useState(0)
  
  const { 
    uploadedPdf, 
    isProcessingPdf, 
    isDarkMode,
    setUploadedPdf, 
    setIsProcessingPdf,
    setPdfTopics,
    setPdfContent,
    addXP
  } = useAppStore()

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    if (file && file.type === 'application/pdf') {
      setUploadedPdf(file)
      setIsProcessingPdf(true)
      setProgress(0)
      
      try {
        // Stage 1: Extract text
        setProcessingStage('Extracting text from PDF...')
        setProgress(20)
        
        const extractedText = await PDFProcessor.extractTextFromPDF(file)
        
        // Stage 2: Analyze content
        setProcessingStage('Analyzing content structure...')
        setProgress(40)
        
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        // Stage 3: Extract topics
        setProcessingStage('Identifying key topics...')
        setProgress(60)
        
        const topics = PDFProcessor.extractTopicsFromText(extractedText)
        
        // Stage 4: Generate summaries
        setProcessingStage('Generating topic summaries...')
        setProgress(80)
        
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        // Stage 5: Complete
        setProcessingStage('Finalizing analysis...')
        setProgress(100)
        
        await new Promise(resolve => setTimeout(resolve, 500))
        
        setPdfContent(extractedText)
        setPdfTopics(topics)
        setIsProcessingPdf(false)
        addXP(100) // Award XP for successful upload and processing
        
      } catch (error) {
        console.error('PDF processing error:', error)
        setIsProcessingPdf(false)
        setProcessingStage('Error processing PDF')
      }
    }
  }, [setUploadedPdf, setIsProcessingPdf, setPdfTopics, setPdfContent, addXP])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    multiple: false,
    maxSize: 50 * 1024 * 1024 // 50MB
  })

  const removeFile = () => {
    setUploadedPdf(null)
    setPdfTopics([])
    setPdfContent('')
    setProgress(0)
    setProcessingStage('')
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <AnimatePresence mode="wait">
        {!uploadedPdf ? (
          <motion.div
            key="uploader"
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            {...getRootProps()}
            className={`relative cursor-pointer rounded-3xl border-2 border-dashed p-8 sm:p-12 text-center transition-all duration-500 ${
              isDragActive
                ? isDarkMode
                  ? 'border-blue-400 bg-blue-500/20 scale-105'
                  : 'border-blue-500 bg-blue-50 scale-105'
                : isDarkMode
                  ? 'border-gray-600 hover:border-gray-500 bg-gray-800/30 hover:bg-gray-800/50'
                  : 'border-gray-300 hover:border-gray-400 bg-gray-50/50 hover:bg-gray-100/50'
            }`}
            style={{
              boxShadow: isDragActive 
                ? isDarkMode
                  ? '0 25px 50px rgba(59, 130, 246, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                  : '0 25px 50px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.8)'
                : isDarkMode
                  ? '0 15px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)'
                  : '0 15px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)'
            }}
          >
            <input {...getInputProps()} />
            
            {/* Floating particles effect */}
            {isDragActive && (
              <div className="absolute inset-0 overflow-hidden rounded-3xl">
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ 
                      opacity: [0, 1, 0],
                      scale: [0, 1, 0],
                      x: [0, Math.random() * 200 - 100],
                      y: [0, Math.random() * 200 - 100]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.2
                    }}
                    className={`absolute w-2 h-2 rounded-full ${
                      isDarkMode ? 'bg-blue-400' : 'bg-blue-500'
                    }`}
                    style={{
                      left: '50%',
                      top: '50%'
                    }}
                  />
                ))}
              </div>
            )}
            
            <motion.div
              animate={{ 
                y: isDragActive ? -10 : [0, -8, 0],
                rotate: isDragActive ? [0, 5, -5, 0] : 0,
                scale: isDragActive ? 1.1 : [1, 1.05, 1]
              }}
              transition={{ 
                duration: isDragActive ? 0.5 : 3,
                repeat: isDragActive ? 0 : Infinity,
                ease: "easeInOut"
              }}
              className={`mx-auto mb-6 sm:mb-8 flex h-20 w-20 sm:h-24 sm:w-24 items-center justify-center rounded-2xl sm:rounded-3xl ${
                isDragActive
                  ? 'bg-gradient-to-br from-blue-500 to-purple-600'
                  : isDarkMode
                    ? 'bg-gradient-to-br from-gray-700 to-gray-600'
                    : 'bg-gradient-to-br from-gray-100 to-gray-200'
              }`}
              style={{
                boxShadow: isDragActive
                  ? '0 15px 40px rgba(59, 130, 246, 0.5)'
                  : '0 10px 30px rgba(0, 0, 0, 0.1)'
              }}
            >
              {isDragActive ? (
                <Sparkles className="h-10 w-10 sm:h-12 sm:w-12 text-white" />
              ) : (
                <Upload className={`h-10 w-10 sm:h-12 sm:w-12 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`} />
              )}
            </motion.div>

            <motion.h3 
              className={`mb-4 sm:mb-6 text-2xl sm:text-3xl font-bold ${
                isDarkMode ? 'text-white' : 'text-gray-900'
              }`}
              animate={{ scale: isDragActive ? 1.05 : 1 }}
            >
              {isDragActive ? 'Drop your PDF here!' : 'Upload PDF Document'}
            </motion.h3>
            
            <p className={`text-lg sm:text-xl mb-6 sm:mb-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {isDragActive 
                ? 'Release to start AI-powered analysis...' 
                : 'Drag and drop your PDF file here, or click to browse'
              }
            </p>

            {/* Feature highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-6">
              {[
                { icon: Brain, label: 'AI Topic Extraction', color: 'blue' },
                { icon: Zap, label: 'Smart Quiz Generation', color: 'purple' },
                { icon: BookOpen, label: 'Adaptive Learning', color: 'green' }
              ].map((feature, index) => (
                <motion.div
                  key={feature.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl ${
                    isDarkMode ? 'bg-gray-700/30' : 'bg-gray-100/50'
                  }`}
                >
                  <feature.icon className={`h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 ${
                    feature.color === 'blue' ? 'text-blue-500' :
                    feature.color === 'purple' ? 'text-purple-500' : 'text-green-500'
                  }`} />
                  <p className={`text-xs sm:text-sm font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {feature.label}
                  </p>
                </motion.div>
              ))}
            </div>

            <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              <p>Supported: PDF files up to 50MB</p>
              <p className="mt-1">✨ Advanced AI will analyze content and generate personalized quizzes</p>
            </div>
            
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: isDragActive ? '100%' : '0%' }}
              className={`mx-auto mt-6 sm:mt-8 h-1 rounded-full ${
                isDarkMode ? 'bg-gradient-to-r from-blue-400 to-purple-500' : 'bg-gradient-to-r from-blue-500 to-purple-600'
              }`}
            />
          </motion.div>
        ) : (
          <motion.div
            key="file-preview"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`rounded-3xl p-6 sm:p-8 ${
              isDarkMode 
                ? 'bg-gray-800/50 border border-gray-700/50' 
                : 'bg-white/80 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 25px 50px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 25px 50px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)'
            }}
          >
            <div className="flex items-start justify-between mb-6 sm:mb-8">
              <div className="flex items-center space-x-4 sm:space-x-6">
                <motion.div
                  initial={{ rotate: -10, scale: 0.8 }}
                  animate={{ rotate: 0, scale: 1 }}
                  className={`flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-2xl sm:rounded-3xl ${
                    isDarkMode ? 'bg-red-500/20 text-red-400' : 'bg-red-100 text-red-600'
                  }`}
                  style={{
                    boxShadow: '0 10px 30px rgba(239, 68, 68, 0.3)'
                  }}
                >
                  <FileText className="h-8 w-8 sm:h-10 sm:w-10" />
                </motion.div>
                
                <div className="min-w-0 flex-1">
                  <h4 className={`text-xl sm:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {uploadedPdf.name}
                  </h4>
                  <p className={`text-sm sm:text-base ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {(uploadedPdf.size / 1024 / 1024).toFixed(2)} MB • PDF Document
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Brain className={`h-4 w-4 sm:h-5 sm:w-5 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                    <span className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      AI-Enhanced Processing
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <AnimatePresence mode="wait">
                  {isProcessingPdf ? (
                    <motion.div
                      key="processing"
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                      className="flex items-center space-x-3"
                    >
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        <Loader className={`h-6 w-6 sm:h-8 sm:w-8 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                      </motion.div>
                      <div className="text-right">
                        <span className={`text-sm sm:text-base font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          Processing...
                        </span>
                        <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {Math.round(progress)}%
                        </p>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="completed"
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="flex items-center space-x-3"
                    >
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.2, 1] }}
                        transition={{ duration: 0.6 }}
                      >
                        <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-green-500" />
                      </motion.div>
                      <div className="text-right">
                        <span className="text-sm sm:text-base font-medium text-green-500">Analysis Complete</span>
                        <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          Ready for learning
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={removeFile}
                  className={`p-2 sm:p-3 rounded-xl transition-colors ${
                    isDarkMode 
                      ? 'hover:bg-red-500/20 text-gray-400 hover:text-red-400' 
                      : 'hover:bg-red-50 text-gray-600 hover:text-red-600'
                  }`}
                >
                  <X className="h-5 w-5 sm:h-6 sm:w-6" />
                </motion.button>
              </div>
            </div>

            <AnimatePresence>
              {isProcessingPdf && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="space-y-6"
                >
                  {/* Progress Bar */}
                  <div className={`h-3 sm:h-4 rounded-full overflow-hidden ${
                    isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
                  }`}>
                    <motion.div
                      initial={{ width: '0%' }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      className={`h-full rounded-full ${
                        isDarkMode 
                          ? 'bg-gradient-to-r from-blue-400 via-purple-500 to-green-400' 
                          : 'bg-gradient-to-r from-blue-500 via-purple-600 to-green-500'
                      }`}
                    />
                  </div>
                  
                  {/* Processing Stage */}
                  <motion.div
                    key={processingStage}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center"
                  >
                    <p className={`text-base sm:text-lg font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {processingStage}
                    </p>
                  </motion.div>
                  
                  {/* Processing Steps */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 sm:gap-4 text-center">
                    {[
                      { label: 'Text Extraction', icon: FileText, stage: 20 },
                      { label: 'Content Analysis', icon: Brain, stage: 40 },
                      { label: 'Topic Identification', icon: Sparkles, stage: 60 },
                      { label: 'Summary Generation', icon: BookOpen, stage: 80 }
                    ].map((step, index) => (
                      <motion.div
                        key={step.label}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.2 }}
                        className={`p-3 sm:p-4 rounded-xl sm:rounded-2xl ${
                          progress >= step.stage
                            ? isDarkMode ? 'bg-green-500/20 border border-green-400/30' : 'bg-green-100 border border-green-300'
                            : isDarkMode ? 'bg-gray-700/30' : 'bg-gray-100/50'
                        }`}
                      >
                        <motion.div
                          animate={progress >= step.stage ? { 
                            scale: [1, 1.2, 1],
                            rotate: [0, 10, -10, 0]
                          } : {}}
                          transition={{ 
                            duration: 1,
                            repeat: progress >= step.stage ? Infinity : 0,
                            repeatDelay: 2
                          }}
                          className="flex justify-center mb-2"
                        >
                          <step.icon className={`h-5 w-5 sm:h-6 sm:w-6 ${
                            progress >= step.stage
                              ? 'text-green-500'
                              : isDarkMode ? 'text-blue-400' : 'text-blue-600'
                          }`} />
                        </motion.div>
                        <p className={`text-xs sm:text-sm font-medium ${
                          progress >= step.stage
                            ? 'text-green-600'
                            : isDarkMode ? 'text-gray-400' : 'text-gray-600'
                        }`}>
                          {step.label}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}