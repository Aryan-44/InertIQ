import React from 'react'
import { motion } from 'framer-motion'
import { Menu, Sun, Moon, Settings, User } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const Header3D: React.FC = () => {
  const { isDarkMode, toggleTheme, toggleSidebar } = useAppStore()

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isDarkMode 
          ? 'bg-gray-900/80 border-gray-700/50' 
          : 'bg-white/80 border-gray-200/50'
      } backdrop-blur-xl border-b`}
      style={{
        boxShadow: isDarkMode 
          ? '0 8px 32px rgba(0, 0, 0, 0.3)' 
          : '0 8px 32px rgba(0, 0, 0, 0.1)'
      }}
    >
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleSidebar}
            className={`p-2 rounded-xl transition-all duration-200 ${
              isDarkMode 
                ? 'hover:bg-gray-700/50 text-gray-300' 
                : 'hover:bg-gray-100/50 text-gray-700'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? 'inset 0 2px 4px rgba(255, 255, 255, 0.1)' 
                : 'inset 0 2px 4px rgba(0, 0, 0, 0.1)'
            }}
          >
            <Menu className="h-6 w-6" />
          </motion.button>
          
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="flex items-center space-x-3"
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
            }`}
            style={{
              boxShadow: '0 4px 20px rgba(59, 130, 246, 0.4)'
            }}>
              <span className="text-white font-bold text-lg">AI</span>
            </div>
            <h1 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              PDF Assistant
            </h1>
          </motion.div>
        </div>

        <div className="flex items-center space-x-3">
          <motion.button
            whileHover={{ scale: 1.05, rotate: 180 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className={`p-2 rounded-xl transition-all duration-300 ${
              isDarkMode 
                ? 'hover:bg-yellow-500/20 text-yellow-400' 
                : 'hover:bg-gray-800/20 text-gray-800'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 4px 20px rgba(250, 204, 21, 0.2)' 
                : '0 4px 20px rgba(0, 0, 0, 0.1)'
            }}
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`p-2 rounded-xl transition-all duration-200 ${
              isDarkMode 
                ? 'hover:bg-gray-700/50 text-gray-300' 
                : 'hover:bg-gray-100/50 text-gray-700'
            }`}
          >
            <Settings className="h-5 w-5" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`p-2 rounded-xl transition-all duration-200 ${
              isDarkMode 
                ? 'hover:bg-gray-700/50 text-gray-300' 
                : 'hover:bg-gray-100/50 text-gray-700'
            }`}
          >
            <User className="h-5 w-5" />
          </motion.button>
        </div>
      </div>
    </motion.header>
  )
}