import React, { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Draggable from 'react-draggable'
import { 
  Camera, 
  Minimize2, 
  Maximize2, 
  Mic, 
  MicOff, 
  X, 
  Move, 
  Video, 
  VideoOff,
  AlertTriangle,
  Eye,
  EyeOff,
  Smartphone,
  Shield,
  Activity
} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import { useAIDetection } from '../hooks/useAIDetection'
import { useFocusDetection } from '../hooks/useFocusDetection'

interface SmartWebcamProps {
  isExamMode?: boolean
  onViolation?: (type: 'focus' | 'phone' | 'face') => void
}

export const SmartWebcam: React.FC<SmartWebcamProps> = ({ 
  isExamMode = false, 
  onViolation 
}) => {
  const [showControls, setShowControls] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [violations, setViolations] = useState<string[]>([])
  const [isDetectionActive, setIsDetectionActive] = useState(isExamMode)
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodeRef = useRef<HTMLDivElement>(null)
  
  const { 
    isWebcamOpen, 
    webcamPosition, 
    webcamSize, 
    isWebcamMuted,
    isDarkMode,
    webcamStream,
    setIsWebcamOpen, 
    setWebcamPosition, 
    setWebcamSize,
    setIsWebcamMuted,
    setWebcamStream
  } = useAppStore()

  // AI Detection Hook
  const {
    isModelLoaded,
    phoneDetected,
    faceDetected,
    faceCount,
    startDetection,
    stopDetection,
    detectionStats
  } = useAIDetection(videoRef, canvasRef, isDetectionActive)

  // Focus Detection Hook
  const {
    isFocused,
    focusLostCount,
    totalFocusTime,
    startFocusTracking,
    stopFocusTracking
  } = useFocusDetection(isExamMode)

  // Handle violations
  useEffect(() => {
    if (!isExamMode) return

    const newViolations: string[] = []
    
    if (phoneDetected) {
      newViolations.push('Smartphone detected in frame')
      onViolation?.('phone')
    }
    
    if (!faceDetected && isVideoOn) {
      newViolations.push('Face not visible in camera')
      onViolation?.('face')
    }
    
    if (faceCount > 1) {
      newViolations.push('Multiple faces detected')
      onViolation?.('face')
    }
    
    if (!isFocused) {
      newViolations.push('Focus lost - not looking at screen')
      onViolation?.('focus')
    }

    setViolations(newViolations)
  }, [phoneDetected, faceDetected, faceCount, isFocused, isExamMode, isVideoOn, onViolation])

  // Initialize webcam stream
  const initializeWebcam = useCallback(async () => {
    if (!isVideoOn) return

    try {
      setError(null)
      const constraints = {
        video: {
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          facingMode: 'user',
          frameRate: { ideal: 30 }
        },
        audio: !isWebcamMuted
      }
      
      const stream = await navigator.mediaDevices.getUserMedia(constraints)
      setWebcamStream(stream)
      setHasPermission(true)
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
        
        // Start AI detection after video is ready
        if (isDetectionActive) {
          setTimeout(() => {
            startDetection()
            startFocusTracking()
          }, 1000)
        }
      }
    } catch (err) {
      console.error("Webcam initialization error:", err)
      setHasPermission(false)
      setIsVideoOn(false)
      
      if (err instanceof Error) {
        switch (err.name) {
          case 'NotAllowedError':
            setError("Camera permission denied. Please allow camera access.")
            break
          case 'NotFoundError':
            setError("No camera found on this device.")
            break
          case 'NotReadableError':
            setError("Camera is already in use by another application.")
            break
          case 'OverconstrainedError':
            setError("Camera constraints not supported.")
            break
          default:
            setError(`Camera error: ${err.message}`)
        }
      } else {
        setError("Unknown camera error occurred.")
      }
    }
  }, [isVideoOn, isWebcamMuted, isDetectionActive, setWebcamStream, startDetection, startFocusTracking])

  // Initialize webcam when component mounts or settings change
  useEffect(() => {
    if (isWebcamOpen && isVideoOn && !webcamStream) {
      initializeWebcam()
    }
  }, [isWebcamOpen, isVideoOn, webcamStream, initializeWebcam])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (webcamStream) {
        webcamStream.getTracks().forEach(track => track.stop())
        setWebcamStream(null)
      }
      stopDetection()
      stopFocusTracking()
    }
  }, [webcamStream, setWebcamStream, stopDetection, stopFocusTracking])

  // Handle video toggle
  const handleVideoToggle = useCallback(() => {
    if (isVideoOn && webcamStream) {
      webcamStream.getVideoTracks().forEach(track => track.stop())
      setWebcamStream(null)
      stopDetection()
    }
    setIsVideoOn(!isVideoOn)
  }, [isVideoOn, webcamStream, setWebcamStream, stopDetection])

  // Handle mute toggle
  const handleMuteToggle = useCallback(() => {
    if (webcamStream) {
      webcamStream.getAudioTracks().forEach(track => {
        track.enabled = isWebcamMuted
      })
    }
    setIsWebcamMuted(!isWebcamMuted)
  }, [webcamStream, isWebcamMuted, setIsWebcamMuted])

  // Handle close
  const handleClose = useCallback(() => {
    if (webcamStream) {
      webcamStream.getTracks().forEach(track => track.stop())
      setWebcamStream(null)
    }
    stopDetection()
    stopFocusTracking()
    setIsWebcamOpen(false)
    setError(null)
    setHasPermission(null)
    setViolations([])
  }, [webcamStream, setWebcamStream, setIsWebcamOpen, stopDetection, stopFocusTracking])

  // Toggle detection
  const toggleDetection = useCallback(() => {
    if (isDetectionActive) {
      stopDetection()
      stopFocusTracking()
    } else {
      startDetection()
      startFocusTracking()
    }
    setIsDetectionActive(!isDetectionActive)
  }, [isDetectionActive, startDetection, stopDetection, startFocusTracking, stopFocusTracking])

  // Responsive sizing
  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth
      const newSize = screenWidth < 640 
        ? { width: 200, height: 150 }
        : screenWidth < 1024 
          ? { width: 240, height: 180 }
          : { width: 280, height: 210 }
      
      setWebcamSize(newSize)
      
      // Keep webcam in bounds
      const windowWidth = window.innerWidth
      const windowHeight = window.innerHeight
      
      let newX = webcamPosition.x
      let newY = webcamPosition.y
      
      if (newX + newSize.width > windowWidth) {
        newX = windowWidth - newSize.width - 20
      }
      if (newY + newSize.height > windowHeight) {
        newY = windowHeight - newSize.height - 20
      }
      
      if (newX !== webcamPosition.x || newY !== webcamPosition.y) {
        setWebcamPosition({ x: Math.max(20, newX), y: Math.max(20, newY) })
      }
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [webcamPosition, setWebcamPosition, setWebcamSize])

  if (!isWebcamOpen) return null

  const currentSize = isExpanded 
    ? { width: webcamSize.width * 1.5, height: webcamSize.height * 1.5 }
    : webcamSize

  const hasViolations = violations.length > 0
  const violationLevel = violations.length > 2 ? 'critical' : violations.length > 0 ? 'warning' : 'safe'

  return (
    <>
      {/* Hidden canvas for AI detection */}
      <canvas
        ref={canvasRef}
        style={{ display: 'none' }}
        width={640}
        height={480}
      />

      <Draggable
        nodeRef={nodeRef}
        defaultPosition={webcamPosition}
        onStop={(e, data) => setWebcamPosition({ x: data.x, y: data.y })}
        bounds="parent"
        handle=".drag-handle"
      >
        <motion.div
          ref={nodeRef}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          whileHover={{ scale: 1.02 }}
          className="fixed z-50"
          style={{
            width: currentSize.width,
            height: currentSize.height
          }}
          onMouseEnter={() => setShowControls(true)}
          onMouseLeave={() => setShowControls(false)}
        >
          <motion.div
            className={`relative w-full h-full rounded-2xl sm:rounded-3xl overflow-hidden transition-all duration-300 ${
              isDarkMode 
                ? 'bg-gray-900/95 border-2' 
                : 'bg-white/95 border-2'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 15px 30px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 15px 30px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)'
            }}
            animate={{
              borderColor: hasViolations
                ? violationLevel === 'critical' 
                  ? '#ef4444' 
                  : '#f59e0b'
                : isVideoOn && webcamStream
                  ? '#10b981'
                  : '#6b7280'
            }}
          >
            {/* Webcam Content */}
            <div className={`w-full h-full flex items-center justify-center ${
              isVideoOn && webcamStream ? 'bg-black' : 'bg-gradient-to-br from-gray-700 to-gray-800'
            }`}>
              {isVideoOn && webcamStream && hasPermission ? (
                <video 
                  ref={videoRef}
                  autoPlay 
                  muted 
                  playsInline 
                  className="w-full h-full object-cover rounded-2xl sm:rounded-3xl"
                />
              ) : error ? (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center p-4"
                >
                  <Camera className="h-8 w-8 sm:h-10 sm:w-10 text-red-400 mx-auto mb-3" />
                  <p className="text-xs sm:text-sm text-red-400 text-center leading-tight">{error}</p>
                </motion.div>
              ) : isVideoOn && hasPermission === null ? (
                <motion.div
                  animate={{ 
                    scale: [1, 1.05, 1],
                    opacity: [0.8, 1, 0.8]
                  }}
                  transition={{ 
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="text-center"
                >
                  <Camera className="h-8 w-8 sm:h-10 sm:w-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-xs sm:text-sm text-gray-400">Connecting...</p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center"
                >
                  <VideoOff className="h-8 w-8 sm:h-10 sm:w-10 text-red-400 mx-auto mb-2" />
                  <p className="text-xs sm:text-sm text-red-400">Camera Off</p>
                </motion.div>
              )}
            </div>

            {/* AI Detection Overlay */}
            {isDetectionActive && isVideoOn && (
              <div className="absolute top-2 left-2 right-2 flex justify-between items-start">
                {/* Detection Status */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`px-2 py-1 rounded-lg text-xs font-medium ${
                    isModelLoaded
                      ? isDarkMode ? 'bg-green-500/20 text-green-400' : 'bg-green-100 text-green-700'
                      : isDarkMode ? 'bg-yellow-500/20 text-yellow-400' : 'bg-yellow-100 text-yellow-700'
                  }`}
                >
                  <div className="flex items-center space-x-1">
                    <Activity className="h-3 w-3" />
                    <span>{isModelLoaded ? 'AI Active' : 'Loading AI...'}</span>
                  </div>
                </motion.div>

                {/* Violation Alerts */}
                <AnimatePresence>
                  {hasViolations && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8, x: 20 }}
                      animate={{ opacity: 1, scale: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.8, x: 20 }}
                      className={`px-2 py-1 rounded-lg text-xs font-medium ${
                        violationLevel === 'critical'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                      }`}
                    >
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="h-3 w-3" />
                        <span>{violations.length} Alert{violations.length > 1 ? 's' : ''}</span>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Drag Handle */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className={`drag-handle absolute bottom-2 left-2 p-2 rounded-xl cursor-move transition-opacity duration-200 ${
                showControls ? 'opacity-100' : 'opacity-0'
              } ${isDarkMode ? 'bg-gray-700/80 text-gray-300' : 'bg-white/80 text-gray-700'}`}
            >
              <Move className="h-4 w-4" />
            </motion.div>

            {/* Status Indicators */}
            <div className="absolute bottom-2 right-2 flex space-x-1">
              {/* Recording Status */}
              <motion.div
                animate={{ 
                  opacity: isVideoOn && webcamStream ? [1, 0.5, 1] : 1,
                  scale: isVideoOn && webcamStream ? [1, 1.1, 1] : 1
                }}
                transition={{ 
                  duration: isVideoOn && webcamStream ? 2 : 0,
                  repeat: isVideoOn && webcamStream ? Infinity : 0,
                  ease: "easeInOut"
                }}
                className={`w-3 h-3 rounded-full ${
                  isVideoOn && webcamStream ? 'bg-green-500' : 'bg-red-500'
                }`}
                style={{
                  boxShadow: isVideoOn && webcamStream
                    ? '0 0 10px rgba(34, 197, 94, 0.6)' 
                    : '0 0 10px rgba(239, 68, 68, 0.6)'
                }}
              />

              {/* AI Detection Status */}
              {isDetectionActive && (
                <motion.div
                  animate={{ 
                    opacity: [0.5, 1, 0.5],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="w-3 h-3 rounded-full bg-blue-500"
                  style={{
                    boxShadow: '0 0 10px rgba(59, 130, 246, 0.6)'
                  }}
                />
              )}
            </div>

            {/* Controls */}
            <AnimatePresence>
              {showControls && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className={`absolute top-2 left-2 right-2 flex items-center justify-between p-3 rounded-2xl ${
                    isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'
                  }`}
                  style={{
                    backdropFilter: 'blur(10px)'
                  }}
                >
                  <div className="flex items-center space-x-2">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={handleMuteToggle}
                      className={`p-2 rounded-xl transition-colors ${
                        isWebcamMuted
                          ? 'bg-red-500/20 text-red-500'
                          : isDarkMode
                            ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                            : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                      }`}
                    >
                      {isWebcamMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={handleVideoToggle}
                      className={`p-2 rounded-xl transition-colors ${
                        !isVideoOn
                          ? 'bg-red-500/20 text-red-500'
                          : isDarkMode
                            ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                            : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                      }`}
                    >
                      {isVideoOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={toggleDetection}
                      className={`p-2 rounded-xl transition-colors ${
                        isDetectionActive
                          ? isDarkMode
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-blue-100 text-blue-600'
                          : isDarkMode
                            ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                            : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                      }`}
                    >
                      <Shield className="h-4 w-4" />
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setIsExpanded(!isExpanded)}
                      className={`p-2 rounded-xl transition-colors ${
                        isDarkMode
                          ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                          : 'bg-gray-100/50 text-gray-700 hover:bg-gray-200/50'
                      }`}
                    >
                      {isExpanded ? <Minimize2 className="h-4 w-4" />  : <Maximize2 className="h-4 w-4" />}
                    </motion.button>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={handleClose}
                    className="p-2 rounded-xl bg-red-500/20 text-red-500 hover:bg-red-500/30 transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      </Draggable>

      {/* Violation Alerts Panel */}
      <AnimatePresence>
        {hasViolations && isExamMode && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-4 right-4 z-50 max-w-sm"
          >
            <div className={`p-4 rounded-2xl border-2 ${
              violationLevel === 'critical'
                ? isDarkMode
                  ? 'bg-red-900/90 border-red-500 text-red-100'
                  : 'bg-red-50 border-red-500 text-red-900'
                : isDarkMode
                  ? 'bg-yellow-900/90 border-yellow-500 text-yellow-100'
                  : 'bg-yellow-50 border-yellow-500 text-yellow-900'
            }`}
            style={{ backdropFilter: 'blur(20px)' }}
            >
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="h-5 w-5" />
                <h3 className="font-bold">Exam Violations Detected</h3>
              </div>
              <ul className="space-y-1 text-sm">
                {violations.map((violation, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-current" />
                    <span>{violation}</span>
                  </li>
                ))}
              </ul>
              {violationLevel === 'critical' && (
                <div className="mt-3 p-2 rounded-lg bg-red-500/20 text-xs">
                  ⚠️ Critical violations may result in exam termination
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detection Stats Panel */}
      <AnimatePresence>
        {isDetectionActive && showControls && detectionStats && (
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="fixed top-4 left-4 z-40 max-w-xs"
          >
            <div className={`p-3 rounded-2xl ${
              isDarkMode ? 'bg-gray-800/90 border border-gray-700/50' : 'bg-white/90 border border-gray-200/50'
            }`}
            style={{ backdropFilter: 'blur(20px)' }}
            >
              <h3 className={`font-bold text-sm mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                AI Detection Stats
              </h3>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Face Detection:</span>
                  <span className={faceDetected ? 'text-green-500' : 'text-red-500'}>
                    {faceDetected ? '✓ Active' : '✗ No Face'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Face Count:</span>
                  <span className={faceCount === 1 ? 'text-green-500' : 'text-yellow-500'}>
                    {faceCount}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Phone Detection:</span>
                  <span className={phoneDetected ? 'text-red-500' : 'text-green-500'}>
                    {phoneDetected ? '⚠ Detected' : '✓ Clear'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Focus Status:</span>
                  <span className={isFocused ? 'text-green-500' : 'text-red-500'}>
                    {isFocused ? '✓ Focused' : '✗ Lost'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>Focus Lost:</span>
                  <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                    {focusLostCount} times
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}