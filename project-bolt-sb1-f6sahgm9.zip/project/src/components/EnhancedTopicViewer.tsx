import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { BookOpen, FileText, Brain, Clock, ChevronRight, Sparkles, Play, RotateCcw, Target } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import { PDFProcessor } from '../utils/pdfProcessor'

interface TopicData {
  title: string
  subtopics: string[]
  summary: string
  difficulty: 'easy' | 'medium' | 'hard'
  estimatedTime: number
}

export const EnhancedTopicViewer: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null)
  const [topicData, setTopicData] = useState<{ [key: string]: TopicData }>({})
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false)
  
  const { pdfTopics, isDarkMode, uploadedPdf, pdfContent, setCurrentQuiz, setIsQuizActive } = useAppStore()

  const mockTopics = pdfTopics.length > 0 ? pdfTopics : [
    "Introduction to Artificial Intelligence",
    "Machine Learning Fundamentals", 
    "Neural Networks and Deep Learning",
    "Computer Vision Applications",
    "Natural Language Processing",
    "Reinforcement Learning",
    "AI Ethics and Bias"
  ]

  // Generate topic data when topic is selected
  const handleTopicSelect = async (topic: string) => {
    setSelectedTopic(topic)
    
    if (!topicData[topic] && pdfContent) {
      const subtopics = PDFProcessor.extractSubtopics(pdfContent, topic)
      const summary = PDFProcessor.generateSummary(pdfContent, topic)
      
      const newTopicData: TopicData = {
        title: topic,
        subtopics,
        summary,
        difficulty: 'medium',
        estimatedTime: Math.floor(Math.random() * 15) + 10 // 10-25 minutes
      }
      
      setTopicData(prev => ({ ...prev, [topic]: newTopicData }))
    }
  }

  const handleStartQuiz = async (topic: string) => {
    setIsGeneratingQuiz(true)
    
    try {
      // Import the quiz generator dynamically
      const { AIQuizGenerator } = await import('../utils/aiQuizGenerator')
      
      const questions = await AIQuizGenerator.generateQuizForTopic(
        topic,
        pdfContent || `Study material for ${topic}`,
        'medium',
        5
      )
      
      setCurrentQuiz(questions)
      setIsQuizActive(true)
      setIsGeneratingQuiz(false)
    } catch (error) {
      console.error('Error generating quiz:', error)
      setIsGeneratingQuiz(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-3xl overflow-hidden ${
        isDarkMode 
          ? 'bg-gray-800/50 border border-gray-700/50' 
          : 'bg-white/80 border border-gray-200/50'
      }`}
      style={{
        boxShadow: isDarkMode 
          ? '0 25px 50px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
          : '0 25px 50px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
        backdropFilter: 'blur(20px)'
      }}
    >
      {/* Header */}
      <div className={`p-6 border-b ${
        isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
      }`}>
        <div className="flex items-center space-x-4">
          <motion.div
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3
            }}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
              isDarkMode ? 'bg-gradient-to-br from-indigo-500 to-blue-600' : 'bg-gradient-to-br from-indigo-400 to-blue-500'
            }`}
            style={{
              boxShadow: '0 8px 30px rgba(99, 102, 241, 0.4)'
            }}
          >
            <BookOpen className="h-6 w-6 text-white" />
          </motion.div>
          <div className="flex-1">
            <h2 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Smart Topic Explorer
            </h2>
            <div className="flex items-center space-x-2">
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {mockTopics.length} topics • AI-enhanced
              </p>
              {uploadedPdf && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center space-x-1"
                >
                  <Sparkles className={`h-3 w-3 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                  <span className={`text-xs ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                    Dynamic Analysis
                  </span>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Topics List */}
      <div className="max-h-96 overflow-y-auto">
        <div className="p-6 space-y-3">
          <AnimatePresence>
            {mockTopics.map((topic, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="space-y-3"
              >
                {/* Topic Header */}
                <motion.div
                  whileHover={{ scale: 1.02, x: 4 }}
                  onClick={() => handleTopicSelect(topic)}
                  className={`group p-4 rounded-2xl cursor-pointer transition-all duration-300 ${
                    selectedTopic === topic
                      ? isDarkMode 
                        ? 'bg-indigo-500/20 border border-indigo-400/50' 
                        : 'bg-indigo-100 border border-indigo-300/50'
                      : isDarkMode 
                        ? 'bg-gray-700/30 border border-gray-600/30 hover:bg-gray-700/50 hover:border-gray-600/50' 
                        : 'bg-gray-50/80 border border-gray-200/50 hover:bg-gray-100/80 hover:border-gray-300/50'
                  }`}
                  style={{
                    boxShadow: selectedTopic === topic
                      ? '0 8px 30px rgba(99, 102, 241, 0.3)'
                      : isDarkMode 
                        ? '0 4px 20px rgba(0, 0, 0, 0.2)' 
                        : '0 4px 20px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <motion.div 
                      whileHover={{ rotate: 5 }}
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        selectedTopic === topic
                          ? isDarkMode ? 'bg-indigo-500/30 text-indigo-300' : 'bg-indigo-200 text-indigo-700'
                          : isDarkMode ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-100 text-indigo-600'
                      }`}
                    >
                      <FileText className="h-5 w-5" />
                    </motion.div>
                    
                    <div className="flex-1">
                      <h3 className={`font-semibold ${
                        selectedTopic === topic
                          ? isDarkMode ? 'text-indigo-300' : 'text-indigo-700'
                          : isDarkMode ? 'text-white' : 'text-gray-900'
                      }`}>
                        {topic}
                      </h3>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center space-x-1">
                          <Brain className={`h-3 w-3 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                          <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            AI Enhanced
                          </span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className={`h-3 w-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                          <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            {Math.floor(Math.random() * 10) + 5} min read
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleStartQuiz(topic)
                        }}
                        disabled={isGeneratingQuiz}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                          isGeneratingQuiz
                            ? 'opacity-50 cursor-not-allowed'
                            : isDarkMode
                              ? 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30'
                              : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                        }`}
                      >
                        {isGeneratingQuiz ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="w-3 h-3 border border-current border-t-transparent rounded-full"
                          />
                        ) : (
                          <div className="flex items-center space-x-1">
                            <Play className="h-3 w-3" />
                            <span>Quiz</span>
                          </div>
                        )}
                      </motion.button>

                      <motion.div
                        whileHover={{ x: 4 }}
                        className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                          selectedTopic === topic
                            ? isDarkMode ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-200 text-indigo-700'
                            : isDarkMode 
                              ? 'bg-gray-600/30 text-gray-400 group-hover:bg-indigo-500/20 group-hover:text-indigo-400' 
                              : 'bg-gray-200/50 text-gray-600 group-hover:bg-indigo-100 group-hover:text-indigo-600'
                        }`}
                      >
                        <motion.div
                          animate={{ rotate: selectedTopic === topic ? 90 : 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </motion.div>
                      </motion.div>
                    </div>
                  </div>
                </motion.div>

                {/* Expanded Topic Details */}
                <AnimatePresence>
                  {selectedTopic === topic && topicData[topic] && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`ml-4 p-4 rounded-2xl ${
                        isDarkMode ? 'bg-gray-700/20 border border-gray-600/30' : 'bg-gray-50/50 border border-gray-200/30'
                      }`}
                    >
                      <div className="space-y-4">
                        {/* Topic Summary */}
                        <div>
                          <h4 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            Summary
                          </h4>
                          <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                            {topicData[topic].summary}
                          </p>
                        </div>

                        {/* Subtopics */}
                        {topicData[topic].subtopics.length > 0 && (
                          <div>
                            <h4 className={`text-sm font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                              Key Subtopics
                            </h4>
                            <div className="space-y-2">
                              {topicData[topic].subtopics.map((subtopic, subIndex) => (
                                <motion.div
                                  key={subIndex}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: subIndex * 0.1 }}
                                  className={`flex items-center space-x-2 p-2 rounded-lg ${
                                    isDarkMode ? 'bg-gray-600/20' : 'bg-white/50'
                                  }`}
                                >
                                  <Target className={`h-3 w-3 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                                  <span className={`text-xs ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    {subtopic}
                                  </span>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Topic Metadata */}
                        <div className="flex items-center justify-between pt-2 border-t border-gray-600/20">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-1">
                              <Clock className={`h-3 w-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                              <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                                ~{topicData[topic].estimatedTime} min
                              </span>
                            </div>
                            <div className={`px-2 py-1 rounded-md text-xs font-medium ${
                              topicData[topic].difficulty === 'easy'
                                ? 'bg-green-500/20 text-green-400'
                                : topicData[topic].difficulty === 'medium'
                                  ? 'bg-yellow-500/20 text-yellow-400'
                                  : 'bg-red-500/20 text-red-400'
                            }`}>
                              {topicData[topic].difficulty}
                            </div>
                          </div>
                          
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => handleStartQuiz(topic)}
                            disabled={isGeneratingQuiz}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                              isGeneratingQuiz
                                ? 'opacity-50 cursor-not-allowed'
                                : isDarkMode
                                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white'
                                  : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white'
                            }`}
                          >
                            <div className="flex items-center space-x-1">
                              <Play className="h-3 w-3" />
                              <span>Start Quiz</span>
                            </div>
                          </motion.button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Footer */}
      {!uploadedPdf && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className={`p-6 border-t ${
            isDarkMode ? 'border-gray-700/50 bg-gray-800/30' : 'border-gray-200/50 bg-gray-50/30'
          }`}
        >
          <div className={`p-4 rounded-2xl text-center ${
            isDarkMode 
              ? 'bg-blue-500/10 border border-blue-400/30' 
              : 'bg-blue-50/80 border border-blue-200/50'
          }`}>
            <p className={`text-sm ${isDarkMode ? 'text-blue-300' : 'text-blue-700'}`}>
              💡 Upload a PDF to unlock dynamic topic extraction and personalized quizzes
            </p>
          </div>
        </motion.div>
      )}
    </motion.div>
  )
}