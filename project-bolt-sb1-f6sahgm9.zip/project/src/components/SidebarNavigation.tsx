import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, 
  Upload, 
  MessageSquare, 
  Brain, 
  Trophy, 
  Settings, 
  BookOpen,
  BarChart3,
  X,
  Menu,
  User,
  LogOut,
  Sparkles
} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const SidebarNavigation: React.FC = () => {
  const { 
    isSidebarOpen, 
    toggleSidebar, 
    isDarkMode, 
    currentPage, 
    setCurrentPage,
    user,
    setUser,
    setIsAuthenticated
  } = useAppStore()

  const menuItems = [
    { icon: Home, label: 'Dashboard', id: 'dashboard', active: currentPage === 'dashboard' },
    { icon: Upload, label: 'Upload PDF', id: 'upload', active: currentPage === 'upload' },
    { icon: MessageSquare, label: 'AI Chat', id: 'chat', active: currentPage === 'chat' },
    { icon: Brain, label: 'Study Tools', id: 'quiz', active: currentPage === 'quiz' },
    { icon: Trophy, label: 'Progress', id: 'progress', active: currentPage === 'progress' },
    { icon: BarChart3, label: 'Analytics', id: 'analytics', active: currentPage === 'analytics' },
    { icon: Settings, label: 'Settings', id: 'settings', active: currentPage === 'settings' }
  ]

  const handleLogout = () => {
    setUser(null)
    setIsAuthenticated(false)
  }

  const handleMenuClick = (pageId: string) => {
    setCurrentPage(pageId)
    // Auto-close sidebar on mobile after selection
    if (window.innerWidth < 1024) {
      toggleSidebar()
    }
  }

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={toggleSidebar}
          />
        )}
      </AnimatePresence>

      {/* Mobile Menu Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleSidebar}
        className={`fixed top-4 left-4 z-50 p-2 sm:p-3 rounded-xl sm:rounded-2xl lg:hidden transition-all duration-300 ${
          isDarkMode 
            ? 'bg-gray-800/90 border border-gray-700/50 text-white shadow-lg' 
            : 'bg-white/90 border border-gray-200/50 text-gray-900 shadow-lg'
        }`}
        style={{
          backdropFilter: 'blur(20px)',
          boxShadow: isDarkMode 
            ? '0 8px 30px rgba(0, 0, 0, 0.3)' 
            : '0 8px 30px rgba(0, 0, 0, 0.1)'
        }}
      >
        <Menu className="h-4 w-4 sm:h-5 sm:w-5" />
      </motion.button>

      {/* Sidebar - Fixed positioning with responsive width */}
      <motion.aside
        initial={false}
        animate={{ 
          x: isSidebarOpen ? 0 : -320,
          transition: { 
            type: "spring", 
            damping: 25, 
            stiffness: 300,
            duration: 0.4
          }
        }}
        className={`fixed left-0 top-0 h-full w-72 sm:w-80 z-50 lg:translate-x-0 ${
          isDarkMode 
            ? 'bg-gray-900/95 border-gray-700/50' 
            : 'bg-white/95 border-gray-200/50'
        } backdrop-blur-xl border-r overflow-y-auto`}
        style={{
          boxShadow: isDarkMode 
            ? '8px 0 32px rgba(0, 0, 0, 0.3)' 
            : '8px 0 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div className="flex flex-col h-full min-h-0">
          {/* Header */}
          <div className={`flex items-center justify-between p-4 sm:p-5 border-b flex-shrink-0 ${
            isDarkMode ? 'border-gray-700/50' : 'border-gray-200/50'
          }`}>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.1, type: "spring" }}
              className="flex items-center space-x-3 min-w-0"
            >
              <motion.div
                animate={{ 
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  repeatDelay: 2
                }}
                className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0 ${
                  isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                }`}
                style={{
                  boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
                }}
              >
                <BookOpen className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
              </motion.div>
              <div className="min-w-0">
                <span className={`font-bold text-sm sm:text-base break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  AI Assistant
                </span>
                <div className="flex items-center space-x-1">
                  <Sparkles className={`h-2 w-2 sm:h-3 sm:w-3 flex-shrink-0 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                  <span className={`text-xs break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Powered by AI
                  </span>
                </div>
              </div>
            </motion.div>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={toggleSidebar}
              className={`p-1.5 sm:p-2 rounded-lg lg:hidden transition-colors flex-shrink-0 ${
                isDarkMode ? 'hover:bg-gray-700/50 text-gray-400' : 'hover:bg-gray-100/50 text-gray-600'
              }`}
            >
              <X className="h-3 w-3 sm:h-4 sm:w-4" />
            </motion.button>
          </div>

          {/* User Profile */}
          {user && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={`p-3 mx-3 mt-3 rounded-xl sm:rounded-2xl flex-shrink-0 ${
                isDarkMode ? 'bg-gray-800/50 border border-gray-700/30' : 'bg-gray-50/80 border border-gray-200/30'
              }`}
              style={{
                backdropFilter: 'blur(10px)'
              }}
            >
              <div className="flex items-center space-x-3 min-w-0">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden flex-shrink-0"
                >
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className={`w-full h-full flex items-center justify-center ${
                      isDarkMode ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-green-400 to-emerald-500'
                    }`}>
                      <User className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                    </div>
                  )}
                </motion.div>
                <div className="flex-1 min-w-0">
                  <h3 className={`font-semibold text-xs sm:text-sm truncate ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {user.name}
                  </h3>
                  <p className={`text-xs truncate ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {user.email}
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-2 overflow-y-auto min-h-0">
            {menuItems.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ x: -50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.05 }}
                whileHover={{ 
                  scale: 1.02,
                  x: 4,
                  transition: { type: "spring", stiffness: 400, damping: 10 }
                }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleMenuClick(item.id)}
                className={`flex items-center space-x-3 w-full p-2.5 sm:p-3 rounded-xl sm:rounded-2xl transition-all duration-300 min-w-0 ${
                  item.active
                    ? isDarkMode
                      ? 'bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 text-blue-400 shadow-lg'
                      : 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-400/30 text-blue-600 shadow-lg'
                    : isDarkMode
                      ? 'hover:bg-gray-700/30 text-gray-300 hover:text-white border border-transparent'
                      : 'hover:bg-gray-100/50 text-gray-700 hover:text-gray-900 border border-transparent'
                }`}
                style={item.active ? {
                  boxShadow: isDarkMode 
                    ? '0 8px 30px rgba(59, 130, 246, 0.2)' 
                    : '0 8px 30px rgba(59, 130, 246, 0.1)'
                } : {}}
              >
                <motion.div
                  whileHover={{ rotate: item.active ? 0 : 5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  className={`w-7 h-7 sm:w-9 sm:h-9 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0 ${
                    item.active 
                      ? isDarkMode 
                        ? 'bg-blue-500/20' 
                        : 'bg-blue-100'
                      : isDarkMode
                        ? 'bg-gray-700/30'
                        : 'bg-gray-100/50'
                  }`}
                >
                  <item.icon className={`h-3 w-3 sm:h-4 sm:w-4 ${
                    item.active 
                      ? isDarkMode ? 'text-blue-400' : 'text-blue-600'
                      : ''
                  }`} />
                </motion.div>
                <span className="font-medium flex-1 text-left text-xs sm:text-sm break-words min-w-0">{item.label}</span>
                {item.active && (
                  <motion.div
                    layoutId="activeIndicator"
                    className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full flex-shrink-0 ${
                      isDarkMode ? 'bg-blue-400' : 'bg-blue-600'
                    }`}
                    style={{
                      boxShadow: isDarkMode 
                        ? '0 0 10px rgba(59, 130, 246, 0.6)' 
                        : '0 0 10px rgba(59, 130, 246, 0.4)'
                    }}
                  />
                )}
              </motion.button>
            ))}
          </nav>

          {/* Logout Button */}
          <div className={`p-3 border-t flex-shrink-0 ${isDarkMode ? 'border-gray-700/50' : 'border-gray-200/50'}`}>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleLogout}
              className={`flex items-center space-x-3 w-full p-2.5 sm:p-3 rounded-xl sm:rounded-2xl transition-all duration-300 border border-transparent min-w-0 ${
                isDarkMode
                  ? 'hover:bg-red-500/20 text-gray-300 hover:text-red-400 hover:border-red-500/30'
                  : 'hover:bg-red-50 text-gray-700 hover:text-red-600 hover:border-red-200/50'
              }`}
            >
              <div className={`w-7 h-7 sm:w-9 sm:h-9 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0 ${
                isDarkMode ? 'bg-gray-700/30' : 'bg-gray-100/50'
              }`}>
                <LogOut className="h-3 w-3 sm:h-4 sm:w-4" />
              </div>
              <span className="font-medium flex-1 text-left text-xs sm:text-sm break-words min-w-0">Logout</span>
            </motion.button>
          </div>
        </div>
      </motion.aside>
    </>
  )
}