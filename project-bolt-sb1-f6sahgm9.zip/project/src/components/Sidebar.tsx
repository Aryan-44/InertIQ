import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, 
  MessageSquare, 
  Upload, 
  Brain, 
  Trophy, 
  Settings, 
  BookOpen,
  BarChart3,
  X
} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const Sidebar: React.FC = () => {
  const { isSidebarOpen, toggleSidebar, isDarkMode } = useAppStore()

  const menuItems = [
    { icon: Home, label: 'Dashboard', active: true },
    { icon: Upload, label: 'Upload PDF' },
    { icon: MessageSquare, label: 'AI Chat' },
    { icon: Brain, label: 'Quiz Mode' },
    { icon: BookOpen, label: 'Topics' },
    { icon: Trophy, label: 'Progress' },
    { icon: BarChart3, label: 'Analytics' },
    { icon: Settings, label: 'Settings' }
  ]

  return (
    <>
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={toggleSidebar}
          />
        )}
      </AnimatePresence>

      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: isSidebarOpen ? 0 : -300 }}
        transition={{ type: "spring", damping: 20, stiffness: 300 }}
        className={`fixed left-0 top-0 h-full w-80 z-50 ${
          isDarkMode 
            ? 'bg-gray-900/95 border-gray-700/50' 
            : 'bg-white/95 border-gray-200/50'
        } backdrop-blur-xl border-r lg:translate-x-0 lg:static lg:z-0`}
        style={{
          boxShadow: isDarkMode 
            ? '8px 0 32px rgba(0, 0, 0, 0.3)' 
            : '8px 0 32px rgba(0, 0, 0, 0.1)'
        }}
      >
        <div className="flex items-center justify-between p-6 border-b border-opacity-50">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: "spring" }}
            className="flex items-center space-x-3"
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
            }`}
            style={{
              boxShadow: '0 4px 20px rgba(59, 130, 246, 0.4)'
            }}>
              <span className="text-white font-bold">AI</span>
            </div>
            <span className={`font-bold text-lg ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Assistant
            </span>
          </motion.div>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleSidebar}
            className={`p-2 rounded-lg lg:hidden ${
              isDarkMode ? 'hover:bg-gray-700/50 text-gray-400' : 'hover:bg-gray-100/50 text-gray-600'
            }`}
          >
            <X className="h-5 w-5" />
          </motion.button>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item, index) => (
            <motion.button
              key={item.label}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ 
                scale: 1.02,
                x: 4,
                transition: { type: "spring", stiffness: 400, damping: 10 }
              }}
              whileTap={{ scale: 0.98 }}
              className={`flex items-center space-x-3 w-full p-3 rounded-xl transition-all duration-200 ${
                item.active
                  ? isDarkMode
                    ? 'bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 text-blue-400'
                    : 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-400/30 text-blue-600'
                  : isDarkMode
                    ? 'hover:bg-gray-700/30 text-gray-300 hover:text-white'
                    : 'hover:bg-gray-100/50 text-gray-700 hover:text-gray-900'
              }`}
              style={item.active ? {
                boxShadow: isDarkMode 
                  ? '0 4px 20px rgba(59, 130, 246, 0.2)' 
                  : '0 4px 20px rgba(59, 130, 246, 0.1)'
              } : {}}
            >
              <motion.div
                whileHover={{ rotate: item.active ? 0 : 5 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <item.icon className={`h-5 w-5 ${
                  item.active 
                    ? isDarkMode ? 'text-blue-400' : 'text-blue-600'
                    : ''
                }`} />
              </motion.div>
              <span className="font-medium">{item.label}</span>
              {item.active && (
                <motion.div
                  layoutId="activeIndicator"
                  className={`ml-auto w-2 h-2 rounded-full ${
                    isDarkMode ? 'bg-blue-400' : 'bg-blue-600'
                  }`}
                  style={{
                    boxShadow: isDarkMode 
                      ? '0 0 10px rgba(59, 130, 246, 0.6)' 
                      : '0 0 10px rgba(59, 130, 246, 0.4)'
                  }}
                />
              )}
            </motion.button>
          ))}
        </nav>
      </motion.aside>
    </>
  )
}