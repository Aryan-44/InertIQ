import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Bot, User, Loader } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

export const ChatInterface: React.FC = () => {
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { messages, isTyping, addMessage, setIsTyping, isDarkMode } = useAppStore()

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage = input.trim()
    setInput('')
    addMessage(userMessage, true)
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      setIsTyping(false)
      addMessage(
        "I understand your question about the PDF content. Based on the document you've uploaded, I can help you with detailed explanations, summaries, and generate practice questions. What specific aspect would you like me to focus on?",
        false
      )
    }, 2000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`flex flex-col h-full rounded-2xl overflow-hidden ${
        isDarkMode 
          ? 'bg-gray-800/50 border border-gray-700/50' 
          : 'bg-white/80 border border-gray-200/50'
      }`}
      style={{
        boxShadow: isDarkMode 
          ? '0 8px 32px rgba(0, 0, 0, 0.3)' 
          : '0 8px 32px rgba(0, 0, 0, 0.1)',
        backdropFilter: 'blur(10px)'
      }}
    >
      {/* Chat Header */}
      <motion.div
        initial={{ y: -20 }}
        animate={{ y: 0 }}
        className={`p-4 border-b ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}
      >
        <div className="flex items-center space-x-3">
          <motion.div
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              repeatDelay: 3
            }}
            className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
            }`}
            style={{
              boxShadow: '0 4px 20px rgba(59, 130, 246, 0.4)'
            }}
          >
            <Bot className="h-5 w-5 text-white" />
          </motion.div>
          <div>
            <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              AI Assistant
            </h3>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Always here to help
            </p>
          </div>
        </div>
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-8"
            >
              <motion.div
                animate={{ 
                  y: [0, -10, 0],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`mx-auto mb-4 w-16 h-16 rounded-full flex items-center justify-center ${
                  isDarkMode ? 'bg-gradient-to-br from-blue-500/20 to-purple-600/20' : 'bg-gradient-to-br from-blue-500/10 to-purple-600/10'
                }`}
              >
                <Bot className={`h-8 w-8 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </motion.div>
              <h4 className={`text-lg font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Start a conversation
              </h4>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Ask me anything about your PDF document!
              </p>
            </motion.div>
          ) : (
            messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-3 max-w-[80%] ${
                  message.isUser ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.isUser
                        ? isDarkMode ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-green-400 to-emerald-500'
                        : isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                    }`}
                    style={{
                      boxShadow: message.isUser 
                        ? '0 4px 20px rgba(34, 197, 94, 0.4)'
                        : '0 4px 20px rgba(59, 130, 246, 0.4)'
                    }}
                  >
                    {message.isUser ? 
                      <User className="h-4 w-4 text-white" /> : 
                      <Bot className="h-4 w-4 text-white" />
                    }
                  </motion.div>
                  
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className={`rounded-2xl px-4 py-3 ${
                      message.isUser
                        ? isDarkMode 
                          ? 'bg-gradient-to-br from-green-600/20 to-emerald-600/20 border border-green-500/30 text-green-100'
                          : 'bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-400/30 text-green-800'
                        : isDarkMode
                          ? 'bg-gray-700/50 border border-gray-600/50 text-gray-100'
                          : 'bg-gray-100/80 border border-gray-200/50 text-gray-800'
                    }`}
                    style={{
                      boxShadow: message.isUser
                        ? '0 4px 20px rgba(34, 197, 94, 0.15)'
                        : '0 4px 20px rgba(0, 0, 0, 0.1)'
                    }}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {message.content}
                    </p>
                    <p className={`text-xs mt-2 opacity-60`}>
                      {message.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </motion.div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex justify-start"
            >
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                }`}>
                  <Bot className="h-4 w-4 text-white" />
                </div>
                
                <div className={`rounded-2xl px-4 py-3 ${
                  isDarkMode ? 'bg-gray-700/50 border border-gray-600/50' : 'bg-gray-100/80 border border-gray-200/50'
                }`}>
                  <div className="flex space-x-1">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        animate={{ 
                          y: [0, -5, 0],
                          opacity: [0.4, 1, 0.4]
                        }}
                        transition={{ 
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2
                        }}
                        className={`w-2 h-2 rounded-full ${
                          isDarkMode ? 'bg-gray-400' : 'bg-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <motion.div
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        className={`p-4 border-t ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}
      >
        <div className="flex space-x-3">
          <div className="relative flex-1">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about your PDF..."
              rows={1}
              className={`w-full rounded-xl border px-4 py-3 pr-12 resize-none transition-all duration-200 ${
                isDarkMode
                  ? 'bg-gray-700/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:bg-gray-700/80'
                  : 'bg-white/80 border-gray-300/50 text-gray-900 placeholder-gray-500 focus:border-blue-500/50 focus:bg-white'
              }`}
              style={{
                minHeight: '48px',
                maxHeight: '120px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
              }}
            />
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all duration-200 ${
                input.trim() && !isTyping
                  ? isDarkMode
                    ? 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                    : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                  : isDarkMode
                    ? 'bg-gray-600/50 text-gray-400 cursor-not-allowed'
                    : 'bg-gray-200/50 text-gray-400 cursor-not-allowed'
              }`}
              style={input.trim() && !isTyping ? {
                boxShadow: '0 4px 20px rgba(59, 130, 246, 0.4)'
              } : {}}
            >
              {isTyping ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Loader className="h-4 w-4" />
                </motion.div>
              ) : (
                <Send className="h-4 w-4" />
              )}
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}