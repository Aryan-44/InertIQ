import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, Send, X, Minimize2, Maximize2, Bot, User, Sparkles, AlertCircle } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

const GEMINI_API_KEY = "AIzaSyD_7Xl4ZCsIHvW7FuvJwoHICHxO-SmV3vQ"
const GEMINI_MODEL = "gemini-2.0-flash"

interface ChatMessage {
  id: string
  content: string
  isUser: boolean
  timestamp: Date
}

export const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)
  
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  
  const { isDarkMode } = useAppStore()

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  const callGeminiAPI = async (userMessage: string): Promise<string> => {
    try {
      setError(null)
      
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: userMessage }]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      
      if (data.error) {
        throw new Error(data.error.message || 'API returned an error')
      }

      const aiResponse = data?.candidates?.[0]?.content?.parts?.[0]?.text
      
      if (!aiResponse) {
        throw new Error('No response content received from API')
      }

      setRetryCount(0) // Reset retry count on success
      return aiResponse
    } catch (error) {
      console.error('Gemini API Error:', error)
      
      if (error instanceof Error) {
        setError(error.message)
        
        if (error.message.includes('API_KEY_INVALID')) {
          return "I'm experiencing authentication issues. Please check the API configuration."
        } else if (error.message.includes('QUOTA_EXCEEDED')) {
          return "I've reached my usage limit for now. Please try again later."
        } else if (error.message.includes('Failed to fetch')) {
          return "I'm having trouble connecting to the AI service. Please check your internet connection and try again."
        }
      }
      
      return "I apologize, but I encountered an error while processing your request. Please try again."
    }
  }

  const handleSend = async () => {
    const trimmedInput = input.trim()
    if (!trimmedInput || isTyping) return

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      content: trimmedInput,
      isUser: true,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsTyping(true)

    try {
      const aiResponse = await callGeminiAPI(trimmedInput)
      
      // Simulate typing delay for better UX
      setTimeout(() => {
        const botMessage: ChatMessage = {
          id: `bot-${Date.now()}`,
          content: aiResponse,
          isUser: false,
          timestamp: new Date()
        }
        
        setMessages(prev => [...prev, botMessage])
        setIsTyping(false)
      }, 800)
      
    } catch (error) {
      setIsTyping(false)
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        content: "I apologize, but I encountered an error while processing your request. Please try again.",
        isUser: false,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleRetry = () => {
    if (retryCount < 3) {
      setRetryCount(prev => prev + 1)
      setError(null)
      // Retry the last user message
      const lastUserMessage = messages.filter(m => m.isUser).pop()
      if (lastUserMessage) {
        handleSend()
      }
    }
  }

  const toggleChat = () => {
    setIsOpen(!isOpen)
    if (!isOpen && messages.length === 0) {
      // Add welcome message
      const welcomeMessage: ChatMessage = {
        id: 'welcome',
        content: "Hello! I'm your AI assistant powered by Gemini 2.0 Flash. How can I help you today?",
        isUser: false,
        timestamp: new Date()
      }
      setMessages([welcomeMessage])
    }
  }

  return (
    <>
      {/* Chat Button - Enhanced with better positioning */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.8, type: "spring", stiffness: 260, damping: 20 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={toggleChat}
        className={`fixed bottom-4 left-4 sm:bottom-6 sm:left-6 z-50 w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-full shadow-2xl transition-all duration-300 btn-hover ${
          isDarkMode 
            ? 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500' 
            : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500'
        }`}
        style={{
          boxShadow: '0 8px 32px rgba(59, 130, 246, 0.4)'
        }}
      >
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
          className="w-full h-full flex items-center justify-center"
        >
          {isOpen ? (
            <X className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-white" />
          ) : (
            <MessageCircle className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-white" />
          )}
        </motion.div>
        
        {/* Pulse animation when closed */}
        {!isOpen && (
          <motion.div
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 rounded-full bg-blue-500"
          />
        )}
      </motion.button>

      {/* Chat Window - Enhanced with better responsive design */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 100 }}
            animate={{ 
              opacity: 1, 
              scale: isMinimized ? 0.3 : 1, 
              y: isMinimized ? 50 : 0 
            }}
            exit={{ opacity: 0, scale: 0.8, y: 100 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`fixed bottom-16 sm:bottom-20 lg:bottom-24 left-4 sm:left-6 z-40 w-72 sm:w-80 lg:w-96 h-80 sm:h-96 lg:h-[500px] rounded-xl sm:rounded-2xl lg:rounded-3xl overflow-hidden ${
              isDarkMode 
                ? 'bg-gray-900/95 border border-gray-700/50' 
                : 'bg-white/95 border border-gray-200/50'
            }`}
            style={{
              boxShadow: isDarkMode 
                ? '0 25px 50px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
                : '0 25px 50px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(20px)',
              maxWidth: '90vw',
              maxHeight: '70vh'
            }}
          >
            {/* Header */}
            <div className={`p-3 sm:p-4 border-b ${
              isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
                  <motion.div
                    animate={{ 
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      repeatDelay: 3
                    }}
                    className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                    }`}
                    style={{
                      boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
                    }}
                  >
                    <Bot className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                  </motion.div>
                  <div className="min-w-0">
                    <h3 className={`font-bold text-sm sm:text-base break-words ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      AI Assistant
                    </h3>
                    <div className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-green-500 animate-pulse" />
                      <p className={`text-xs break-words ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Powered by Gemini 2.0 Flash
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-1 sm:space-x-2 flex-shrink-0">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsMinimized(!isMinimized)}
                    className={`p-1.5 sm:p-2 rounded-lg sm:rounded-xl transition-colors ${
                      isDarkMode 
                        ? 'hover:bg-gray-700/50 text-gray-400' 
                        : 'hover:bg-gray-100/50 text-gray-600'
                    }`}
                  >
                    {isMinimized ? <Maximize2 className="h-3 w-3 sm:h-4 sm:w-4" /> : <Minimize2 className="h-3 w-3 sm:h-4 sm:w-4" />}
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsOpen(false)}
                    className={`p-1.5 sm:p-2 rounded-lg sm:rounded-xl transition-colors ${
                      isDarkMode 
                        ? 'hover:bg-red-500/20 text-gray-400 hover:text-red-400' 
                        : 'hover:bg-red-50 text-gray-600 hover:text-red-600'
                    }`}
                  >
                    <X className="h-3 w-3 sm:h-4 sm:w-4" />
                  </motion.button>
                </div>
              </div>

              {/* Error Display */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className={`mt-2 sm:mt-3 p-2 sm:p-3 rounded-lg sm:rounded-xl ${
                    isDarkMode ? 'bg-red-500/10 border border-red-400/30 text-red-300' : 'bg-red-50 border border-red-200 text-red-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 min-w-0">
                      <AlertCircle className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                      <p className="text-xs sm:text-sm break-words">Connection error</p>
                    </div>
                    {retryCount < 3 && (
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleRetry}
                        className="text-xs px-2 py-1 rounded bg-red-500/20 hover:bg-red-500/30 transition-colors flex-shrink-0"
                      >
                        Retry
                      </motion.button>
                    )}
                  </div>
                </motion.div>
              )}
            </div>

            {!isMinimized && (
              <>
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4 h-48 sm:h-56 lg:h-72">
                  <AnimatePresence>
                    {messages.map((message, index) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`flex items-start space-x-2 max-w-[85%] ${
                          message.isUser ? 'flex-row-reverse space-x-reverse' : ''
                        }`}>
                          <motion.div
                            whileHover={{ scale: 1.05 }}
                            className={`w-6 h-6 sm:w-8 sm:h-8 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0 ${
                              message.isUser
                                ? isDarkMode ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-green-400 to-emerald-500'
                                : isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                            }`}
                            style={{
                              boxShadow: message.isUser 
                                ? '0 8px 30px rgba(34, 197, 94, 0.4)'
                                : '0 8px 30px rgba(59, 130, 246, 0.4)'
                            }}
                          >
                            {message.isUser ? 
                              <User className="h-3 w-3 sm:h-4 sm:w-4 text-white" /> : 
                              <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-white" />
                            }
                          </motion.div>
                          
                          <motion.div
                            whileHover={{ scale: 1.01 }}
                            className={`rounded-xl sm:rounded-2xl px-3 py-2 sm:px-4 sm:py-3 min-w-0 ${
                              message.isUser
                                ? isDarkMode 
                                  ? 'bg-gradient-to-br from-green-600/20 to-emerald-600/20 border border-green-500/30 text-green-100'
                                  : 'bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-400/30 text-green-800'
                                : isDarkMode
                                  ? 'bg-gray-700/50 border border-gray-600/50 text-gray-100'
                                  : 'bg-gray-100/80 border border-gray-200/50 text-gray-800'
                            }`}
                            style={{
                              boxShadow: message.isUser
                                ? '0 8px 30px rgba(34, 197, 94, 0.15)'
                                : '0 8px 30px rgba(0, 0, 0, 0.1)',
                              backdropFilter: 'blur(10px)'
                            }}
                          >
                            <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap break-words">
                              {message.content}
                            </p>
                            <p className={`text-xs mt-1 sm:mt-2 opacity-60`}>
                              {message.timestamp.toLocaleTimeString([], { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </p>
                          </motion.div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Typing Indicator */}
                  <AnimatePresence>
                    {isTyping && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="flex justify-start"
                      >
                        <div className="flex items-start space-x-2">
                          <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-xl sm:rounded-2xl flex items-center justify-center ${
                            isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                          }`}>
                            <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-white" />
                          </div>
                          
                          <div className={`rounded-xl sm:rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                            isDarkMode ? 'bg-gray-700/50 border border-gray-600/50' : 'bg-gray-100/80 border border-gray-200/50'
                          }`}>
                            <div className="flex space-x-1">
                              {[0, 1, 2].map((i) => (
                                <motion.div
                                  key={i}
                                  animate={{ 
                                    y: [0, -8, 0],
                                    opacity: [0.4, 1, 0.4]
                                  }}
                                  transition={{ 
                                    duration: 1.5,
                                    repeat: Infinity,
                                    delay: i * 0.2
                                  }}
                                  className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full ${
                                    isDarkMode ? 'bg-gray-400' : 'bg-gray-600'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className={`p-3 sm:p-4 border-t ${
                  isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
                }`}>
                  <div className="flex space-x-2 sm:space-x-3">
                    <div className="relative flex-1 min-w-0">
                      <textarea
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Ask me anything..."
                        rows={1}
                        disabled={isTyping}
                        className={`w-full rounded-lg sm:rounded-xl lg:rounded-2xl border px-3 py-2 sm:px-4 sm:py-3 pr-10 sm:pr-12 resize-none transition-all duration-200 text-xs sm:text-sm min-w-0 ${
                          isDarkMode
                            ? 'bg-gray-700/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:bg-gray-700/80 disabled:opacity-50'
                            : 'bg-white/80 border-gray-300/50 text-gray-900 placeholder-gray-500 focus:border-blue-500/50 focus:bg-white disabled:opacity-50'
                        }`}
                        style={{
                          minHeight: '36px',
                          maxHeight: '80px',
                          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                          backdropFilter: 'blur(10px)'
                        }}
                      />
                      
                      <motion.button
                        whileHover={{ scale: input.trim() && !isTyping ? 1.05 : 1 }}
                        whileTap={{ scale: input.trim() && !isTyping ? 0.95 : 1 }}
                        onClick={handleSend}
                        disabled={!input.trim() || isTyping}
                        className={`absolute right-2 sm:right-3 top-1/2 -translate-y-1/2 p-1.5 sm:p-2 lg:p-3 rounded-md sm:rounded-lg lg:rounded-xl transition-all duration-200 btn-hover ${
                          input.trim() && !isTyping
                            ? isDarkMode
                              ? 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                              : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                            : isDarkMode
                              ? 'bg-gray-600/50 text-gray-400 cursor-not-allowed'
                              : 'bg-gray-200/50 text-gray-400 cursor-not-allowed'
                        }`}
                        style={input.trim() && !isTyping ? {
                          boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
                        } : {}}
                      >
                        <Send className="h-3 w-3 sm:h-4 sm:w-4" />
                      </motion.button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}