import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Bot, User, Loader, Sparkles, Brain, FileText } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

const GEMINI_API_KEY = "AIzaSyD_7Xl4ZCsIHvW7FuvJwoHICHxO-SmV3vQ"
const GEMINI_MODEL = "gemini-2.0-flash"

export const ChatAssistant: React.FC = () => {
  const [input, setInput] = useState('')
  const [apiError, setApiError] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  
  const { 
    messages, 
    isTyping, 
    addMessage, 
    setIsTyping, 
    isDarkMode,
    uploadedPdf,
    pdfContent,
    addXP
  } = useAppStore()

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`
    }
  }, [input])

  const callGeminiAPI = async (userMessage: string): Promise<string> => {
    try {
      setApiError(null)
      let contextualMessage = userMessage
      
      // Add PDF context if available
      if (uploadedPdf && pdfContent) {
        contextualMessage = `Based on the uploaded PDF "${uploadedPdf.name}" with content: "${pdfContent.substring(0, 1000)}...", please answer: ${userMessage}`
      }

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: contextualMessage }]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      
      if (data.error) {
        throw new Error(data.error.message || 'API returned an error')
      }

      const aiResponse = data?.candidates?.[0]?.content?.parts?.[0]?.text
      
      if (!aiResponse) {
        throw new Error('No response content received from API')
      }

      return aiResponse
    } catch (error) {
      console.error('Gemini API Error:', error)
      
      if (error instanceof Error) {
        setApiError(error.message)
        
        if (error.message.includes('API_KEY_INVALID')) {
          return "I'm experiencing authentication issues. Please check the API configuration."
        } else if (error.message.includes('QUOTA_EXCEEDED')) {
          return "I've reached my usage limit for now. Please try again later."
        } else if (error.message.includes('Failed to fetch')) {
          return "I'm having trouble connecting to the AI service. Please check your internet connection and try again."
        }
      }
      
      return "I apologize, but I encountered an error while processing your request. Please try again."
    }
  }

  const handleSend = async () => {
    const trimmedInput = input.trim()
    if (!trimmedInput || isTyping) return

    setInput('')
    addMessage(trimmedInput, true)
    setIsTyping(true)
    addXP(10) // Award XP for asking questions

    try {
      const aiResponse = await callGeminiAPI(trimmedInput)
      setIsTyping(false)
      addMessage(aiResponse, false)
      addXP(5) // Award XP for receiving responses
    } catch (error) {
      setIsTyping(false)
      addMessage("I apologize, but I encountered an error while processing your request. Please try again.", false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const suggestedQuestions = [
    "Explain the main concepts",
    "Generate a quiz",
    "Summarize key points",
    "What are the important topics?"
  ]

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`flex flex-col h-full rounded-2xl sm:rounded-3xl overflow-hidden ${
        isDarkMode 
          ? 'bg-gray-800/50 border border-gray-700/50' 
          : 'bg-white/80 border border-gray-200/50'
      }`}
      style={{
        boxShadow: isDarkMode 
          ? '0 20px 40px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
          : '0 20px 40px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
        backdropFilter: 'blur(20px)'
      }}
    >
      {/* Chat Header */}
      <motion.div
        initial={{ y: -20 }}
        animate={{ y: 0 }}
        className={`p-4 sm:p-5 border-b ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}
      >
        <div className="flex items-center space-x-3">
          <motion.div
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              repeatDelay: 2
            }}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl flex items-center justify-center ${
              isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
            }`}
            style={{
              boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
            }}
          >
            <Bot className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
          </motion.div>
          <div className="flex-1 min-w-0">
            <h3 className={`text-lg sm:text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              AI Assistant
            </h3>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full bg-green-500 animate-pulse`} />
              <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Powered by Gemini 2.0 Flash
              </p>
            </div>
          </div>
          
          {uploadedPdf && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`hidden sm:flex items-center space-x-2 px-3 py-2 rounded-xl ${
                isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-100 text-blue-700'
              }`}
            >
              <FileText className="h-4 w-4" />
              <span className="text-xs font-medium">PDF Context</span>
            </motion.div>
          )}
        </div>

        {/* API Error Display */}
        {apiError && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className={`mt-3 p-3 rounded-xl ${
              isDarkMode ? 'bg-red-500/10 border border-red-400/30 text-red-300' : 'bg-red-50 border border-red-200 text-red-700'
            }`}
          >
            <p className="text-sm">⚠️ {apiError}</p>
          </motion.div>
        )}
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4">
        <AnimatePresence>
          {messages.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-8 sm:py-10"
            >
              <motion.div
                animate={{ 
                  y: [0, -10, 0],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`mx-auto mb-4 sm:mb-5 w-14 h-14 sm:w-16 sm:h-16 rounded-2xl sm:rounded-3xl flex items-center justify-center ${
                  isDarkMode ? 'bg-gradient-to-br from-blue-500/20 to-purple-600/20' : 'bg-gradient-to-br from-blue-500/10 to-purple-600/10'
                }`}
              >
                <Sparkles className={`h-7 w-7 sm:h-8 sm:w-8 ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </motion.div>
              <h4 className={`text-lg sm:text-xl font-bold mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Start a conversation
              </h4>
              <p className={`text-sm sm:text-base mb-5 sm:mb-6 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Ask me anything! I can help with general knowledge or analyze your PDF content.
              </p>
              
              {/* Suggested Questions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 max-w-md mx-auto">
                {suggestedQuestions.map((question, index) => (
                  <motion.button
                    key={question}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setInput(question)}
                    className={`p-2 sm:p-3 rounded-lg sm:rounded-xl text-xs sm:text-sm transition-all duration-200 ${
                      isDarkMode
                        ? 'bg-gray-700/30 hover:bg-gray-700/50 text-gray-300 border border-gray-600/30'
                        : 'bg-gray-50/80 hover:bg-gray-100/80 text-gray-700 border border-gray-200/50'
                    }`}
                  >
                    {question}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ) : (
            messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-2 sm:space-x-3 max-w-[85%] ${
                  message.isUser ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      message.isUser
                        ? isDarkMode ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-green-400 to-emerald-500'
                        : isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                    }`}
                    style={{
                      boxShadow: message.isUser 
                        ? '0 8px 30px rgba(34, 197, 94, 0.4)'
                        : '0 8px 30px rgba(59, 130, 246, 0.4)'
                    }}
                  >
                    {message.isUser ? 
                      <User className="h-4 w-4 text-white" /> : 
                      <Bot className="h-4 w-4 text-white" />
                    }
                  </motion.div>
                  
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className={`rounded-xl sm:rounded-2xl px-3 sm:px-4 py-3 ${
                      message.isUser
                        ? isDarkMode 
                          ? 'bg-gradient-to-br from-green-600/20 to-emerald-600/20 border border-green-500/30 text-green-100'
                          : 'bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-400/30 text-green-800'
                        : isDarkMode
                          ? 'bg-gray-700/50 border border-gray-600/50 text-gray-100'
                          : 'bg-gray-100/80 border border-gray-200/50 text-gray-800'
                    }`}
                    style={{
                      boxShadow: message.isUser
                        ? '0 8px 30px rgba(34, 197, 94, 0.15)'
                        : '0 8px 30px rgba(0, 0, 0, 0.1)',
                      backdropFilter: 'blur(10px)'
                    }}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {message.content}
                    </p>
                    <p className={`text-xs mt-2 opacity-60`}>
                      {message.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </motion.div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex justify-start"
            >
              <div className="flex items-start space-x-2 sm:space-x-3">
                <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl sm:rounded-2xl flex items-center justify-center ${
                  isDarkMode ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-blue-400 to-purple-500'
                }`}>
                  <Bot className="h-4 w-4 text-white" />
                </div>
                
                <div className={`rounded-xl sm:rounded-2xl px-3 sm:px-4 py-3 ${
                  isDarkMode ? 'bg-gray-700/50 border border-gray-600/50' : 'bg-gray-100/80 border border-gray-200/50'
                }`}>
                  <div className="flex space-x-1">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        animate={{ 
                          y: [0, -8, 0],
                          opacity: [0.4, 1, 0.4]
                        }}
                        transition={{ 
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2
                        }}
                        className={`w-2 h-2 rounded-full ${
                          isDarkMode ? 'bg-gray-400' : 'bg-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <motion.div
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        className={`p-3 sm:p-5 border-t ${
          isDarkMode ? 'border-gray-700/50 bg-gray-800/80' : 'border-gray-200/50 bg-gray-50/80'
        }`}
      >
        <div className="flex space-x-2 sm:space-x-3">
          <div className="relative flex-1">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about your PDF or general questions..."
              rows={1}
              disabled={isTyping}
              className={`w-full rounded-xl sm:rounded-2xl border px-3 sm:px-4 py-3 pr-12 resize-none transition-all duration-200 text-sm ${
                isDarkMode
                  ? 'bg-gray-700/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:bg-gray-700/80 disabled:opacity-50'
                  : 'bg-white/80 border-gray-300/50 text-gray-900 placeholder-gray-500 focus:border-blue-500/50 focus:bg-white disabled:opacity-50'
              }`}
              style={{
                minHeight: '48px',
                maxHeight: '120px',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                backdropFilter: 'blur(10px)'
              }}
            />
            
            <motion.button
              whileHover={{ scale: input.trim() && !isTyping ? 1.05 : 1 }}
              whileTap={{ scale: input.trim() && !isTyping ? 0.95 : 1 }}
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className={`absolute right-2 sm:right-3 top-1/2 -translate-y-1/2 p-2 sm:p-3 rounded-lg sm:rounded-xl transition-all duration-200 ${
                input.trim() && !isTyping
                  ? isDarkMode
                    ? 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                    : 'bg-gradient-to-br from-blue-500 to-purple-600 hover:from-blue-400 hover:to-purple-500 text-white shadow-lg'
                  : isDarkMode
                    ? 'bg-gray-600/50 text-gray-400 cursor-not-allowed'
                    : 'bg-gray-200/50 text-gray-400 cursor-not-allowed'
              }`}
              style={input.trim() && !isTyping ? {
                boxShadow: '0 8px 30px rgba(59, 130, 246, 0.4)'
              } : {}}
            >
              {isTyping ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Loader className="h-4 w-4" />
                </motion.div>
              ) : (
                <Send className="h-4 w-4" />
              )}
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}