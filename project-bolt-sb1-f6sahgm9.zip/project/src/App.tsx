import React, { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { LoginPage } from './components/LoginPage'
import { SidebarNavigation } from './components/SidebarNavigation'
import { Dashboard } from './components/Dashboard'
import { FloatingWebcam } from './components/FloatingWebcam'
import { ChatBot } from './components/ChatBot'
import { ErrorBoundary } from './components/ErrorBoundary'
import { useAppStore } from './store/useAppStore'

function App() {
  const { isDarkMode, isAuthenticated } = useAppStore()

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode)
  }, [isDarkMode])

  return (
    <ErrorBoundary>
      <div className="min-h-screen w-full overflow-x-hidden bg-gray-50 dark:bg-gray-900">
        {/* Animated Background */}
        <div className="fixed inset-0 w-full h-full overflow-hidden pointer-events-none">
          <div className={`absolute inset-0 w-full h-full transition-all duration-1000 ${
            isDarkMode 
              ? 'bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20' 
              : 'bg-gradient-to-br from-blue-50/30 via-white to-purple-50/30'
          }`} />

          <motion.div
            animate={{
              x: [0, 100, -50, 0],
              y: [0, -80, 40, 0],
              scale: [1, 1.2, 0.8, 1],
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute top-1/4 left-1/4 w-32 h-32 sm:w-48 sm:h-48 lg:w-64 lg:h-64 rounded-full opacity-10 ${
              isDarkMode 
                ? 'bg-gradient-to-br from-blue-500 to-purple-600' 
                : 'bg-gradient-to-br from-blue-300 to-purple-400'
            }`}
            style={{ filter: 'blur(60px)' }}
          />

          <motion.div
            animate={{
              x: [0, -120, 80, 0],
              y: [0, 80, -40, 0],
              scale: [1.2, 0.8, 1.5, 1.2],
            }}
            transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute bottom-1/4 right-1/4 w-24 h-24 sm:w-36 sm:h-36 lg:w-48 lg:h-48 rounded-full opacity-8 ${
              isDarkMode 
                ? 'bg-gradient-to-br from-purple-500 to-pink-600' 
                : 'bg-gradient-to-br from-purple-300 to-pink-400'
            }`}
            style={{ filter: 'blur(50px)' }}
          />

          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -100, 0],
                x: [0, Math.random() * 50 - 25, 0],
                opacity: [0, 0.6, 0],
                scale: [0, 1, 0]
              }}
              transition={{
                duration: 6 + i,
                repeat: Infinity,
                delay: i * 2,
                ease: "easeInOut"
              }}
              className={`absolute w-1 h-1 sm:w-2 sm:h-2 rounded-full ${
                isDarkMode ? 'bg-blue-400' : 'bg-blue-500'
              }`}
              style={{
                left: `${20 + Math.random() * 60}%`,
                top: `${20 + Math.random() * 60}%`,
                filter: 'blur(0.5px)'
              }}
            />
          ))}
        </div>

        <AnimatePresence mode="wait">
          {!isAuthenticated ? (
            <motion.div
              key="login"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95, y: -50 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="relative z-10"
            >
              <LoginPage />
            </motion.div>
          ) : (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, scale: 1.02, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="relative z-10 w-full min-h-screen flex"
            >
              {/* Sidebar Navigation */}
              <div className="relative z-30">
                <SidebarNavigation />
              </div>

              {/* Main Content - Responsive Layout */}
              <motion.main
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
                className="flex-1 min-w-0 w-full min-h-screen px-2 sm:px-4 md:px-6 lg:px-8 xl:px-12 py-4 sm:py-6 lg:py-8 transition-all duration-300 relative z-10"
              >
                <div className="w-full max-w-none">
                  <Dashboard />
                </div>
              </motion.main>

              {/* Floating Components */}
              <div className="relative z-40">
                <AnimatePresence>
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
                  >
                    <FloatingWebcam />
                  </motion.div>

                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 1.2, type: "spring", stiffness: 260, damping: 20 }}
                  >
                    <ChatBot />
                  </motion.div>
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <style jsx global>{`
          * { 
            box-sizing: border-box; 
            margin: 0;
            padding: 0;
          }
          
          html, body {
            width: 100%;
            height: 100%;
            overflow-x: hidden;
            font-size: clamp(14px, 2.5vw, 18px);
            scroll-behavior: smooth;
          }

          #root { 
            width: 100%; 
            height: 100%;
            overflow-x: hidden;
          }

          /* Responsive scrollbar */
          ::-webkit-scrollbar { 
            width: clamp(4px, 1vw, 8px); 
          }
          
          ::-webkit-scrollbar-track {
            background: ${isDarkMode ? 'rgba(55, 65, 81, 0.2)' : 'rgba(243, 244, 246, 0.2)'};
            border-radius: 4px;
          }

          ::-webkit-scrollbar-thumb {
            background: ${isDarkMode 
              ? 'linear-gradient(45deg, #6366f1, #8b5cf6)' 
              : 'linear-gradient(45deg, #8b5cf6, #a855f7)'};
            border-radius: 4px;
          }

          ::-webkit-scrollbar-thumb:hover {
            background: ${isDarkMode 
              ? 'linear-gradient(45deg, #4f46e5, #7c3aed)' 
              : 'linear-gradient(45deg, #7c3aed, #9333ea)'};
          }

          /* Hide scrollbar on mobile */
          @media (max-width: 768px) {
            ::-webkit-scrollbar { display: none; }
            body {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
          }

          /* Responsive glass effect */
          .glass-effect {
            background: ${isDarkMode ? 'rgba(31, 41, 55, 0.7)' : 'rgba(255, 255, 255, 0.7)'};
            backdrop-filter: blur(clamp(8px, 2vw, 16px));
            border: 1px solid ${isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'};
          }

          .magnetic-hover {
            transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
          }

          .magnetic-hover:hover {
            transform: scale(1.02) translateY(-2px);
          }

          /* Responsive loading shimmer */
          .loading-shimmer {
            background: linear-gradient(90deg, 
              ${isDarkMode ? '#374151' : '#f3f4f6'} 25%, 
              ${isDarkMode ? '#4b5563' : '#e5e7eb'} 50%, 
              ${isDarkMode ? '#374151' : '#f3f4f6'} 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
          }

          @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
          }

          .success-bounce {
            animation: successBounce 0.6s ease-out;
          }

          @keyframes successBounce {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
          }

          .error-shake {
            animation: shake 0.5s ease-in-out;
          }

          @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
          }

          .focus-visible:focus-visible {
            outline: 2px solid ${isDarkMode ? '#6366f1' : '#8b5cf6'};
            outline-offset: 2px;
            border-radius: 8px;
          }

          /* Prevent horizontal overflow */
          .container-responsive {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            padding-left: clamp(1rem, 4vw, 3rem);
            padding-right: clamp(1rem, 4vw, 3rem);
          }

          /* Responsive text sizing */
          .text-responsive-xs { font-size: clamp(0.75rem, 2vw, 0.875rem); }
          .text-responsive-sm { font-size: clamp(0.875rem, 2.5vw, 1rem); }
          .text-responsive-base { font-size: clamp(1rem, 3vw, 1.125rem); }
          .text-responsive-lg { font-size: clamp(1.125rem, 3.5vw, 1.25rem); }
          .text-responsive-xl { font-size: clamp(1.25rem, 4vw, 1.5rem); }
          .text-responsive-2xl { font-size: clamp(1.5rem, 5vw, 2rem); }
          .text-responsive-3xl { font-size: clamp(1.875rem, 6vw, 2.5rem); }
          .text-responsive-4xl { font-size: clamp(2.25rem, 7vw, 3rem); }

          /* Responsive spacing */
          .space-responsive-sm > * + * { margin-top: clamp(0.5rem, 2vw, 1rem); }
          .space-responsive-md > * + * { margin-top: clamp(1rem, 3vw, 1.5rem); }
          .space-responsive-lg > * + * { margin-top: clamp(1.5rem, 4vw, 2rem); }

          /* Ensure no element exceeds viewport */
          img, video, canvas, svg {
            max-width: 100%;
            height: auto;
          }

          /* Responsive grid gaps */
          .grid-responsive-sm { gap: clamp(0.5rem, 2vw, 1rem); }
          .grid-responsive-md { gap: clamp(1rem, 3vw, 1.5rem); }
          .grid-responsive-lg { gap: clamp(1.5rem, 4vw, 2rem); }
        `}</style>
      </div>
    </ErrorBoundary>
  )
}

export default App