import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface Message {
  id: string
  content: string
  isUser: boolean
  timestamp: Date
}

interface QuizQuestion {
  id: string
  type: 'multiple-choice' | 'true-false' | 'short-answer'
  question: string
  options?: string[]
  correctAnswer: string | number | boolean
  explanation: string
  difficulty: 'easy' | 'medium' | 'hard'
  topic: string
}

interface User {
  id: string
  name: string
  email: string
  avatar?: string
}

interface AppState {
  // Authentication
  user: User | null
  isAuthenticated: boolean
  setUser: (user: User | null) => void
  setIsAuthenticated: (auth: boolean) => void
  
  // Theme
  isDarkMode: boolean
  toggleTheme: () => void
  
  // Navigation
  isSidebarOpen: boolean
  currentPage: string
  toggleSidebar: () => void
  setCurrentPage: (page: string) => void
  
  // PDF
  uploadedPdf: File | null
  isProcessingPdf: boolean
  pdfTopics: string[]
  pdfContent: string
  setUploadedPdf: (file: File | null) => void
  setIsProcessingPdf: (processing: boolean) => void
  setPdfTopics: (topics: string[]) => void
  setPdfContent: (content: string) => void
  
  // Chat
  messages: Message[]
  isTyping: boolean
  addMessage: (content: string, isUser: boolean) => void
  setIsTyping: (typing: boolean) => void
  clearMessages: () => void
  
  // Enhanced Quiz System
  currentQuiz: QuizQuestion[]
  currentQuestionIndex: number
  score: number
  isQuizActive: boolean
  quizTimeLeft: number
  answeredQuestions: number[]
  setCurrentQuiz: (quiz: QuizQuestion[]) => void
  setCurrentQuestionIndex: (index: number) => void
  setScore: (score: number) => void
  setIsQuizActive: (active: boolean) => void
  setQuizTimeLeft: (time: number) => void
  addAnsweredQuestion: (index: number) => void
  resetQuiz: () => void
  
  // Study Progress
  studyStreak: number
  dailyXP: number
  totalXP: number
  level: number
  weeklyProgress: boolean[]
  achievements: string[]
  setStudyStreak: (streak: number) => void
  setDailyXP: (xp: number) => void
  addXP: (xp: number) => void
  setLevel: (level: number) => void
  updateWeeklyProgress: (day: number, completed: boolean) => void
  addAchievement: (achievement: string) => void
  
  // Webcam
  isWebcamOpen: boolean
  webcamPosition: { x: number; y: number }
  webcamSize: { width: number; height: number }
  isWebcamMuted: boolean
  webcamStream: MediaStream | null
  setIsWebcamOpen: (open: boolean) => void
  setWebcamPosition: (position: { x: number; y: number }) => void
  setWebcamSize: (size: { width: number; height: number }) => void
  setIsWebcamMuted: (muted: boolean) => void
  setWebcamStream: (stream: MediaStream | null) => void
  
  // Settings
  notifications: boolean
  autoSave: boolean
  language: string
  setNotifications: (enabled: boolean) => void
  setAutoSave: (enabled: boolean) => void
  setLanguage: (lang: string) => void
}

// Get responsive webcam size based on screen width
const getInitialWebcamSize = () => {
  if (typeof window === 'undefined') return { width: 280, height: 210 }
  
  const screenWidth = window.innerWidth
  if (screenWidth < 640) { // mobile
    return { width: 200, height: 150 }
  } else if (screenWidth < 1024) { // tablet
    return { width: 240, height: 180 }
  } else { // desktop
    return { width: 280, height: 210 }
  }
}

// Get initial webcam position (bottom-right corner)
const getInitialWebcamPosition = () => {
  if (typeof window === 'undefined') return { x: 20, y: 100 }
  
  const screenWidth = window.innerWidth
  const screenHeight = window.innerHeight
  const size = getInitialWebcamSize()
  
  return {
    x: screenWidth - size.width - 20,
    y: screenHeight - size.height - 100
  }
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Authentication
      user: null,
      isAuthenticated: false,
      setUser: (user) => set({ user }),
      setIsAuthenticated: (auth) => set({ isAuthenticated: auth }),
      
      // Theme
      isDarkMode: true,
      toggleTheme: () => set((state) => ({ isDarkMode: !state.isDarkMode })),
      
      // Navigation
      isSidebarOpen: false,
      currentPage: 'dashboard',
      toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
      setCurrentPage: (page) => set({ currentPage: page }),
      
      // PDF
      uploadedPdf: null,
      isProcessingPdf: false,
      pdfTopics: [],
      pdfContent: '',
      setUploadedPdf: (file) => set({ uploadedPdf: file }),
      setIsProcessingPdf: (processing) => set({ isProcessingPdf: processing }),
      setPdfTopics: (topics) => set({ pdfTopics: topics }),
      setPdfContent: (content) => set({ pdfContent: content }),
      
      // Chat
      messages: [],
      isTyping: false,
      addMessage: (content, isUser) => set((state) => ({
        messages: [...state.messages, {
          id: `${Date.now()}-${Math.random()}`,
          content,
          isUser,
          timestamp: new Date()
        }]
      })),
      setIsTyping: (typing) => set({ isTyping: typing }),
      clearMessages: () => set({ messages: [] }),
      
      // Enhanced Quiz System
      currentQuiz: [],
      currentQuestionIndex: 0,
      score: 0,
      isQuizActive: false,
      quizTimeLeft: 300,
      answeredQuestions: [],
      setCurrentQuiz: (quiz) => set({ currentQuiz: quiz }),
      setCurrentQuestionIndex: (index) => set({ currentQuestionIndex: index }),
      setScore: (score) => set({ score: score }),
      setIsQuizActive: (active) => set({ isQuizActive: active }),
      setQuizTimeLeft: (time) => set({ quizTimeLeft: time }),
      addAnsweredQuestion: (index) => set((state) => ({
        answeredQuestions: [...state.answeredQuestions, index]
      })),
      resetQuiz: () => set({
        currentQuiz: [],
        currentQuestionIndex: 0,
        score: 0,
        isQuizActive: false,
        quizTimeLeft: 300,
        answeredQuestions: []
      }),
      
      // Study Progress - Start with clean slate
      studyStreak: 0,
      dailyXP: 0,
      totalXP: 0,
      level: 1,
      weeklyProgress: [false, false, false, false, false, false, false],
      achievements: [],
      setStudyStreak: (streak) => set({ studyStreak: streak }),
      setDailyXP: (xp) => set({ dailyXP: xp }),
      addXP: (xp) => set((state) => {
        const newDailyXP = state.dailyXP + xp
        const newTotalXP = state.totalXP + xp
        const newLevel = Math.floor(newTotalXP / 500) + 1
        return { dailyXP: newDailyXP, totalXP: newTotalXP, level: newLevel }
      }),
      setLevel: (level) => set({ level: level }),
      updateWeeklyProgress: (day, completed) => set((state) => {
        const newProgress = [...state.weeklyProgress]
        newProgress[day] = completed
        return { weeklyProgress: newProgress }
      }),
      addAchievement: (achievement) => set((state) => ({
        achievements: [...state.achievements, achievement]
      })),
      
      // Webcam - Better initial positioning
      isWebcamOpen: false,
      webcamPosition: getInitialWebcamPosition(),
      webcamSize: getInitialWebcamSize(),
      isWebcamMuted: false,
      webcamStream: null,
      setIsWebcamOpen: (open) => set({ isWebcamOpen: open }),
      setWebcamPosition: (position) => set({ webcamPosition: position }),
      setWebcamSize: (size) => set({ webcamSize: size }),
      setIsWebcamMuted: (muted) => set({ isWebcamMuted: muted }),
      setWebcamStream: (stream) => set({ webcamStream: stream }),
      
      // Settings
      notifications: true,
      autoSave: true,
      language: 'en',
      setNotifications: (enabled) => set({ notifications: enabled }),
      setAutoSave: (enabled) => set({ autoSave: enabled }),
      setLanguage: (lang) => set({ language: lang })
    }),
    {
      name: 'ai-pdf-assistant-storage',
      partialize: (state) => ({
        isDarkMode: state.isDarkMode,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        studyStreak: state.studyStreak,
        dailyXP: state.dailyXP,
        totalXP: state.totalXP,
        level: state.level,
        weeklyProgress: state.weeklyProgress,
        achievements: state.achievements,
        notifications: state.notifications,
        autoSave: state.autoSave,
        language: state.language,
        webcamPosition: state.webcamPosition,
        webcamSize: state.webcamSize,
        isWebcamMuted: state.isWebcamMuted
      })
    }
  )
)