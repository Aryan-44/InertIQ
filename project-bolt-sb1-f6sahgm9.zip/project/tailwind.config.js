/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'spin-slow': 'spin 4s linear infinite',
        'bounce-slow': 'bounce 3s infinite',
        'shimmer': 'shimmer 2s infinite',
        'morph': 'morph 12s ease-in-out infinite',
        'floating': 'floating 6s ease-in-out infinite',
        'pulseGlow': 'pulseGlow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        glow: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.5' },
        },
        shimmer: {
          '0%': { left: '-100%' },
          '100%': { left: '100%' },
        },
        morph: {
          '0%, 100%': { 
            borderRadius: '50% 50% 50% 50% / 50% 50% 50% 50%',
            transform: 'rotate(0deg) scale(1)'
          },
          '25%': { 
            borderRadius: '75% 25% 50% 50% / 50% 75% 25% 50%',
            transform: 'rotate(90deg) scale(1.1)'
          },
          '50%': { 
            borderRadius: '50% 75% 25% 50% / 25% 50% 75% 50%',
            transform: 'rotate(180deg) scale(0.9)'
          },
          '75%': { 
            borderRadius: '25% 50% 75% 50% / 50% 25% 50% 75%',
            transform: 'rotate(270deg) scale(1.05)'
          },
        },
        floating: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        pulseGlow: {
          'from': { boxShadow: '0 0 20px rgba(99, 102, 241, 0.4)' },
          'to': { boxShadow: '0 0 40px rgba(99, 102, 241, 0.8)' },
        },
      },
      backdropBlur: {
        'xs': '2px',
      },
      boxShadow: {
        '3d': '0 8px 30px rgba(0, 0, 0, 0.12), 0 2px 6px rgba(0, 0, 0, 0.08)',
        '3d-hover': '0 15px 40px rgba(0, 0, 0, 0.2), 0 8px 12px rgba(0, 0, 0, 0.15)',
        'glass': 'inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 3px rgba(0, 0, 0, 0.1)',
        'glass-dark': 'inset 0 1px 0 rgba(255, 255, 255, 0.05), 0 1px 3px rgba(0, 0, 0, 0.3)',
        'neumorphic': '20px 20px 60px #bebebe, -20px -20px 60px #ffffff',
        'neumorphic-dark': '20px 20px 60px #1a1a1a, -20px -20px 60px #2e2e2e',
        'glow': '0 0 20px rgba(99, 102, 241, 0.4)',
        'glow-lg': '0 0 40px rgba(99, 102, 241, 0.6)',
      },
      colors: {
        glass: {
          light: 'rgba(255, 255, 255, 0.1)',
          dark: 'rgba(0, 0, 0, 0.1)',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      gridTemplateColumns: {
        '13': 'repeat(13, minmax(0, 1fr))',
        '14': 'repeat(14, minmax(0, 1fr))',
        '15': 'repeat(15, minmax(0, 1fr))',
        '16': 'repeat(16, minmax(0, 1fr))',
      },
      maxWidth: {
        '8xl': '88rem',
        '9xl': '96rem',
        '10xl': '104rem',
        '11xl': '112rem',
        '12xl': '120rem',
      },
      screens: {
        '3xl': '1600px',
        '4xl': '1920px',
        '5xl': '2560px',
      },
      backgroundSize: {
        '100%': '100%',
      },
      perspective: {
        '1000': '1000px',
        '2000': '2000px',
      },
      transformStyle: {
        'preserve-3d': 'preserve-3d',
      },
    },
  },
  plugins: [],
};